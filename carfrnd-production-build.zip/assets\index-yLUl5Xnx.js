var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t),e=null),t.exports),s=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},c=(n,r,o)=>(o=n==null?{}:e(i(n)),s(r||!n||!n.__esModule||!a.call(n,`default`)?t(o,`default`,{value:n,enumerable:!0}):o,n));(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var l=o((e=>{var t=Symbol.for(`react.transitional.element`),n=Symbol.for(`react.portal`),r=Symbol.for(`react.fragment`),i=Symbol.for(`react.strict_mode`),a=Symbol.for(`react.profiler`),o=Symbol.for(`react.consumer`),s=Symbol.for(`react.context`),c=Symbol.for(`react.forward_ref`),l=Symbol.for(`react.suspense`),u=Symbol.for(`react.memo`),d=Symbol.for(`react.lazy`),f=Symbol.for(`react.activity`),p=Symbol.iterator;function m(e){return typeof e!=`object`||!e?null:(e=p&&e[p]||e[`@@iterator`],typeof e==`function`?e:null)}var h={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},g=Object.assign,_={};function v(e,t,n){this.props=e,this.context=t,this.refs=_,this.updater=n||h}v.prototype.isReactComponent={},v.prototype.setState=function(e,t){if(typeof e!=`object`&&typeof e!=`function`&&e!=null)throw Error(`takes an object of state variables to update or a function which returns an object of state variables.`);this.updater.enqueueSetState(this,e,t,`setState`)},v.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,`forceUpdate`)};function y(){}y.prototype=v.prototype;function b(e,t,n){this.props=e,this.context=t,this.refs=_,this.updater=n||h}var x=b.prototype=new y;x.constructor=b,g(x,v.prototype),x.isPureReactComponent=!0;var ee=Array.isArray;function S(){}var C={H:null,A:null,T:null,S:null},te=Object.prototype.hasOwnProperty;function w(e,n,r){var i=r.ref;return{$$typeof:t,type:e,key:n,ref:i===void 0?null:i,props:r}}function ne(e,t){return w(e.type,t,e.props)}function T(e){return typeof e==`object`&&!!e&&e.$$typeof===t}function re(e){var t={"=":`=0`,":":`=2`};return`$`+e.replace(/[=:]/g,function(e){return t[e]})}var ie=/\/+/g;function ae(e,t){return typeof e==`object`&&e&&e.key!=null?re(``+e.key):t.toString(36)}function oe(e){switch(e.status){case`fulfilled`:return e.value;case`rejected`:throw e.reason;default:switch(typeof e.status==`string`?e.then(S,S):(e.status=`pending`,e.then(function(t){e.status===`pending`&&(e.status=`fulfilled`,e.value=t)},function(t){e.status===`pending`&&(e.status=`rejected`,e.reason=t)})),e.status){case`fulfilled`:return e.value;case`rejected`:throw e.reason}}throw e}function se(e,r,i,a,o){var s=typeof e;(s===`undefined`||s===`boolean`)&&(e=null);var c=!1;if(e===null)c=!0;else switch(s){case`bigint`:case`string`:case`number`:c=!0;break;case`object`:switch(e.$$typeof){case t:case n:c=!0;break;case d:return c=e._init,se(c(e._payload),r,i,a,o)}}if(c)return o=o(e),c=a===``?`.`+ae(e,0):a,ee(o)?(i=``,c!=null&&(i=c.replace(ie,`$&/`)+`/`),se(o,r,i,``,function(e){return e})):o!=null&&(T(o)&&(o=ne(o,i+(o.key==null||e&&e.key===o.key?``:(``+o.key).replace(ie,`$&/`)+`/`)+c)),r.push(o)),1;c=0;var l=a===``?`.`:a+`:`;if(ee(e))for(var u=0;u<e.length;u++)a=e[u],s=l+ae(a,u),c+=se(a,r,i,s,o);else if(u=m(e),typeof u==`function`)for(e=u.call(e),u=0;!(a=e.next()).done;)a=a.value,s=l+ae(a,u++),c+=se(a,r,i,s,o);else if(s===`object`){if(typeof e.then==`function`)return se(oe(e),r,i,a,o);throw r=String(e),Error(`Objects are not valid as a React child (found: `+(r===`[object Object]`?`object with keys {`+Object.keys(e).join(`, `)+`}`:r)+`). If you meant to render a collection of children, use an array instead.`)}return c}function E(e,t,n){if(e==null)return e;var r=[],i=0;return se(e,r,``,``,function(e){return t.call(n,e,i++)}),r}function ce(e){if(e._status===-1){var t=e._result;t=t(),t.then(function(t){(e._status===0||e._status===-1)&&(e._status=1,e._result=t)},function(t){(e._status===0||e._status===-1)&&(e._status=2,e._result=t)}),e._status===-1&&(e._status=0,e._result=t)}if(e._status===1)return e._result.default;throw e._result}var D=typeof reportError==`function`?reportError:function(e){if(typeof window==`object`&&typeof window.ErrorEvent==`function`){var t=new window.ErrorEvent(`error`,{bubbles:!0,cancelable:!0,message:typeof e==`object`&&e&&typeof e.message==`string`?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process==`object`&&typeof process.emit==`function`){process.emit(`uncaughtException`,e);return}console.error(e)},O={map:E,forEach:function(e,t,n){E(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return E(e,function(){t++}),t},toArray:function(e){return E(e,function(e){return e})||[]},only:function(e){if(!T(e))throw Error(`React.Children.only expected to receive a single React element child.`);return e}};e.Activity=f,e.Children=O,e.Component=v,e.Fragment=r,e.Profiler=a,e.PureComponent=b,e.StrictMode=i,e.Suspense=l,e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=C,e.__COMPILER_RUNTIME={__proto__:null,c:function(e){return C.H.useMemoCache(e)}},e.cache=function(e){return function(){return e.apply(null,arguments)}},e.cacheSignal=function(){return null},e.cloneElement=function(e,t,n){if(e==null)throw Error(`The argument must be a React element, but you passed `+e+`.`);var r=g({},e.props),i=e.key;if(t!=null)for(a in t.key!==void 0&&(i=``+t.key),t)!te.call(t,a)||a===`key`||a===`__self`||a===`__source`||a===`ref`&&t.ref===void 0||(r[a]=t[a]);var a=arguments.length-2;if(a===1)r.children=n;else if(1<a){for(var o=Array(a),s=0;s<a;s++)o[s]=arguments[s+2];r.children=o}return w(e.type,i,r)},e.createContext=function(e){return e={$$typeof:s,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null},e.Provider=e,e.Consumer={$$typeof:o,_context:e},e},e.createElement=function(e,t,n){var r,i={},a=null;if(t!=null)for(r in t.key!==void 0&&(a=``+t.key),t)te.call(t,r)&&r!==`key`&&r!==`__self`&&r!==`__source`&&(i[r]=t[r]);var o=arguments.length-2;if(o===1)i.children=n;else if(1<o){for(var s=Array(o),c=0;c<o;c++)s[c]=arguments[c+2];i.children=s}if(e&&e.defaultProps)for(r in o=e.defaultProps,o)i[r]===void 0&&(i[r]=o[r]);return w(e,a,i)},e.createRef=function(){return{current:null}},e.forwardRef=function(e){return{$$typeof:c,render:e}},e.isValidElement=T,e.lazy=function(e){return{$$typeof:d,_payload:{_status:-1,_result:e},_init:ce}},e.memo=function(e,t){return{$$typeof:u,type:e,compare:t===void 0?null:t}},e.startTransition=function(e){var t=C.T,n={};C.T=n;try{var r=e(),i=C.S;i!==null&&i(n,r),typeof r==`object`&&r&&typeof r.then==`function`&&r.then(S,D)}catch(e){D(e)}finally{t!==null&&n.types!==null&&(t.types=n.types),C.T=t}},e.unstable_useCacheRefresh=function(){return C.H.useCacheRefresh()},e.use=function(e){return C.H.use(e)},e.useActionState=function(e,t,n){return C.H.useActionState(e,t,n)},e.useCallback=function(e,t){return C.H.useCallback(e,t)},e.useContext=function(e){return C.H.useContext(e)},e.useDebugValue=function(){},e.useDeferredValue=function(e,t){return C.H.useDeferredValue(e,t)},e.useEffect=function(e,t){return C.H.useEffect(e,t)},e.useEffectEvent=function(e){return C.H.useEffectEvent(e)},e.useId=function(){return C.H.useId()},e.useImperativeHandle=function(e,t,n){return C.H.useImperativeHandle(e,t,n)},e.useInsertionEffect=function(e,t){return C.H.useInsertionEffect(e,t)},e.useLayoutEffect=function(e,t){return C.H.useLayoutEffect(e,t)},e.useMemo=function(e,t){return C.H.useMemo(e,t)},e.useOptimistic=function(e,t){return C.H.useOptimistic(e,t)},e.useReducer=function(e,t,n){return C.H.useReducer(e,t,n)},e.useRef=function(e){return C.H.useRef(e)},e.useState=function(e){return C.H.useState(e)},e.useSyncExternalStore=function(e,t,n){return C.H.useSyncExternalStore(e,t,n)},e.useTransition=function(){return C.H.useTransition()},e.version=`19.2.8`})),u=o(((e,t)=>{t.exports=l()})),d=o((e=>{function t(e,t){var n=e.length;e.push(t);a:for(;0<n;){var r=n-1>>>1,a=e[r];if(0<i(a,t))e[r]=t,e[n]=a,n=r;else break a}}function n(e){return e.length===0?null:e[0]}function r(e){if(e.length===0)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;a:for(var r=0,a=e.length,o=a>>>1;r<o;){var s=2*(r+1)-1,c=e[s],l=s+1,u=e[l];if(0>i(c,n))l<a&&0>i(u,c)?(e[r]=u,e[l]=n,r=l):(e[r]=c,e[s]=n,r=s);else if(l<a&&0>i(u,n))e[r]=u,e[l]=n,r=l;else break a}}return t}function i(e,t){var n=e.sortIndex-t.sortIndex;return n===0?e.id-t.id:n}if(e.unstable_now=void 0,typeof performance==`object`&&typeof performance.now==`function`){var a=performance;e.unstable_now=function(){return a.now()}}else{var o=Date,s=o.now();e.unstable_now=function(){return o.now()-s}}var c=[],l=[],u=1,d=null,f=3,p=!1,m=!1,h=!1,g=!1,_=typeof setTimeout==`function`?setTimeout:null,v=typeof clearTimeout==`function`?clearTimeout:null,y=typeof setImmediate<`u`?setImmediate:null;function b(e){for(var i=n(l);i!==null;){if(i.callback===null)r(l);else if(i.startTime<=e)r(l),i.sortIndex=i.expirationTime,t(c,i);else break;i=n(l)}}function x(e){if(h=!1,b(e),!m){if(n(c)!==null)m=!0,ee||(ee=!0,T());else{var t=n(l);t!==null&&ae(x,t.startTime-e)}}}var ee=!1,S=-1,C=5,te=-1;function w(){return g?!0:!(e.unstable_now()-te<C)}function ne(){if(g=!1,ee){var t=e.unstable_now();te=t;var i=!0;try{a:{m=!1,h&&(h=!1,v(S),S=-1),p=!0;var a=f;try{b:{for(b(t),d=n(c);d!==null&&!(d.expirationTime>t&&w());){var o=d.callback;if(typeof o==`function`){d.callback=null,f=d.priorityLevel;var s=o(d.expirationTime<=t);if(t=e.unstable_now(),typeof s==`function`){d.callback=s,b(t),i=!0;break b}d===n(c)&&r(c),b(t)}else r(c);d=n(c)}if(d!==null)i=!0;else{var u=n(l);u!==null&&ae(x,u.startTime-t),i=!1}}break a}finally{d=null,f=a,p=!1}i=void 0}}finally{i?T():ee=!1}}}var T;if(typeof y==`function`)T=function(){y(ne)};else if(typeof MessageChannel<`u`){var re=new MessageChannel,ie=re.port2;re.port1.onmessage=ne,T=function(){ie.postMessage(null)}}else T=function(){_(ne,0)};function ae(t,n){S=_(function(){t(e.unstable_now())},n)}e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(e){e.callback=null},e.unstable_forceFrameRate=function(e){0>e||125<e?console.error(`forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported`):C=0<e?Math.floor(1e3/e):5},e.unstable_getCurrentPriorityLevel=function(){return f},e.unstable_next=function(e){switch(f){case 1:case 2:case 3:var t=3;break;default:t=f}var n=f;f=t;try{return e()}finally{f=n}},e.unstable_requestPaint=function(){g=!0},e.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=f;f=e;try{return t()}finally{f=n}},e.unstable_scheduleCallback=function(r,i,a){var o=e.unstable_now();switch(typeof a==`object`&&a?(a=a.delay,a=typeof a==`number`&&0<a?o+a:o):a=o,r){case 1:var s=-1;break;case 2:s=250;break;case 5:s=1073741823;break;case 4:s=1e4;break;default:s=5e3}return s=a+s,r={id:u++,callback:i,priorityLevel:r,startTime:a,expirationTime:s,sortIndex:-1},a>o?(r.sortIndex=a,t(l,r),n(c)===null&&r===n(l)&&(h?(v(S),S=-1):h=!0,ae(x,a-o))):(r.sortIndex=s,t(c,r),m||p||(m=!0,ee||(ee=!0,T()))),r},e.unstable_shouldYield=w,e.unstable_wrapCallback=function(e){var t=f;return function(){var n=f;f=t;try{return e.apply(this,arguments)}finally{f=n}}}})),f=o(((e,t)=>{t.exports=d()})),p=o((e=>{var t=u();function n(e){var t=`https://react.dev/errors/`+e;if(1<arguments.length){t+=`?args[]=`+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+=`&args[]=`+encodeURIComponent(arguments[n])}return`Minified React error #`+e+`; visit `+t+` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`}function r(){}var i={d:{f:r,r:function(){throw Error(n(522))},D:r,C:r,L:r,m:r,X:r,S:r,M:r},p:0,findDOMNode:null},a=Symbol.for(`react.portal`);function o(e,t,n){var r=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:a,key:r==null?null:``+r,children:e,containerInfo:t,implementation:n}}var s=t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function c(e,t){if(e===`font`)return``;if(typeof t==`string`)return t===`use-credentials`?t:``}e.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=i,e.createPortal=function(e,t){var r=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)throw Error(n(299));return o(e,t,null,r)},e.flushSync=function(e){var t=s.T,n=i.p;try{if(s.T=null,i.p=2,e)return e()}finally{s.T=t,i.p=n,i.d.f()}},e.preconnect=function(e,t){typeof e==`string`&&(t?(t=t.crossOrigin,t=typeof t==`string`?t===`use-credentials`?t:``:void 0):t=null,i.d.C(e,t))},e.prefetchDNS=function(e){typeof e==`string`&&i.d.D(e)},e.preinit=function(e,t){if(typeof e==`string`&&t&&typeof t.as==`string`){var n=t.as,r=c(n,t.crossOrigin),a=typeof t.integrity==`string`?t.integrity:void 0,o=typeof t.fetchPriority==`string`?t.fetchPriority:void 0;n===`style`?i.d.S(e,typeof t.precedence==`string`?t.precedence:void 0,{crossOrigin:r,integrity:a,fetchPriority:o}):n===`script`&&i.d.X(e,{crossOrigin:r,integrity:a,fetchPriority:o,nonce:typeof t.nonce==`string`?t.nonce:void 0})}},e.preinitModule=function(e,t){if(typeof e==`string`){if(typeof t==`object`&&t){if(t.as==null||t.as===`script`){var n=c(t.as,t.crossOrigin);i.d.M(e,{crossOrigin:n,integrity:typeof t.integrity==`string`?t.integrity:void 0,nonce:typeof t.nonce==`string`?t.nonce:void 0})}}else t??i.d.M(e)}},e.preload=function(e,t){if(typeof e==`string`&&typeof t==`object`&&t&&typeof t.as==`string`){var n=t.as,r=c(n,t.crossOrigin);i.d.L(e,n,{crossOrigin:r,integrity:typeof t.integrity==`string`?t.integrity:void 0,nonce:typeof t.nonce==`string`?t.nonce:void 0,type:typeof t.type==`string`?t.type:void 0,fetchPriority:typeof t.fetchPriority==`string`?t.fetchPriority:void 0,referrerPolicy:typeof t.referrerPolicy==`string`?t.referrerPolicy:void 0,imageSrcSet:typeof t.imageSrcSet==`string`?t.imageSrcSet:void 0,imageSizes:typeof t.imageSizes==`string`?t.imageSizes:void 0,media:typeof t.media==`string`?t.media:void 0})}},e.preloadModule=function(e,t){if(typeof e==`string`){if(t){var n=c(t.as,t.crossOrigin);i.d.m(e,{as:typeof t.as==`string`&&t.as!==`script`?t.as:void 0,crossOrigin:n,integrity:typeof t.integrity==`string`?t.integrity:void 0})}else i.d.m(e)}},e.requestFormReset=function(e){i.d.r(e)},e.unstable_batchedUpdates=function(e,t){return e(t)},e.useFormState=function(e,t,n){return s.H.useFormState(e,t,n)},e.useFormStatus=function(){return s.H.useHostTransitionStatus()},e.version=`19.2.8`})),m=o(((e,t)=>{function n(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>`u`||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!=`function`))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(e){console.error(e)}}n(),t.exports=p()})),h=o((e=>{var t=f(),n=u(),r=m();function i(e){var t=`https://react.dev/errors/`+e;if(1<arguments.length){t+=`?args[]=`+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+=`&args[]=`+encodeURIComponent(arguments[n])}return`Minified React error #`+e+`; visit `+t+` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`}function a(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function o(e){var t=e,n=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,t.flags&4098&&(n=t.return),e=t.return;while(e)}return t.tag===3?n:null}function s(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function c(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function l(e){if(o(e)!==e)throw Error(i(188))}function d(e){var t=e.alternate;if(!t){if(t=o(e),t===null)throw Error(i(188));return t===e?e:null}for(var n=e,r=t;;){var a=n.return;if(a===null)break;var s=a.alternate;if(s===null){if(r=a.return,r!==null){n=r;continue}break}if(a.child===s.child){for(s=a.child;s;){if(s===n)return l(a),e;if(s===r)return l(a),t;s=s.sibling}throw Error(i(188))}if(n.return!==r.return)n=a,r=s;else{for(var c=!1,u=a.child;u;){if(u===n){c=!0,n=a,r=s;break}if(u===r){c=!0,r=a,n=s;break}u=u.sibling}if(!c){for(u=s.child;u;){if(u===n){c=!0,n=s,r=a;break}if(u===r){c=!0,r=s,n=a;break}u=u.sibling}if(!c)throw Error(i(189))}}if(n.alternate!==r)throw Error(i(190))}if(n.tag!==3)throw Error(i(188));return n.stateNode.current===n?e:t}function p(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=p(e),t!==null)return t;e=e.sibling}return null}var h=Object.assign,g=Symbol.for(`react.element`),_=Symbol.for(`react.transitional.element`),v=Symbol.for(`react.portal`),y=Symbol.for(`react.fragment`),b=Symbol.for(`react.strict_mode`),x=Symbol.for(`react.profiler`),ee=Symbol.for(`react.consumer`),S=Symbol.for(`react.context`),C=Symbol.for(`react.forward_ref`),te=Symbol.for(`react.suspense`),w=Symbol.for(`react.suspense_list`),ne=Symbol.for(`react.memo`),T=Symbol.for(`react.lazy`),re=Symbol.for(`react.activity`),ie=Symbol.for(`react.memo_cache_sentinel`),ae=Symbol.iterator;function oe(e){return typeof e!=`object`||!e?null:(e=ae&&e[ae]||e[`@@iterator`],typeof e==`function`?e:null)}var se=Symbol.for(`react.client.reference`);function E(e){if(e==null)return null;if(typeof e==`function`)return e.$$typeof===se?null:e.displayName||e.name||null;if(typeof e==`string`)return e;switch(e){case y:return`Fragment`;case x:return`Profiler`;case b:return`StrictMode`;case te:return`Suspense`;case w:return`SuspenseList`;case re:return`Activity`}if(typeof e==`object`)switch(e.$$typeof){case v:return`Portal`;case S:return e.displayName||`Context`;case ee:return(e._context.displayName||`Context`)+`.Consumer`;case C:var t=e.render;return e=e.displayName,e||=(e=t.displayName||t.name||``,e===``?`ForwardRef`:`ForwardRef(`+e+`)`),e;case ne:return t=e.displayName||null,t===null?E(e.type)||`Memo`:t;case T:t=e._payload,e=e._init;try{return E(e(t))}catch{}}return null}var ce=Array.isArray,D=n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,O=r.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,le={pending:!1,data:null,method:null,action:null},ue=[],de=-1;function fe(e){return{current:e}}function k(e){0>de||(e.current=ue[de],ue[de]=null,de--)}function A(e,t){de++,ue[de]=e.current,e.current=t}var pe=fe(null),me=fe(null),he=fe(null),ge=fe(null);function _e(e,t){switch(A(he,t),A(me,e),A(pe,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?Vd(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=Vd(t),e=Hd(t,e);else switch(e){case`svg`:e=1;break;case`math`:e=2;break;default:e=0}}k(pe),A(pe,e)}function ve(){k(pe),k(me),k(he)}function ye(e){e.memoizedState!==null&&A(ge,e);var t=pe.current,n=Hd(t,e.type);t!==n&&(A(me,e),A(pe,n))}function be(e){me.current===e&&(k(pe),k(me)),ge.current===e&&(k(ge),Qf._currentValue=le)}var xe,Se;function Ce(e){if(xe===void 0)try{throw Error()}catch(e){var t=e.stack.trim().match(/\n( *(at )?)/);xe=t&&t[1]||``,Se=-1<e.stack.indexOf(`
    at`)?` (<anonymous>)`:-1<e.stack.indexOf(`@`)?`@unknown:0:0`:``}return`
`+xe+e+Se}var we=!1;function Te(e,t){if(!e||we)return``;we=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var r={DetermineComponentFrameRoot:function(){try{if(t){var n=function(){throw Error()};if(Object.defineProperty(n.prototype,"props",{set:function(){throw Error()}}),typeof Reflect==`object`&&Reflect.construct){try{Reflect.construct(n,[])}catch(e){var r=e}Reflect.construct(e,[],n)}else{try{n.call()}catch(e){r=e}e.call(n.prototype)}}else{try{throw Error()}catch(e){r=e}(n=e())&&typeof n.catch==`function`&&n.catch(function(){})}}catch(e){if(e&&r&&typeof e.stack==`string`)return[e.stack,r.stack]}return[null,null]}};r.DetermineComponentFrameRoot.displayName=`DetermineComponentFrameRoot`;var i=Object.getOwnPropertyDescriptor(r.DetermineComponentFrameRoot,`name`);i&&i.configurable&&Object.defineProperty(r.DetermineComponentFrameRoot,"name",{value:`DetermineComponentFrameRoot`});var a=r.DetermineComponentFrameRoot(),o=a[0],s=a[1];if(o&&s){var c=o.split(`
`),l=s.split(`
`);for(i=r=0;r<c.length&&!c[r].includes(`DetermineComponentFrameRoot`);)r++;for(;i<l.length&&!l[i].includes(`DetermineComponentFrameRoot`);)i++;if(r===c.length||i===l.length)for(r=c.length-1,i=l.length-1;1<=r&&0<=i&&c[r]!==l[i];)i--;for(;1<=r&&0<=i;r--,i--)if(c[r]!==l[i]){if(r!==1||i!==1)do if(r--,i--,0>i||c[r]!==l[i]){var u=`
`+c[r].replace(` at new `,` at `);return e.displayName&&u.includes(`<anonymous>`)&&(u=u.replace(`<anonymous>`,e.displayName)),u}while(1<=r&&0<=i);break}}}finally{we=!1,Error.prepareStackTrace=n}return(n=e?e.displayName||e.name:``)?Ce(n):``}function Ee(e,t){switch(e.tag){case 26:case 27:case 5:return Ce(e.type);case 16:return Ce(`Lazy`);case 13:return e.child!==t&&t!==null?Ce(`Suspense Fallback`):Ce(`Suspense`);case 19:return Ce(`SuspenseList`);case 0:case 15:return Te(e.type,!1);case 11:return Te(e.type.render,!1);case 1:return Te(e.type,!0);case 31:return Ce(`Activity`);default:return``}}function De(e){try{var t=``,n=null;do t+=Ee(e,n),n=e,e=e.return;while(e);return t}catch(e){return`
Error generating stack: `+e.message+`
`+e.stack}}var Oe=Object.prototype.hasOwnProperty,ke=t.unstable_scheduleCallback,Ae=t.unstable_cancelCallback,j=t.unstable_shouldYield,je=t.unstable_requestPaint,Me=t.unstable_now,Ne=t.unstable_getCurrentPriorityLevel,Pe=t.unstable_ImmediatePriority,Fe=t.unstable_UserBlockingPriority,Ie=t.unstable_NormalPriority,Le=t.unstable_LowPriority,Re=t.unstable_IdlePriority,ze=t.log,Be=t.unstable_setDisableYieldValue,Ve=null,He=null;function Ue(e){if(typeof ze==`function`&&Be(e),He&&typeof He.setStrictMode==`function`)try{He.setStrictMode(Ve,e)}catch{}}var We=Math.clz32?Math.clz32:qe,Ge=Math.log,Ke=Math.LN2;function qe(e){return e>>>=0,e===0?32:31-(Ge(e)/Ke|0)|0}var Je=256,Ye=262144,Xe=4194304;function Ze(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&261888;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function Qe(e,t,n){var r=e.pendingLanes;if(r===0)return 0;var i=0,a=e.suspendedLanes,o=e.pingedLanes;e=e.warmLanes;var s=r&134217727;return s===0?(s=r&~a,s===0?o===0?n||(n=r&~e,n!==0&&(i=Ze(n))):i=Ze(o):i=Ze(s)):(r=s&~a,r===0?(o&=s,o===0?n||(n=s&~e,n!==0&&(i=Ze(n))):i=Ze(o)):i=Ze(r)),i===0?0:t!==0&&t!==i&&(t&a)===0&&(a=i&-i,n=t&-t,a>=n||a===32&&n&4194048)?t:i}function $e(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function et(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function tt(){var e=Xe;return Xe<<=1,!(Xe&62914560)&&(Xe=4194304),e}function nt(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function rt(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function it(e,t,n,r,i,a){var o=e.pendingLanes;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;var s=e.entanglements,c=e.expirationTimes,l=e.hiddenUpdates;for(n=o&~n;0<n;){var u=31-We(n),d=1<<u;s[u]=0,c[u]=-1;var f=l[u];if(f!==null)for(l[u]=null,u=0;u<f.length;u++){var p=f[u];p!==null&&(p.lane&=-536870913)}n&=~d}r!==0&&at(e,r,0),a!==0&&i===0&&e.tag!==0&&(e.suspendedLanes|=a&~(o&~t))}function at(e,t,n){e.pendingLanes|=t,e.suspendedLanes&=~t;var r=31-We(t);e.entangledLanes|=t,e.entanglements[r]=e.entanglements[r]|1073741824|n&261930}function ot(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var r=31-We(n),i=1<<r;i&t|e[r]&t&&(e[r]|=t),n&=~i}}function st(e,t){var n=t&-t;return n=n&42?1:ct(n),(n&(e.suspendedLanes|t))===0?n:0}function ct(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function lt(e){return e&=-e,2<e?8<e?e&134217727?32:268435456:8:2}function ut(){var e=O.p;return e===0?(e=window.event,e===void 0?32:mp(e.type)):e}function dt(e,t){var n=O.p;try{return O.p=e,t()}finally{O.p=n}}var ft=Math.random().toString(36).slice(2),pt=`__reactFiber$`+ft,mt=`__reactProps$`+ft,ht=`__reactContainer$`+ft,gt=`__reactEvents$`+ft,_t=`__reactListeners$`+ft,vt=`__reactHandles$`+ft,yt=`__reactResources$`+ft,bt=`__reactMarker$`+ft;function xt(e){delete e[pt],delete e[mt],delete e[gt],delete e[_t],delete e[vt]}function St(e){var t=e[pt];if(t)return t;for(var n=e.parentNode;n;){if(t=n[ht]||n[pt]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=df(e);e!==null;){if(n=e[pt])return n;e=df(e)}return t}e=n,n=e.parentNode}return null}function Ct(e){if(e=e[pt]||e[ht]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function wt(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(i(33))}function Tt(e){var t=e[yt];return t||=e[yt]={hoistableStyles:new Map,hoistableScripts:new Map},t}function Et(e){e[bt]=!0}var Dt=new Set,Ot={};function kt(e,t){At(e,t),At(e+`Capture`,t)}function At(e,t){for(Ot[e]=t,e=0;e<t.length;e++)Dt.add(t[e])}var jt=RegExp(`^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$`),Mt={},Nt={};function Pt(e){return Oe.call(Nt,e)?!0:Oe.call(Mt,e)?!1:jt.test(e)?Nt[e]=!0:(Mt[e]=!0,!1)}function Ft(e,t,n){if(Pt(t)){if(n===null)e.removeAttribute(t);else{switch(typeof n){case`undefined`:case`function`:case`symbol`:e.removeAttribute(t);return;case`boolean`:var r=t.toLowerCase().slice(0,5);if(r!==`data-`&&r!==`aria-`){e.removeAttribute(t);return}}e.setAttribute(t,``+n)}}}function It(e,t,n){if(n===null)e.removeAttribute(t);else{switch(typeof n){case`undefined`:case`function`:case`symbol`:case`boolean`:e.removeAttribute(t);return}e.setAttribute(t,``+n)}}function Lt(e,t,n,r){if(r===null)e.removeAttribute(n);else{switch(typeof r){case`undefined`:case`function`:case`symbol`:case`boolean`:e.removeAttribute(n);return}e.setAttributeNS(t,n,``+r)}}function Rt(e){switch(typeof e){case`bigint`:case`boolean`:case`number`:case`string`:case`undefined`:return e;case`object`:return e;default:return``}}function zt(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()===`input`&&(t===`checkbox`||t===`radio`)}function Bt(e,t,n){var r=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&r!==void 0&&typeof r.get==`function`&&typeof r.set==`function`){var i=r.get,a=r.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return i.call(this)},set:function(e){n=``+e,a.call(this,e)}}),Object.defineProperty(e,t,{enumerable:r.enumerable}),{getValue:function(){return n},setValue:function(e){n=``+e},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function Vt(e){if(!e._valueTracker){var t=zt(e)?`checked`:`value`;e._valueTracker=Bt(e,t,``+e[t])}}function Ht(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),r=``;return e&&(r=zt(e)?e.checked?`true`:`false`:e.value),e=r,e!==n&&(t.setValue(e),!0)}function Ut(e){if(e||=typeof document<`u`?document:void 0,e===void 0)return null;try{return e.activeElement||e.body}catch{return e.body}}var Wt=/[\n"\\]/g;function Gt(e){return e.replace(Wt,function(e){return`\\`+e.charCodeAt(0).toString(16)+` `})}function Kt(e,t,n,r,i,a,o,s){e.name=``,o!=null&&typeof o!=`function`&&typeof o!=`symbol`&&typeof o!=`boolean`?e.type=o:e.removeAttribute(`type`),t==null?o!==`submit`&&o!==`reset`||e.removeAttribute(`value`):o===`number`?(t===0&&e.value===``||e.value!=t)&&(e.value=``+Rt(t)):e.value!==``+Rt(t)&&(e.value=``+Rt(t)),t==null?n==null?r!=null&&e.removeAttribute(`value`):Jt(e,o,Rt(n)):Jt(e,o,Rt(t)),i==null&&a!=null&&(e.defaultChecked=!!a),i!=null&&(e.checked=i&&typeof i!=`function`&&typeof i!=`symbol`),s!=null&&typeof s!=`function`&&typeof s!=`symbol`&&typeof s!=`boolean`?e.name=``+Rt(s):e.removeAttribute(`name`)}function qt(e,t,n,r,i,a,o,s){if(a!=null&&typeof a!=`function`&&typeof a!=`symbol`&&typeof a!=`boolean`&&(e.type=a),t!=null||n!=null){if(!(a!==`submit`&&a!==`reset`||t!=null)){Vt(e);return}n=n==null?``:``+Rt(n),t=t==null?n:``+Rt(t),s||t===e.value||(e.value=t),e.defaultValue=t}r??=i,r=typeof r!=`function`&&typeof r!=`symbol`&&!!r,e.checked=s?e.checked:!!r,e.defaultChecked=!!r,o!=null&&typeof o!=`function`&&typeof o!=`symbol`&&typeof o!=`boolean`&&(e.name=o),Vt(e)}function Jt(e,t,n){t===`number`&&Ut(e.ownerDocument)===e||e.defaultValue===``+n||(e.defaultValue=``+n)}function Yt(e,t,n,r){if(e=e.options,t){t={};for(var i=0;i<n.length;i++)t[`$`+n[i]]=!0;for(n=0;n<e.length;n++)i=t.hasOwnProperty(`$`+e[n].value),e[n].selected!==i&&(e[n].selected=i),i&&r&&(e[n].defaultSelected=!0)}else{for(n=``+Rt(n),t=null,i=0;i<e.length;i++){if(e[i].value===n){e[i].selected=!0,r&&(e[i].defaultSelected=!0);return}t!==null||e[i].disabled||(t=e[i])}t!==null&&(t.selected=!0)}}function Xt(e,t,n){if(t!=null&&(t=``+Rt(t),t!==e.value&&(e.value=t),n==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=n==null?``:``+Rt(n)}function Zt(e,t,n,r){if(t==null){if(r!=null){if(n!=null)throw Error(i(92));if(ce(r)){if(1<r.length)throw Error(i(93));r=r[0]}n=r}n??=``,t=n}n=Rt(t),e.defaultValue=n,r=e.textContent,r===n&&r!==``&&r!==null&&(e.value=r),Vt(e)}function Qt(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var $t=new Set(`animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp`.split(` `));function en(e,t,n){var r=t.indexOf(`--`)===0;n==null||typeof n==`boolean`||n===``?r?e.setProperty(t,``):t===`float`?e.cssFloat=``:e[t]=``:r?e.setProperty(t,n):typeof n!=`number`||n===0||$t.has(t)?t===`float`?e.cssFloat=n:e[t]=(``+n).trim():e[t]=n+`px`}function tn(e,t,n){if(t!=null&&typeof t!=`object`)throw Error(i(62));if(e=e.style,n!=null){for(var r in n)!n.hasOwnProperty(r)||t!=null&&t.hasOwnProperty(r)||(r.indexOf(`--`)===0?e.setProperty(r,``):r===`float`?e.cssFloat=``:e[r]=``);for(var a in t)r=t[a],t.hasOwnProperty(a)&&n[a]!==r&&en(e,a,r)}else for(var o in t)t.hasOwnProperty(o)&&en(e,o,t[o])}function nn(e){if(e.indexOf(`-`)===-1)return!1;switch(e){case`annotation-xml`:case`color-profile`:case`font-face`:case`font-face-src`:case`font-face-uri`:case`font-face-format`:case`font-face-name`:case`missing-glyph`:return!1;default:return!0}}var rn=new Map([[`acceptCharset`,`accept-charset`],[`htmlFor`,`for`],[`httpEquiv`,`http-equiv`],[`crossOrigin`,`crossorigin`],[`accentHeight`,`accent-height`],[`alignmentBaseline`,`alignment-baseline`],[`arabicForm`,`arabic-form`],[`baselineShift`,`baseline-shift`],[`capHeight`,`cap-height`],[`clipPath`,`clip-path`],[`clipRule`,`clip-rule`],[`colorInterpolation`,`color-interpolation`],[`colorInterpolationFilters`,`color-interpolation-filters`],[`colorProfile`,`color-profile`],[`colorRendering`,`color-rendering`],[`dominantBaseline`,`dominant-baseline`],[`enableBackground`,`enable-background`],[`fillOpacity`,`fill-opacity`],[`fillRule`,`fill-rule`],[`floodColor`,`flood-color`],[`floodOpacity`,`flood-opacity`],[`fontFamily`,`font-family`],[`fontSize`,`font-size`],[`fontSizeAdjust`,`font-size-adjust`],[`fontStretch`,`font-stretch`],[`fontStyle`,`font-style`],[`fontVariant`,`font-variant`],[`fontWeight`,`font-weight`],[`glyphName`,`glyph-name`],[`glyphOrientationHorizontal`,`glyph-orientation-horizontal`],[`glyphOrientationVertical`,`glyph-orientation-vertical`],[`horizAdvX`,`horiz-adv-x`],[`horizOriginX`,`horiz-origin-x`],[`imageRendering`,`image-rendering`],[`letterSpacing`,`letter-spacing`],[`lightingColor`,`lighting-color`],[`markerEnd`,`marker-end`],[`markerMid`,`marker-mid`],[`markerStart`,`marker-start`],[`overlinePosition`,`overline-position`],[`overlineThickness`,`overline-thickness`],[`paintOrder`,`paint-order`],[`panose-1`,`panose-1`],[`pointerEvents`,`pointer-events`],[`renderingIntent`,`rendering-intent`],[`shapeRendering`,`shape-rendering`],[`stopColor`,`stop-color`],[`stopOpacity`,`stop-opacity`],[`strikethroughPosition`,`strikethrough-position`],[`strikethroughThickness`,`strikethrough-thickness`],[`strokeDasharray`,`stroke-dasharray`],[`strokeDashoffset`,`stroke-dashoffset`],[`strokeLinecap`,`stroke-linecap`],[`strokeLinejoin`,`stroke-linejoin`],[`strokeMiterlimit`,`stroke-miterlimit`],[`strokeOpacity`,`stroke-opacity`],[`strokeWidth`,`stroke-width`],[`textAnchor`,`text-anchor`],[`textDecoration`,`text-decoration`],[`textRendering`,`text-rendering`],[`transformOrigin`,`transform-origin`],[`underlinePosition`,`underline-position`],[`underlineThickness`,`underline-thickness`],[`unicodeBidi`,`unicode-bidi`],[`unicodeRange`,`unicode-range`],[`unitsPerEm`,`units-per-em`],[`vAlphabetic`,`v-alphabetic`],[`vHanging`,`v-hanging`],[`vIdeographic`,`v-ideographic`],[`vMathematical`,`v-mathematical`],[`vectorEffect`,`vector-effect`],[`vertAdvY`,`vert-adv-y`],[`vertOriginX`,`vert-origin-x`],[`vertOriginY`,`vert-origin-y`],[`wordSpacing`,`word-spacing`],[`writingMode`,`writing-mode`],[`xmlnsXlink`,`xmlns:xlink`],[`xHeight`,`x-height`]]),an=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function on(e){return an.test(``+e)?`javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')`:e}function sn(){}var cn=null;function ln(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var un=null,dn=null;function fn(e){var t=Ct(e);if(t&&(e=t.stateNode)){var n=e[mt]||null;a:switch(e=t.stateNode,t.type){case`input`:if(Kt(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name),t=n.name,n.type===`radio`&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll(`input[name="`+Gt(``+t)+`"][type="radio"]`),t=0;t<n.length;t++){var r=n[t];if(r!==e&&r.form===e.form){var a=r[mt]||null;if(!a)throw Error(i(90));Kt(r,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name)}}for(t=0;t<n.length;t++)r=n[t],r.form===e.form&&Ht(r)}break a;case`textarea`:Xt(e,n.value,n.defaultValue);break a;case`select`:t=n.value,t!=null&&Yt(e,!!n.multiple,t,!1)}}}var pn=!1;function mn(e,t,n){if(pn)return e(t,n);pn=!0;try{return e(t)}finally{if(pn=!1,(un!==null||dn!==null)&&(bu(),un&&(t=un,e=dn,dn=un=null,fn(t),e)))for(t=0;t<e.length;t++)fn(e[t])}}function hn(e,t){var n=e.stateNode;if(n===null)return null;var r=n[mt]||null;if(r===null)return null;n=r[t];a:switch(t){case`onClick`:case`onClickCapture`:case`onDoubleClick`:case`onDoubleClickCapture`:case`onMouseDown`:case`onMouseDownCapture`:case`onMouseMove`:case`onMouseMoveCapture`:case`onMouseUp`:case`onMouseUpCapture`:case`onMouseEnter`:(r=!r.disabled)||(e=e.type,r=e!==`button`&&e!==`input`&&e!==`select`&&e!==`textarea`),e=!r;break a;default:e=!1}if(e)return null;if(n&&typeof n!=`function`)throw Error(i(231,t,typeof n));return n}var gn=!(typeof window>`u`||window.document===void 0||window.document.createElement===void 0),_n=!1;if(gn)try{var vn={};Object.defineProperty(vn,"passive",{get:function(){_n=!0}}),window.addEventListener(`test`,vn,vn),window.removeEventListener(`test`,vn,vn)}catch{_n=!1}var yn=null,bn=null,xn=null;function Sn(){if(xn)return xn;var e,t=bn,n=t.length,r,i=`value`in yn?yn.value:yn.textContent,a=i.length;for(e=0;e<n&&t[e]===i[e];e++);var o=n-e;for(r=1;r<=o&&t[n-r]===i[a-r];r++);return xn=i.slice(e,1<r?1-r:void 0)}function Cn(e){var t=e.keyCode;return`charCode`in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function wn(){return!0}function Tn(){return!1}function En(e){function t(t,n,r,i,a){for(var o in this._reactName=t,this._targetInst=r,this.type=n,this.nativeEvent=i,this.target=a,this.currentTarget=null,e)e.hasOwnProperty(o)&&(t=e[o],this[o]=t?t(i):i[o]);return this.isDefaultPrevented=(i.defaultPrevented==null?!1===i.returnValue:i.defaultPrevented)?wn:Tn,this.isPropagationStopped=Tn,this}return h(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var e=this.nativeEvent;e&&(e.preventDefault?e.preventDefault():typeof e.returnValue!=`unknown`&&(e.returnValue=!1),this.isDefaultPrevented=wn)},stopPropagation:function(){var e=this.nativeEvent;e&&(e.stopPropagation?e.stopPropagation():typeof e.cancelBubble!=`unknown`&&(e.cancelBubble=!0),this.isPropagationStopped=wn)},persist:function(){},isPersistent:wn}),t}var Dn={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},On=En(Dn),kn=h({},Dn,{view:0,detail:0}),An=En(kn),jn,Mn,Nn,Pn=h({},kn,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Gn,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return`movementX`in e?e.movementX:(e!==Nn&&(Nn&&e.type===`mousemove`?(jn=e.screenX-Nn.screenX,Mn=e.screenY-Nn.screenY):Mn=jn=0,Nn=e),jn)},movementY:function(e){return`movementY`in e?e.movementY:Mn}}),Fn=En(Pn),In=En(h({},Pn,{dataTransfer:0})),Ln=En(h({},kn,{relatedTarget:0})),Rn=En(h({},Dn,{animationName:0,elapsedTime:0,pseudoElement:0})),zn=En(h({},Dn,{clipboardData:function(e){return`clipboardData`in e?e.clipboardData:window.clipboardData}})),Bn=En(h({},Dn,{data:0})),Vn={Esc:`Escape`,Spacebar:` `,Left:`ArrowLeft`,Up:`ArrowUp`,Right:`ArrowRight`,Down:`ArrowDown`,Del:`Delete`,Win:`OS`,Menu:`ContextMenu`,Apps:`ContextMenu`,Scroll:`ScrollLock`,MozPrintableKey:`Unidentified`},Hn={8:`Backspace`,9:`Tab`,12:`Clear`,13:`Enter`,16:`Shift`,17:`Control`,18:`Alt`,19:`Pause`,20:`CapsLock`,27:`Escape`,32:` `,33:`PageUp`,34:`PageDown`,35:`End`,36:`Home`,37:`ArrowLeft`,38:`ArrowUp`,39:`ArrowRight`,40:`ArrowDown`,45:`Insert`,46:`Delete`,112:`F1`,113:`F2`,114:`F3`,115:`F4`,116:`F5`,117:`F6`,118:`F7`,119:`F8`,120:`F9`,121:`F10`,122:`F11`,123:`F12`,144:`NumLock`,145:`ScrollLock`,224:`Meta`},Un={Alt:`altKey`,Control:`ctrlKey`,Meta:`metaKey`,Shift:`shiftKey`};function Wn(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=Un[e])?!!t[e]:!1}function Gn(){return Wn}var Kn=En(h({},kn,{key:function(e){if(e.key){var t=Vn[e.key]||e.key;if(t!==`Unidentified`)return t}return e.type===`keypress`?(e=Cn(e),e===13?`Enter`:String.fromCharCode(e)):e.type===`keydown`||e.type===`keyup`?Hn[e.keyCode]||`Unidentified`:``},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Gn,charCode:function(e){return e.type===`keypress`?Cn(e):0},keyCode:function(e){return e.type===`keydown`||e.type===`keyup`?e.keyCode:0},which:function(e){return e.type===`keypress`?Cn(e):e.type===`keydown`||e.type===`keyup`?e.keyCode:0}})),qn=En(h({},Pn,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0})),Jn=En(h({},kn,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Gn})),Yn=En(h({},Dn,{propertyName:0,elapsedTime:0,pseudoElement:0})),Xn=En(h({},Pn,{deltaX:function(e){return`deltaX`in e?e.deltaX:`wheelDeltaX`in e?-e.wheelDeltaX:0},deltaY:function(e){return`deltaY`in e?e.deltaY:`wheelDeltaY`in e?-e.wheelDeltaY:`wheelDelta`in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0})),Zn=En(h({},Dn,{newState:0,oldState:0})),Qn=[9,13,27,32],$n=gn&&`CompositionEvent`in window,er=null;gn&&`documentMode`in document&&(er=document.documentMode);var tr=gn&&`TextEvent`in window&&!er,nr=gn&&(!$n||er&&8<er&&11>=er),rr=` `,ir=!1;function ar(e,t){switch(e){case`keyup`:return Qn.indexOf(t.keyCode)!==-1;case`keydown`:return t.keyCode!==229;case`keypress`:case`mousedown`:case`focusout`:return!0;default:return!1}}function or(e){return e=e.detail,typeof e==`object`&&`data`in e?e.data:null}var sr=!1;function cr(e,t){switch(e){case`compositionend`:return or(t);case`keypress`:return t.which===32?(ir=!0,rr):null;case`textInput`:return e=t.data,e===rr&&ir?null:e;default:return null}}function lr(e,t){if(sr)return e===`compositionend`||!$n&&ar(e,t)?(e=Sn(),xn=bn=yn=null,sr=!1,e):null;switch(e){case`paste`:return null;case`keypress`:if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case`compositionend`:return nr&&t.locale!==`ko`?null:t.data;default:return null}}var ur={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function dr(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t===`input`?!!ur[e.type]:t===`textarea`}function fr(e,t,n,r){un?dn?dn.push(r):dn=[r]:un=r,t=Ed(t,`onChange`),0<t.length&&(n=new On(`onChange`,`change`,null,n,r),e.push({event:n,listeners:t}))}var pr=null,mr=null;function hr(e){yd(e,0)}function gr(e){if(Ht(wt(e)))return e}function _r(e,t){if(e===`change`)return t}var vr=!1;if(gn){var yr;if(gn){var br=`oninput`in document;if(!br){var xr=document.createElement(`div`);xr.setAttribute(`oninput`,`return;`),br=typeof xr.oninput==`function`}yr=br}else yr=!1;vr=yr&&(!document.documentMode||9<document.documentMode)}function Sr(){pr&&(pr.detachEvent(`onpropertychange`,Cr),mr=pr=null)}function Cr(e){if(e.propertyName===`value`&&gr(mr)){var t=[];fr(t,mr,e,ln(e)),mn(hr,t)}}function wr(e,t,n){e===`focusin`?(Sr(),pr=t,mr=n,pr.attachEvent(`onpropertychange`,Cr)):e===`focusout`&&Sr()}function Tr(e){if(e===`selectionchange`||e===`keyup`||e===`keydown`)return gr(mr)}function Er(e,t){if(e===`click`)return gr(t)}function Dr(e,t){if(e===`input`||e===`change`)return gr(t)}function Or(e,t){return e===t&&(e!==0||1/e==1/t)||e!==e&&t!==t}var kr=typeof Object.is==`function`?Object.is:Or;function Ar(e,t){if(kr(e,t))return!0;if(typeof e!=`object`||!e||typeof t!=`object`||!t)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var i=n[r];if(!Oe.call(t,i)||!kr(e[i],t[i]))return!1}return!0}function jr(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Mr(e,t){var n=jr(e);e=0;for(var r;n;){if(n.nodeType===3){if(r=e+n.textContent.length,e<=t&&r>=t)return{node:n,offset:t-e};e=r}a:{for(;n;){if(n.nextSibling){n=n.nextSibling;break a}n=n.parentNode}n=void 0}n=jr(n)}}function Nr(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?Nr(e,t.parentNode):`contains`in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function Pr(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=Ut(e.document);t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href==`string`}catch{n=!1}if(n)e=t.contentWindow;else break;t=Ut(e.document)}return t}function Fr(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t===`input`&&(e.type===`text`||e.type===`search`||e.type===`tel`||e.type===`url`||e.type===`password`)||t===`textarea`||e.contentEditable===`true`)}var Ir=gn&&`documentMode`in document&&11>=document.documentMode,Lr=null,Rr=null,zr=null,Br=!1;function Vr(e,t,n){var r=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;Br||Lr==null||Lr!==Ut(r)||(r=Lr,`selectionStart`in r&&Fr(r)?r={start:r.selectionStart,end:r.selectionEnd}:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection(),r={anchorNode:r.anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset}),zr&&Ar(zr,r)||(zr=r,r=Ed(Rr,`onSelect`),0<r.length&&(t=new On(`onSelect`,`select`,null,t,n),e.push({event:t,listeners:r}),t.target=Lr)))}function Hr(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n[`Webkit`+e]=`webkit`+t,n[`Moz`+e]=`moz`+t,n}var Ur={animationend:Hr(`Animation`,`AnimationEnd`),animationiteration:Hr(`Animation`,`AnimationIteration`),animationstart:Hr(`Animation`,`AnimationStart`),transitionrun:Hr(`Transition`,`TransitionRun`),transitionstart:Hr(`Transition`,`TransitionStart`),transitioncancel:Hr(`Transition`,`TransitionCancel`),transitionend:Hr(`Transition`,`TransitionEnd`)},Wr={},Gr={};gn&&(Gr=document.createElement(`div`).style,`AnimationEvent`in window||(delete Ur.animationend.animation,delete Ur.animationiteration.animation,delete Ur.animationstart.animation),`TransitionEvent`in window||delete Ur.transitionend.transition);function Kr(e){if(Wr[e])return Wr[e];if(!Ur[e])return e;var t=Ur[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in Gr)return Wr[e]=t[n];return e}var qr=Kr(`animationend`),Jr=Kr(`animationiteration`),Yr=Kr(`animationstart`),Xr=Kr(`transitionrun`),Zr=Kr(`transitionstart`),Qr=Kr(`transitioncancel`),$r=Kr(`transitionend`),ei=new Map,ti=`abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel`.split(` `);ti.push(`scrollEnd`);function ni(e,t){ei.set(e,t),kt(t,[e])}var ri=typeof reportError==`function`?reportError:function(e){if(typeof window==`object`&&typeof window.ErrorEvent==`function`){var t=new window.ErrorEvent(`error`,{bubbles:!0,cancelable:!0,message:typeof e==`object`&&e&&typeof e.message==`string`?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process==`object`&&typeof process.emit==`function`){process.emit(`uncaughtException`,e);return}console.error(e)},ii=[],ai=0,oi=0;function si(){for(var e=ai,t=oi=ai=0;t<e;){var n=ii[t];ii[t++]=null;var r=ii[t];ii[t++]=null;var i=ii[t];ii[t++]=null;var a=ii[t];if(ii[t++]=null,r!==null&&i!==null){var o=r.pending;o===null?i.next=i:(i.next=o.next,o.next=i),r.pending=i}a!==0&&di(n,i,a)}}function ci(e,t,n,r){ii[ai++]=e,ii[ai++]=t,ii[ai++]=n,ii[ai++]=r,oi|=r,e.lanes|=r,e=e.alternate,e!==null&&(e.lanes|=r)}function li(e,t,n,r){return ci(e,t,n,r),fi(e)}function ui(e,t){return ci(e,null,null,t),fi(e)}function di(e,t,n){e.lanes|=n;var r=e.alternate;r!==null&&(r.lanes|=n);for(var i=!1,a=e.return;a!==null;)a.childLanes|=n,r=a.alternate,r!==null&&(r.childLanes|=n),a.tag===22&&(e=a.stateNode,e===null||e._visibility&1||(i=!0)),e=a,a=a.return;return e.tag===3?(a=e.stateNode,i&&t!==null&&(i=31-We(n),e=a.hiddenUpdates,r=e[i],r===null?e[i]=[t]:r.push(t),t.lane=n|536870912),a):null}function fi(e){if(50<du)throw du=0,fu=null,Error(i(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var pi={};function mi(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function hi(e,t,n,r){return new mi(e,t,n,r)}function gi(e){return e=e.prototype,!(!e||!e.isReactComponent)}function _i(e,t){var n=e.alternate;return n===null?(n=hi(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&65011712,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n.refCleanup=e.refCleanup,n}function vi(e,t){e.flags&=65011714;var n=e.alternate;return n===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,t=n.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function yi(e,t,n,r,a,o){var s=0;if(r=e,typeof e==`function`)gi(e)&&(s=1);else if(typeof e==`string`)s=Uf(e,n,pe.current)?26:e===`html`||e===`head`||e===`body`?27:5;else a:switch(e){case re:return e=hi(31,n,t,a),e.elementType=re,e.lanes=o,e;case y:return bi(n.children,a,o,t);case b:s=8,a|=24;break;case x:return e=hi(12,n,t,a|2),e.elementType=x,e.lanes=o,e;case te:return e=hi(13,n,t,a),e.elementType=te,e.lanes=o,e;case w:return e=hi(19,n,t,a),e.elementType=w,e.lanes=o,e;default:if(typeof e==`object`&&e)switch(e.$$typeof){case S:s=10;break a;case ee:s=9;break a;case C:s=11;break a;case ne:s=14;break a;case T:s=16,r=null;break a}s=29,n=Error(i(130,e===null?`null`:typeof e,``)),r=null}return t=hi(s,n,t,a),t.elementType=e,t.type=r,t.lanes=o,t}function bi(e,t,n,r){return e=hi(7,e,r,t),e.lanes=n,e}function xi(e,t,n){return e=hi(6,e,null,t),e.lanes=n,e}function Si(e){var t=hi(18,null,null,0);return t.stateNode=e,t}function Ci(e,t,n){return t=hi(4,e.children===null?[]:e.children,e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var wi=new WeakMap;function Ti(e,t){if(typeof e==`object`&&e){var n=wi.get(e);return n===void 0?(t={value:e,source:t,stack:De(t)},wi.set(e,t),t):n}return{value:e,source:t,stack:De(t)}}var Ei=[],Di=0,Oi=null,ki=0,Ai=[],ji=0,Mi=null,Ni=1,Pi=``;function Fi(e,t){Ei[Di++]=ki,Ei[Di++]=Oi,Oi=e,ki=t}function Ii(e,t,n){Ai[ji++]=Ni,Ai[ji++]=Pi,Ai[ji++]=Mi,Mi=e;var r=Ni;e=Pi;var i=32-We(r)-1;r&=~(1<<i),n+=1;var a=32-We(t)+i;if(30<a){var o=i-i%5;a=(r&(1<<o)-1).toString(32),r>>=o,i-=o,Ni=1<<32-We(t)+i|n<<i|r,Pi=a+e}else Ni=1<<a|n<<i|r,Pi=e}function Li(e){e.return!==null&&(Fi(e,1),Ii(e,1,0))}function Ri(e){for(;e===Oi;)Oi=Ei[--Di],Ei[Di]=null,ki=Ei[--Di],Ei[Di]=null;for(;e===Mi;)Mi=Ai[--ji],Ai[ji]=null,Pi=Ai[--ji],Ai[ji]=null,Ni=Ai[--ji],Ai[ji]=null}function zi(e,t){Ai[ji++]=Ni,Ai[ji++]=Pi,Ai[ji++]=Mi,Ni=t.id,Pi=t.overflow,Mi=e}var Bi=null,M=null,N=!1,Vi=null,Hi=!1,Ui=Error(i(519));function Wi(e){throw Xi(Ti(Error(i(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?`text`:`HTML`,``)),e)),Ui}function Gi(e){var t=e.stateNode,n=e.type,r=e.memoizedProps;switch(t[pt]=e,t[mt]=r,n){case`dialog`:Q(`cancel`,t),Q(`close`,t);break;case`iframe`:case`object`:case`embed`:Q(`load`,t);break;case`video`:case`audio`:for(n=0;n<_d.length;n++)Q(_d[n],t);break;case`source`:Q(`error`,t);break;case`img`:case`image`:case`link`:Q(`error`,t),Q(`load`,t);break;case`details`:Q(`toggle`,t);break;case`input`:Q(`invalid`,t),qt(t,r.value,r.defaultValue,r.checked,r.defaultChecked,r.type,r.name,!0);break;case`select`:Q(`invalid`,t);break;case`textarea`:Q(`invalid`,t),Zt(t,r.value,r.defaultValue,r.children)}n=r.children,typeof n!=`string`&&typeof n!=`number`&&typeof n!=`bigint`||t.textContent===``+n||!0===r.suppressHydrationWarning||Md(t.textContent,n)?(r.popover!=null&&(Q(`beforetoggle`,t),Q(`toggle`,t)),r.onScroll!=null&&Q(`scroll`,t),r.onScrollEnd!=null&&Q(`scrollend`,t),r.onClick!=null&&(t.onclick=sn),t=!0):t=!1,t||Wi(e,!0)}function Ki(e){for(Bi=e.return;Bi;)switch(Bi.tag){case 5:case 31:case 13:Hi=!1;return;case 27:case 3:Hi=!0;return;default:Bi=Bi.return}}function qi(e){if(e!==Bi)return!1;if(!N)return Ki(e),N=!0,!1;var t=e.tag,n;if((n=t!==3&&t!==27)&&((n=t===5)&&(n=e.type,n=n===`form`||n===`button`||Ud(e.type,e.memoizedProps)),n=!n),n&&M&&Wi(e),Ki(e),t===13){if(e=e.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(i(317));M=uf(e)}else if(t===31){if(e=e.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(i(317));M=uf(e)}else t===27?(t=M,Zd(e.type)?(e=lf,lf=null,M=e):M=t):M=Bi?cf(e.stateNode.nextSibling):null;return!0}function Ji(){M=Bi=null,N=!1}function Yi(){var e=Vi;return e!==null&&(Zl===null?Zl=e:Zl.push.apply(Zl,e),Vi=null),e}function Xi(e){Vi===null?Vi=[e]:Vi.push(e)}var Zi=fe(null),Qi=null,$i=null;function ea(e,t,n){A(Zi,t._currentValue),t._currentValue=n}function ta(e){e._currentValue=Zi.current,k(Zi)}function na(e,t,n){for(;e!==null;){var r=e.alternate;if((e.childLanes&t)===t?r!==null&&(r.childLanes&t)!==t&&(r.childLanes|=t):(e.childLanes|=t,r!==null&&(r.childLanes|=t)),e===n)break;e=e.return}}function ra(e,t,n,r){var a=e.child;for(a!==null&&(a.return=e);a!==null;){var o=a.dependencies;if(o!==null){var s=a.child;o=o.firstContext;a:for(;o!==null;){var c=o;o=a;for(var l=0;l<t.length;l++)if(c.context===t[l]){o.lanes|=n,c=o.alternate,c!==null&&(c.lanes|=n),na(o.return,n,e),r||(s=null);break a}o=c.next}}else if(a.tag===18){if(s=a.return,s===null)throw Error(i(341));s.lanes|=n,o=s.alternate,o!==null&&(o.lanes|=n),na(s,n,e),s=null}else s=a.child;if(s!==null)s.return=a;else for(s=a;s!==null;){if(s===e){s=null;break}if(a=s.sibling,a!==null){a.return=s.return,s=a;break}s=s.return}a=s}}function ia(e,t,n,r){e=null;for(var a=t,o=!1;a!==null;){if(!o){if(a.flags&524288)o=!0;else if(a.flags&262144)break}if(a.tag===10){var s=a.alternate;if(s===null)throw Error(i(387));if(s=s.memoizedProps,s!==null){var c=a.type;kr(a.pendingProps.value,s.value)||(e===null?e=[c]:e.push(c))}}else if(a===ge.current){if(s=a.alternate,s===null)throw Error(i(387));s.memoizedState.memoizedState!==a.memoizedState.memoizedState&&(e===null?e=[Qf]:e.push(Qf))}a=a.return}e!==null&&ra(t,e,n,r),t.flags|=262144}function aa(e){for(e=e.firstContext;e!==null;){if(!kr(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function oa(e){Qi=e,$i=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function sa(e){return la(Qi,e)}function ca(e,t){return Qi===null&&oa(e),la(e,t)}function la(e,t){var n=t._currentValue;if(t={context:t,memoizedValue:n,next:null},$i===null){if(e===null)throw Error(i(308));$i=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else $i=$i.next=t;return n}var ua=typeof AbortController<`u`?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(t,n){e.push(n)}};this.abort=function(){t.aborted=!0,e.forEach(function(e){return e()})}},da=t.unstable_scheduleCallback,fa=t.unstable_NormalPriority,P={$$typeof:S,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function pa(){return{controller:new ua,data:new Map,refCount:0}}function ma(e){e.refCount--,e.refCount===0&&da(fa,function(){e.controller.abort()})}var ha=null,ga=0,_a=0,va=null;function ya(e,t){if(ha===null){var n=ha=[];ga=0,_a=dd(),va={status:`pending`,value:void 0,then:function(e){n.push(e)}}}return ga++,t.then(ba,ba),t}function ba(){if(--ga===0&&ha!==null){va!==null&&(va.status=`fulfilled`);var e=ha;ha=null,_a=0,va=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function xa(e,t){var n=[],r={status:`pending`,value:null,reason:null,then:function(e){n.push(e)}};return e.then(function(){r.status=`fulfilled`,r.value=t;for(var e=0;e<n.length;e++)(0,n[e])(t)},function(e){for(r.status=`rejected`,r.reason=e,e=0;e<n.length;e++)(0,n[e])(void 0)}),r}var Sa=D.S;D.S=function(e,t){eu=Me(),typeof t==`object`&&t&&typeof t.then==`function`&&ya(e,t),Sa!==null&&Sa(e,t)};var Ca=fe(null);function wa(){var e=Ca.current;return e===null?K.pooledCache:e}function Ta(e,t){t===null?A(Ca,Ca.current):A(Ca,t.pool)}function Ea(){var e=wa();return e===null?null:{parent:P._currentValue,pool:e}}var Da=Error(i(460)),Oa=Error(i(474)),ka=Error(i(542)),Aa={then:function(){}};function ja(e){return e=e.status,e===`fulfilled`||e===`rejected`}function Ma(e,t,n){switch(n=e[n],n===void 0?e.push(t):n!==t&&(t.then(sn,sn),t=n),t.status){case`fulfilled`:return t.value;case`rejected`:throw e=t.reason,Ia(e),e;default:if(typeof t.status==`string`)t.then(sn,sn);else{if(e=K,e!==null&&100<e.shellSuspendCounter)throw Error(i(482));e=t,e.status=`pending`,e.then(function(e){if(t.status===`pending`){var n=t;n.status=`fulfilled`,n.value=e}},function(e){if(t.status===`pending`){var n=t;n.status=`rejected`,n.reason=e}})}switch(t.status){case`fulfilled`:return t.value;case`rejected`:throw e=t.reason,Ia(e),e}throw Pa=t,Da}}function Na(e){try{var t=e._init;return t(e._payload)}catch(e){throw typeof e==`object`&&e&&typeof e.then==`function`?(Pa=e,Da):e}}var Pa=null;function Fa(){if(Pa===null)throw Error(i(459));var e=Pa;return Pa=null,e}function Ia(e){if(e===Da||e===ka)throw Error(i(483))}var La=null,Ra=0;function za(e){var t=Ra;return Ra+=1,La===null&&(La=[]),Ma(La,e,t)}function Ba(e,t){t=t.props.ref,e.ref=t===void 0?null:t}function Va(e,t){throw t.$$typeof===g?Error(i(525)):(e=Object.prototype.toString.call(t),Error(i(31,e===`[object Object]`?`object with keys {`+Object.keys(t).join(`, `)+`}`:e)))}function Ha(e){function t(t,n){if(e){var r=t.deletions;r===null?(t.deletions=[n],t.flags|=16):r.push(n)}}function n(n,r){if(!e)return null;for(;r!==null;)t(n,r),r=r.sibling;return null}function r(e){for(var t=new Map;e!==null;)e.key===null?t.set(e.index,e):t.set(e.key,e),e=e.sibling;return t}function a(e,t){return e=_i(e,t),e.index=0,e.sibling=null,e}function o(t,n,r){return t.index=r,e?(r=t.alternate,r===null?(t.flags|=67108866,n):(r=r.index,r<n?(t.flags|=67108866,n):r)):(t.flags|=1048576,n)}function s(t){return e&&t.alternate===null&&(t.flags|=67108866),t}function c(e,t,n,r){return t===null||t.tag!==6?(t=xi(n,e.mode,r),t.return=e,t):(t=a(t,n),t.return=e,t)}function l(e,t,n,r){var i=n.type;return i===y?d(e,t,n.props.children,r,n.key):t!==null&&(t.elementType===i||typeof i==`object`&&i&&i.$$typeof===T&&Na(i)===t.type)?(t=a(t,n.props),Ba(t,n),t.return=e,t):(t=yi(n.type,n.key,n.props,null,e.mode,r),Ba(t,n),t.return=e,t)}function u(e,t,n,r){return t===null||t.tag!==4||t.stateNode.containerInfo!==n.containerInfo||t.stateNode.implementation!==n.implementation?(t=Ci(n,e.mode,r),t.return=e,t):(t=a(t,n.children||[]),t.return=e,t)}function d(e,t,n,r,i){return t===null||t.tag!==7?(t=bi(n,e.mode,r,i),t.return=e,t):(t=a(t,n),t.return=e,t)}function f(e,t,n){if(typeof t==`string`&&t!==``||typeof t==`number`||typeof t==`bigint`)return t=xi(``+t,e.mode,n),t.return=e,t;if(typeof t==`object`&&t){switch(t.$$typeof){case _:return n=yi(t.type,t.key,t.props,null,e.mode,n),Ba(n,t),n.return=e,n;case v:return t=Ci(t,e.mode,n),t.return=e,t;case T:return t=Na(t),f(e,t,n)}if(ce(t)||oe(t))return t=bi(t,e.mode,n,null),t.return=e,t;if(typeof t.then==`function`)return f(e,za(t),n);if(t.$$typeof===S)return f(e,ca(e,t),n);Va(e,t)}return null}function p(e,t,n,r){var i=t===null?null:t.key;if(typeof n==`string`&&n!==``||typeof n==`number`||typeof n==`bigint`)return i===null?c(e,t,``+n,r):null;if(typeof n==`object`&&n){switch(n.$$typeof){case _:return n.key===i?l(e,t,n,r):null;case v:return n.key===i?u(e,t,n,r):null;case T:return n=Na(n),p(e,t,n,r)}if(ce(n)||oe(n))return i===null?d(e,t,n,r,null):null;if(typeof n.then==`function`)return p(e,t,za(n),r);if(n.$$typeof===S)return p(e,t,ca(e,n),r);Va(e,n)}return null}function m(e,t,n,r,i){if(typeof r==`string`&&r!==``||typeof r==`number`||typeof r==`bigint`)return e=e.get(n)||null,c(t,e,``+r,i);if(typeof r==`object`&&r){switch(r.$$typeof){case _:return e=e.get(r.key===null?n:r.key)||null,l(t,e,r,i);case v:return e=e.get(r.key===null?n:r.key)||null,u(t,e,r,i);case T:return r=Na(r),m(e,t,n,r,i)}if(ce(r)||oe(r))return e=e.get(n)||null,d(t,e,r,i,null);if(typeof r.then==`function`)return m(e,t,n,za(r),i);if(r.$$typeof===S)return m(e,t,n,ca(t,r),i);Va(t,r)}return null}function h(i,a,s,c){for(var l=null,u=null,d=a,h=a=0,g=null;d!==null&&h<s.length;h++){d.index>h?(g=d,d=null):g=d.sibling;var _=p(i,d,s[h],c);if(_===null){d===null&&(d=g);break}e&&d&&_.alternate===null&&t(i,d),a=o(_,a,h),u===null?l=_:u.sibling=_,u=_,d=g}if(h===s.length)return n(i,d),N&&Fi(i,h),l;if(d===null){for(;h<s.length;h++)d=f(i,s[h],c),d!==null&&(a=o(d,a,h),u===null?l=d:u.sibling=d,u=d);return N&&Fi(i,h),l}for(d=r(d);h<s.length;h++)g=m(d,i,h,s[h],c),g!==null&&(e&&g.alternate!==null&&d.delete(g.key===null?h:g.key),a=o(g,a,h),u===null?l=g:u.sibling=g,u=g);return e&&d.forEach(function(e){return t(i,e)}),N&&Fi(i,h),l}function g(a,s,c,l){if(c==null)throw Error(i(151));for(var u=null,d=null,h=s,g=s=0,_=null,v=c.next();h!==null&&!v.done;g++,v=c.next()){h.index>g?(_=h,h=null):_=h.sibling;var y=p(a,h,v.value,l);if(y===null){h===null&&(h=_);break}e&&h&&y.alternate===null&&t(a,h),s=o(y,s,g),d===null?u=y:d.sibling=y,d=y,h=_}if(v.done)return n(a,h),N&&Fi(a,g),u;if(h===null){for(;!v.done;g++,v=c.next())v=f(a,v.value,l),v!==null&&(s=o(v,s,g),d===null?u=v:d.sibling=v,d=v);return N&&Fi(a,g),u}for(h=r(h);!v.done;g++,v=c.next())v=m(h,a,g,v.value,l),v!==null&&(e&&v.alternate!==null&&h.delete(v.key===null?g:v.key),s=o(v,s,g),d===null?u=v:d.sibling=v,d=v);return e&&h.forEach(function(e){return t(a,e)}),N&&Fi(a,g),u}function b(e,r,o,c){if(typeof o==`object`&&o&&o.type===y&&o.key===null&&(o=o.props.children),typeof o==`object`&&o){switch(o.$$typeof){case _:a:{for(var l=o.key;r!==null;){if(r.key===l){if(l=o.type,l===y){if(r.tag===7){n(e,r.sibling),c=a(r,o.props.children),c.return=e,e=c;break a}}else if(r.elementType===l||typeof l==`object`&&l&&l.$$typeof===T&&Na(l)===r.type){n(e,r.sibling),c=a(r,o.props),Ba(c,o),c.return=e,e=c;break a}n(e,r);break}t(e,r),r=r.sibling}o.type===y?(c=bi(o.props.children,e.mode,c,o.key),c.return=e,e=c):(c=yi(o.type,o.key,o.props,null,e.mode,c),Ba(c,o),c.return=e,e=c)}return s(e);case v:a:{for(l=o.key;r!==null;){if(r.key===l){if(r.tag===4&&r.stateNode.containerInfo===o.containerInfo&&r.stateNode.implementation===o.implementation){n(e,r.sibling),c=a(r,o.children||[]),c.return=e,e=c;break a}n(e,r);break}t(e,r),r=r.sibling}c=Ci(o,e.mode,c),c.return=e,e=c}return s(e);case T:return o=Na(o),b(e,r,o,c)}if(ce(o))return h(e,r,o,c);if(oe(o)){if(l=oe(o),typeof l!=`function`)throw Error(i(150));return o=l.call(o),g(e,r,o,c)}if(typeof o.then==`function`)return b(e,r,za(o),c);if(o.$$typeof===S)return b(e,r,ca(e,o),c);Va(e,o)}return typeof o==`string`&&o!==``||typeof o==`number`||typeof o==`bigint`?(o=``+o,r!==null&&r.tag===6?(n(e,r.sibling),c=a(r,o),c.return=e,e=c):(n(e,r),c=xi(o,e.mode,c),c.return=e,e=c),s(e)):n(e,r)}return function(e,t,n,r){try{Ra=0;var i=b(e,t,n,r);return La=null,i}catch(t){if(t===Da||t===ka)throw t;var a=hi(29,t,null,e.mode);return a.lanes=r,a.return=e,a}}}var Ua=Ha(!0),Wa=Ha(!1),Ga=!1;function Ka(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function qa(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function Ja(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function Ya(e,t,n){var r=e.updateQueue;if(r===null)return null;if(r=r.shared,G&2){var i=r.pending;return i===null?t.next=t:(t.next=i.next,i.next=t),r.pending=t,t=fi(e),di(e,null,n),t}return ci(e,r,t,n),fi(e)}function Xa(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,n&4194048)){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,ot(e,n)}}function Za(e,t){var n=e.updateQueue,r=e.alternate;if(r!==null&&(r=r.updateQueue,n===r)){var i=null,a=null;if(n=n.firstBaseUpdate,n!==null){do{var o={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};a===null?i=a=o:a=a.next=o,n=n.next}while(n!==null);a===null?i=a=t:a=a.next=t}else i=a=t;n={baseState:r.baseState,firstBaseUpdate:i,lastBaseUpdate:a,shared:r.shared,callbacks:r.callbacks},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}var Qa=!1;function $a(){if(Qa){var e=va;if(e!==null)throw e}}function eo(e,t,n,r){Qa=!1;var i=e.updateQueue;Ga=!1;var a=i.firstBaseUpdate,o=i.lastBaseUpdate,s=i.shared.pending;if(s!==null){i.shared.pending=null;var c=s,l=c.next;c.next=null,o===null?a=l:o.next=l,o=c;var u=e.alternate;u!==null&&(u=u.updateQueue,s=u.lastBaseUpdate,s!==o&&(s===null?u.firstBaseUpdate=l:s.next=l,u.lastBaseUpdate=c))}if(a!==null){var d=i.baseState;o=0,u=l=c=null,s=a;do{var f=s.lane&-536870913,p=f!==s.lane;if(p?(J&f)===f:(r&f)===f){f!==0&&f===_a&&(Qa=!0),u!==null&&(u=u.next={lane:0,tag:s.tag,payload:s.payload,callback:null,next:null});a:{var m=e,g=s;f=t;var _=n;switch(g.tag){case 1:if(m=g.payload,typeof m==`function`){d=m.call(_,d,f);break a}d=m;break a;case 3:m.flags=m.flags&-65537|128;case 0:if(m=g.payload,f=typeof m==`function`?m.call(_,d,f):m,f==null)break a;d=h({},d,f);break a;case 2:Ga=!0}}f=s.callback,f!==null&&(e.flags|=64,p&&(e.flags|=8192),p=i.callbacks,p===null?i.callbacks=[f]:p.push(f))}else p={lane:f,tag:s.tag,payload:s.payload,callback:s.callback,next:null},u===null?(l=u=p,c=d):u=u.next=p,o|=f;if(s=s.next,s===null){if(s=i.shared.pending,s===null)break;p=s,s=p.next,p.next=null,i.lastBaseUpdate=p,i.shared.pending=null}}while(1);u===null&&(c=d),i.baseState=c,i.firstBaseUpdate=l,i.lastBaseUpdate=u,a===null&&(i.shared.lanes=0),Gl|=o,e.lanes=o,e.memoizedState=d}}function to(e,t){if(typeof e!=`function`)throw Error(i(191,e));e.call(t)}function no(e,t){var n=e.callbacks;if(n!==null)for(e.callbacks=null,e=0;e<n.length;e++)to(n[e],t)}var ro=fe(null),io=fe(0);function ao(e,t){e=Wl,A(io,e),A(ro,t),Wl=e|t.baseLanes}function oo(){A(io,Wl),A(ro,ro.current)}function so(){Wl=io.current,k(ro),k(io)}var co=fe(null),lo=null;function uo(e){var t=e.alternate;A(F,F.current&1),A(co,e),lo===null&&(t===null||ro.current!==null||t.memoizedState!==null)&&(lo=e)}function fo(e){A(F,F.current),A(co,e),lo===null&&(lo=e)}function po(e){e.tag===22?(A(F,F.current),A(co,e),lo===null&&(lo=e)):mo(e)}function mo(){A(F,F.current),A(co,co.current)}function ho(e){k(co),lo===e&&(lo=null),k(F)}var F=fe(0);function go(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||af(n)||of(n)))return t}else if(t.tag===19&&(t.memoizedProps.revealOrder===`forwards`||t.memoizedProps.revealOrder===`backwards`||t.memoizedProps.revealOrder===`unstable_legacy-backwards`||t.memoizedProps.revealOrder===`together`)){if(t.flags&128)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var _o=0,I=null,L=null,R=null,vo=!1,yo=!1,bo=!1,xo=0,So=0,Co=null,wo=0;function z(){throw Error(i(321))}function To(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!kr(e[n],t[n]))return!1;return!0}function Eo(e,t,n,r,i,a){return _o=a,I=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,D.H=e===null||e.memoizedState===null?Hs:Us,bo=!1,a=n(r,i),bo=!1,yo&&(a=Oo(t,n,r,i)),Do(e),a}function Do(e){D.H=Vs;var t=L!==null&&L.next!==null;if(_o=0,R=L=I=null,vo=!1,So=0,Co=null,t)throw Error(i(300));e===null||V||(e=e.dependencies,e!==null&&aa(e)&&(V=!0))}function Oo(e,t,n,r){I=e;var a=0;do{if(yo&&(Co=null),So=0,yo=!1,25<=a)throw Error(i(301));if(a+=1,R=L=null,e.updateQueue!=null){var o=e.updateQueue;o.lastEffect=null,o.events=null,o.stores=null,o.memoCache!=null&&(o.memoCache.index=0)}D.H=Ws,o=t(n,r)}while(yo);return o}function ko(){var e=D.H,t=e.useState()[0];return t=typeof t.then==`function`?Fo(t):t,e=e.useState()[0],(L===null?null:L.memoizedState)!==e&&(I.flags|=1024),t}function Ao(){var e=xo!==0;return xo=0,e}function jo(e,t,n){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~n}function Mo(e){if(vo){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}vo=!1}_o=0,R=L=I=null,yo=!1,So=xo=0,Co=null}function No(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return R===null?I.memoizedState=R=e:R=R.next=e,R}function B(){if(L===null){var e=I.alternate;e=e===null?null:e.memoizedState}else e=L.next;var t=R===null?I.memoizedState:R.next;if(t!==null)R=t,L=e;else{if(e===null)throw I.alternate===null?Error(i(467)):Error(i(310));L=e,e={memoizedState:L.memoizedState,baseState:L.baseState,baseQueue:L.baseQueue,queue:L.queue,next:null},R===null?I.memoizedState=R=e:R=R.next=e}return R}function Po(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Fo(e){var t=So;return So+=1,Co===null&&(Co=[]),e=Ma(Co,e,t),t=I,(R===null?t.memoizedState:R.next)===null&&(t=t.alternate,D.H=t===null||t.memoizedState===null?Hs:Us),e}function Io(e){if(typeof e==`object`&&e){if(typeof e.then==`function`)return Fo(e);if(e.$$typeof===S)return sa(e)}throw Error(i(438,String(e)))}function Lo(e){var t=null,n=I.updateQueue;if(n!==null&&(t=n.memoCache),t==null){var r=I.alternate;r!==null&&(r=r.updateQueue,r!==null&&(r=r.memoCache,r!=null&&(t={data:r.data.map(function(e){return e.slice()}),index:0})))}if(t??={data:[],index:0},n===null&&(n=Po(),I.updateQueue=n),n.memoCache=t,n=t.data[t.index],n===void 0)for(n=t.data[t.index]=Array(e),r=0;r<e;r++)n[r]=ie;return t.index++,n}function Ro(e,t){return typeof t==`function`?t(e):t}function zo(e){return Bo(B(),L,e)}function Bo(e,t,n){var r=e.queue;if(r===null)throw Error(i(311));r.lastRenderedReducer=n;var a=e.baseQueue,o=r.pending;if(o!==null){if(a!==null){var s=a.next;a.next=o.next,o.next=s}t.baseQueue=a=o,r.pending=null}if(o=e.baseState,a===null)e.memoizedState=o;else{t=a.next;var c=s=null,l=null,u=t,d=!1;do{var f=u.lane&-536870913;if(f===u.lane?(_o&f)===f:(J&f)===f){var p=u.revertLane;if(p===0)l!==null&&(l=l.next={lane:0,revertLane:0,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null}),f===_a&&(d=!0);else if((_o&p)===p){u=u.next,p===_a&&(d=!0);continue}else f={lane:0,revertLane:u.revertLane,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},l===null?(c=l=f,s=o):l=l.next=f,I.lanes|=p,Gl|=p;f=u.action,bo&&n(o,f),o=u.hasEagerState?u.eagerState:n(o,f)}else p={lane:f,revertLane:u.revertLane,gesture:u.gesture,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},l===null?(c=l=p,s=o):l=l.next=p,I.lanes|=f,Gl|=f;u=u.next}while(u!==null&&u!==t);if(l===null?s=o:l.next=c,!kr(o,e.memoizedState)&&(V=!0,d&&(n=va,n!==null)))throw n;e.memoizedState=o,e.baseState=s,e.baseQueue=l,r.lastRenderedState=o}return a===null&&(r.lanes=0),[e.memoizedState,r.dispatch]}function Vo(e){var t=B(),n=t.queue;if(n===null)throw Error(i(311));n.lastRenderedReducer=e;var r=n.dispatch,a=n.pending,o=t.memoizedState;if(a!==null){n.pending=null;var s=a=a.next;do o=e(o,s.action),s=s.next;while(s!==a);kr(o,t.memoizedState)||(V=!0),t.memoizedState=o,t.baseQueue===null&&(t.baseState=o),n.lastRenderedState=o}return[o,r]}function Ho(e,t,n){var r=I,a=B(),o=N;if(o){if(n===void 0)throw Error(i(407));n=n()}else n=t();var s=!kr((L||a).memoizedState,n);if(s&&(a.memoizedState=n,V=!0),a=a.queue,ps(Go.bind(null,r,a,e),[e]),a.getSnapshot!==t||s||R!==null&&R.memoizedState.tag&1){if(r.flags|=2048,cs(9,{destroy:void 0},Wo.bind(null,r,a,n,t),null),K===null)throw Error(i(349));o||_o&127||Uo(r,t,n)}return n}function Uo(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=I.updateQueue,t===null?(t=Po(),I.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function Wo(e,t,n,r){t.value=n,t.getSnapshot=r,Ko(t)&&qo(e)}function Go(e,t,n){return n(function(){Ko(t)&&qo(e)})}function Ko(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!kr(e,n)}catch{return!0}}function qo(e){var t=ui(e,2);t!==null&&hu(t,e,2)}function Jo(e){var t=No();if(typeof e==`function`){var n=e;if(e=n(),bo){Ue(!0);try{n()}finally{Ue(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ro,lastRenderedState:e},t}function Yo(e,t,n,r){return e.baseState=n,Bo(e,L,typeof r==`function`?r:Ro)}function Xo(e,t,n,r,a){if(Rs(e))throw Error(i(485));if(e=t.action,e!==null){var o={payload:a,action:e,next:null,isTransition:!0,status:`pending`,value:null,reason:null,listeners:[],then:function(e){o.listeners.push(e)}};D.T===null?o.isTransition=!1:n(!0),r(o),n=t.pending,n===null?(o.next=t.pending=o,Zo(t,o)):(o.next=n.next,t.pending=n.next=o)}}function Zo(e,t){var n=t.action,r=t.payload,i=e.state;if(t.isTransition){var a=D.T,o={};D.T=o;try{var s=n(i,r),c=D.S;c!==null&&c(o,s),Qo(e,t,s)}catch(n){es(e,t,n)}finally{a!==null&&o.types!==null&&(a.types=o.types),D.T=a}}else try{a=n(i,r),Qo(e,t,a)}catch(n){es(e,t,n)}}function Qo(e,t,n){typeof n==`object`&&n&&typeof n.then==`function`?n.then(function(n){$o(e,t,n)},function(n){return es(e,t,n)}):$o(e,t,n)}function $o(e,t,n){t.status=`fulfilled`,t.value=n,ts(t),e.state=n,t=e.pending,t!==null&&(n=t.next,n===t?e.pending=null:(n=n.next,t.next=n,Zo(e,n)))}function es(e,t,n){var r=e.pending;if(e.pending=null,r!==null){r=r.next;do t.status=`rejected`,t.reason=n,ts(t),t=t.next;while(t!==r)}e.action=null}function ts(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function ns(e,t){return t}function rs(e,t){if(N){var n=K.formState;if(n!==null){a:{var r=I;if(N){if(M){b:{for(var i=M,a=Hi;i.nodeType!==8;){if(!a){i=null;break b}if(i=cf(i.nextSibling),i===null){i=null;break b}}a=i.data,i=a===`F!`||a===`F`?i:null}if(i){M=cf(i.nextSibling),r=i.data===`F!`;break a}}Wi(r)}r=!1}r&&(t=n[0])}}return n=No(),n.memoizedState=n.baseState=t,r={pending:null,lanes:0,dispatch:null,lastRenderedReducer:ns,lastRenderedState:t},n.queue=r,n=Fs.bind(null,I,r),r.dispatch=n,r=Jo(!1),a=Ls.bind(null,I,!1,r.queue),r=No(),i={state:t,dispatch:null,action:e,pending:null},r.queue=i,n=Xo.bind(null,I,i,a,n),i.dispatch=n,r.memoizedState=e,[t,n,!1]}function is(e){return as(B(),L,e)}function as(e,t,n){if(t=Bo(e,t,ns)[0],e=zo(Ro)[0],typeof t==`object`&&t&&typeof t.then==`function`)try{var r=Fo(t)}catch(e){throw e===Da?ka:e}else r=t;t=B();var i=t.queue,a=i.dispatch;return n!==t.memoizedState&&(I.flags|=2048,cs(9,{destroy:void 0},os.bind(null,i,n),null)),[r,a,e]}function os(e,t){e.action=t}function ss(e){var t=B(),n=L;if(n!==null)return as(t,n,e);B(),t=t.memoizedState,n=B();var r=n.queue.dispatch;return n.memoizedState=e,[t,r,!1]}function cs(e,t,n,r){return e={tag:e,create:n,deps:r,inst:t,next:null},t=I.updateQueue,t===null&&(t=Po(),I.updateQueue=t),n=t.lastEffect,n===null?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e),e}function ls(){return B().memoizedState}function us(e,t,n,r){var i=No();I.flags|=e,i.memoizedState=cs(1|t,{destroy:void 0},n,r===void 0?null:r)}function ds(e,t,n,r){var i=B();r=r===void 0?null:r;var a=i.memoizedState.inst;L!==null&&r!==null&&To(r,L.memoizedState.deps)?i.memoizedState=cs(t,a,n,r):(I.flags|=e,i.memoizedState=cs(1|t,a,n,r))}function fs(e,t){us(8390656,8,e,t)}function ps(e,t){ds(2048,8,e,t)}function ms(e){I.flags|=4;var t=I.updateQueue;if(t===null)t=Po(),I.updateQueue=t,t.events=[e];else{var n=t.events;n===null?t.events=[e]:n.push(e)}}function hs(e){var t=B().memoizedState;return ms({ref:t,nextImpl:e}),function(){if(G&2)throw Error(i(440));return t.impl.apply(void 0,arguments)}}function gs(e,t){return ds(4,2,e,t)}function _s(e,t){return ds(4,4,e,t)}function vs(e,t){if(typeof t==`function`){e=e();var n=t(e);return function(){typeof n==`function`?n():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function ys(e,t,n){n=n==null?null:n.concat([e]),ds(4,4,vs.bind(null,t,e),n)}function bs(){}function xs(e,t){var n=B();t=t===void 0?null:t;var r=n.memoizedState;return t!==null&&To(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function Ss(e,t){var n=B();t=t===void 0?null:t;var r=n.memoizedState;if(t!==null&&To(t,r[1]))return r[0];if(r=e(),bo){Ue(!0);try{e()}finally{Ue(!1)}}return n.memoizedState=[r,t],r}function Cs(e,t,n){return n===void 0||_o&1073741824&&!(J&261930)?e.memoizedState=t:(e.memoizedState=n,e=mu(),I.lanes|=e,Gl|=e,n)}function ws(e,t,n,r){return kr(n,t)?n:ro.current===null?!(_o&42)||_o&1073741824&&!(J&261930)?(V=!0,e.memoizedState=n):(e=mu(),I.lanes|=e,Gl|=e,t):(e=Cs(e,n,r),kr(e,t)||(V=!0),e)}function Ts(e,t,n,r,i){var a=O.p;O.p=a!==0&&8>a?a:8;var o=D.T,s={};D.T=s,Ls(e,!1,t,n);try{var c=i(),l=D.S;l!==null&&l(s,c),typeof c==`object`&&c&&typeof c.then==`function`?Is(e,t,xa(c,r),pu(e)):Is(e,t,r,pu(e))}catch(n){Is(e,t,{then:function(){},status:`rejected`,reason:n},pu())}finally{O.p=a,o!==null&&s.types!==null&&(o.types=s.types),D.T=o}}function Es(){}function Ds(e,t,n,r){if(e.tag!==5)throw Error(i(476));var a=Os(e).queue;Ts(e,a,t,le,n===null?Es:function(){return ks(e),n(r)})}function Os(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:le,baseState:le,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ro,lastRenderedState:le},next:null};var n={};return t.next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ro,lastRenderedState:n},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function ks(e){var t=Os(e);t.next===null&&(t=e.alternate.memoizedState),Is(e,t.next.queue,{},pu())}function As(){return sa(Qf)}function js(){return B().memoizedState}function Ms(){return B().memoizedState}function Ns(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var n=pu();e=Ja(n);var r=Ya(t,e,n);r!==null&&(hu(r,t,n),Xa(r,t,n)),t={cache:pa()},e.payload=t;return}t=t.return}}function Ps(e,t,n){var r=pu();n={lane:r,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},Rs(e)?zs(t,n):(n=li(e,t,n,r),n!==null&&(hu(n,e,r),Bs(n,t,r)))}function Fs(e,t,n){Is(e,t,n,pu())}function Is(e,t,n,r){var i={lane:r,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};if(Rs(e))zs(t,i);else{var a=e.alternate;if(e.lanes===0&&(a===null||a.lanes===0)&&(a=t.lastRenderedReducer,a!==null))try{var o=t.lastRenderedState,s=a(o,n);if(i.hasEagerState=!0,i.eagerState=s,kr(s,o))return ci(e,t,i,0),K===null&&si(),!1}catch{}if(n=li(e,t,i,r),n!==null)return hu(n,e,r),Bs(n,t,r),!0}return!1}function Ls(e,t,n,r){if(r={lane:2,revertLane:dd(),gesture:null,action:r,hasEagerState:!1,eagerState:null,next:null},Rs(e)){if(t)throw Error(i(479))}else t=li(e,n,r,2),t!==null&&hu(t,e,2)}function Rs(e){var t=e.alternate;return e===I||t!==null&&t===I}function zs(e,t){yo=vo=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function Bs(e,t,n){if(n&4194048){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,ot(e,n)}}var Vs={readContext:sa,use:Io,useCallback:z,useContext:z,useEffect:z,useImperativeHandle:z,useLayoutEffect:z,useInsertionEffect:z,useMemo:z,useReducer:z,useRef:z,useState:z,useDebugValue:z,useDeferredValue:z,useTransition:z,useSyncExternalStore:z,useId:z,useHostTransitionStatus:z,useFormState:z,useActionState:z,useOptimistic:z,useMemoCache:z,useCacheRefresh:z};Vs.useEffectEvent=z;var Hs={readContext:sa,use:Io,useCallback:function(e,t){return No().memoizedState=[e,t===void 0?null:t],e},useContext:sa,useEffect:fs,useImperativeHandle:function(e,t,n){n=n==null?null:n.concat([e]),us(4194308,4,vs.bind(null,t,e),n)},useLayoutEffect:function(e,t){return us(4194308,4,e,t)},useInsertionEffect:function(e,t){us(4,2,e,t)},useMemo:function(e,t){var n=No();t=t===void 0?null:t;var r=e();if(bo){Ue(!0);try{e()}finally{Ue(!1)}}return n.memoizedState=[r,t],r},useReducer:function(e,t,n){var r=No();if(n!==void 0){var i=n(t);if(bo){Ue(!0);try{n(t)}finally{Ue(!1)}}}else i=t;return r.memoizedState=r.baseState=i,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:i},r.queue=e,e=e.dispatch=Ps.bind(null,I,e),[r.memoizedState,e]},useRef:function(e){var t=No();return e={current:e},t.memoizedState=e},useState:function(e){e=Jo(e);var t=e.queue,n=Fs.bind(null,I,t);return t.dispatch=n,[e.memoizedState,n]},useDebugValue:bs,useDeferredValue:function(e,t){return Cs(No(),e,t)},useTransition:function(){var e=Jo(!1);return e=Ts.bind(null,I,e.queue,!0,!1),No().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,n){var r=I,a=No();if(N){if(n===void 0)throw Error(i(407));n=n()}else{if(n=t(),K===null)throw Error(i(349));J&127||Uo(r,t,n)}a.memoizedState=n;var o={value:n,getSnapshot:t};return a.queue=o,fs(Go.bind(null,r,o,e),[e]),r.flags|=2048,cs(9,{destroy:void 0},Wo.bind(null,r,o,n,t),null),n},useId:function(){var e=No(),t=K.identifierPrefix;if(N){var n=Pi,r=Ni;n=(r&~(1<<32-We(r)-1)).toString(32)+n,t=`_`+t+`R_`+n,n=xo++,0<n&&(t+=`H`+n.toString(32)),t+=`_`}else n=wo++,t=`_`+t+`r_`+n.toString(32)+`_`;return e.memoizedState=t},useHostTransitionStatus:As,useFormState:rs,useActionState:rs,useOptimistic:function(e){var t=No();t.memoizedState=t.baseState=e;var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=n,t=Ls.bind(null,I,!0,n),n.dispatch=t,[e,t]},useMemoCache:Lo,useCacheRefresh:function(){return No().memoizedState=Ns.bind(null,I)},useEffectEvent:function(e){var t=No(),n={impl:e};return t.memoizedState=n,function(){if(G&2)throw Error(i(440));return n.impl.apply(void 0,arguments)}}},Us={readContext:sa,use:Io,useCallback:xs,useContext:sa,useEffect:ps,useImperativeHandle:ys,useInsertionEffect:gs,useLayoutEffect:_s,useMemo:Ss,useReducer:zo,useRef:ls,useState:function(){return zo(Ro)},useDebugValue:bs,useDeferredValue:function(e,t){return ws(B(),L.memoizedState,e,t)},useTransition:function(){var e=zo(Ro)[0],t=B().memoizedState;return[typeof e==`boolean`?e:Fo(e),t]},useSyncExternalStore:Ho,useId:js,useHostTransitionStatus:As,useFormState:is,useActionState:is,useOptimistic:function(e,t){return Yo(B(),L,e,t)},useMemoCache:Lo,useCacheRefresh:Ms};Us.useEffectEvent=hs;var Ws={readContext:sa,use:Io,useCallback:xs,useContext:sa,useEffect:ps,useImperativeHandle:ys,useInsertionEffect:gs,useLayoutEffect:_s,useMemo:Ss,useReducer:Vo,useRef:ls,useState:function(){return Vo(Ro)},useDebugValue:bs,useDeferredValue:function(e,t){var n=B();return L===null?Cs(n,e,t):ws(n,L.memoizedState,e,t)},useTransition:function(){var e=Vo(Ro)[0],t=B().memoizedState;return[typeof e==`boolean`?e:Fo(e),t]},useSyncExternalStore:Ho,useId:js,useHostTransitionStatus:As,useFormState:ss,useActionState:ss,useOptimistic:function(e,t){var n=B();return L===null?(n.baseState=e,[e,n.queue.dispatch]):Yo(n,L,e,t)},useMemoCache:Lo,useCacheRefresh:Ms};Ws.useEffectEvent=hs;function Gs(e,t,n,r){t=e.memoizedState,n=n(r,t),n=n==null?t:h({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var Ks={enqueueSetState:function(e,t,n){e=e._reactInternals;var r=pu(),i=Ja(r);i.payload=t,n!=null&&(i.callback=n),t=Ya(e,i,r),t!==null&&(hu(t,e,r),Xa(t,e,r))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=pu(),i=Ja(r);i.tag=1,i.payload=t,n!=null&&(i.callback=n),t=Ya(e,i,r),t!==null&&(hu(t,e,r),Xa(t,e,r))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=pu(),r=Ja(n);r.tag=2,t!=null&&(r.callback=t),t=Ya(e,r,n),t!==null&&(hu(t,e,n),Xa(t,e,n))}};function qs(e,t,n,r,i,a,o){return e=e.stateNode,typeof e.shouldComponentUpdate==`function`?e.shouldComponentUpdate(r,a,o):t.prototype&&t.prototype.isPureReactComponent?!Ar(n,r)||!Ar(i,a):!0}function Js(e,t,n,r){e=t.state,typeof t.componentWillReceiveProps==`function`&&t.componentWillReceiveProps(n,r),typeof t.UNSAFE_componentWillReceiveProps==`function`&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&Ks.enqueueReplaceState(t,t.state,null)}function Ys(e,t){var n=t;if(`ref`in t)for(var r in n={},t)r!==`ref`&&(n[r]=t[r]);if(e=e.defaultProps)for(var i in n===t&&(n=h({},n)),e)n[i]===void 0&&(n[i]=e[i]);return n}function Xs(e){ri(e)}function Zs(e){console.error(e)}function Qs(e){ri(e)}function $s(e,t){try{var n=e.onUncaughtError;n(t.value,{componentStack:t.stack})}catch(e){setTimeout(function(){throw e})}}function ec(e,t,n){try{var r=e.onCaughtError;r(n.value,{componentStack:n.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(e){setTimeout(function(){throw e})}}function tc(e,t,n){return n=Ja(n),n.tag=3,n.payload={element:null},n.callback=function(){$s(e,t)},n}function nc(e){return e=Ja(e),e.tag=3,e}function rc(e,t,n,r){var i=n.type.getDerivedStateFromError;if(typeof i==`function`){var a=r.value;e.payload=function(){return i(a)},e.callback=function(){ec(t,n,r)}}var o=n.stateNode;o!==null&&typeof o.componentDidCatch==`function`&&(e.callback=function(){ec(t,n,r),typeof i!=`function`&&(ru===null?ru=new Set([this]):ru.add(this));var e=r.stack;this.componentDidCatch(r.value,{componentStack:e===null?``:e})})}function ic(e,t,n,r,a){if(n.flags|=32768,typeof r==`object`&&r&&typeof r.then==`function`){if(t=n.alternate,t!==null&&ia(t,n,a,!0),n=co.current,n!==null){switch(n.tag){case 31:case 13:return lo===null?Du():n.alternate===null&&X===0&&(X=3),n.flags&=-257,n.flags|=65536,n.lanes=a,r===Aa?n.flags|=16384:(t=n.updateQueue,t===null?n.updateQueue=new Set([r]):t.add(r),Gu(e,r,a)),!1;case 22:return n.flags|=65536,r===Aa?n.flags|=16384:(t=n.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([r])},n.updateQueue=t):(n=t.retryQueue,n===null?t.retryQueue=new Set([r]):n.add(r)),Gu(e,r,a)),!1}throw Error(i(435,n.tag))}return Gu(e,r,a),Du(),!1}if(N)return t=co.current,t===null?(r!==Ui&&(t=Error(i(423),{cause:r}),Xi(Ti(t,n))),e=e.current.alternate,e.flags|=65536,a&=-a,e.lanes|=a,r=Ti(r,n),a=tc(e.stateNode,r,a),Za(e,a),X!==4&&(X=2)):(!(t.flags&65536)&&(t.flags|=256),t.flags|=65536,t.lanes=a,r!==Ui&&(e=Error(i(422),{cause:r}),Xi(Ti(e,n)))),!1;var o=Error(i(520),{cause:r});if(o=Ti(o,n),Xl===null?Xl=[o]:Xl.push(o),X!==4&&(X=2),t===null)return!0;r=Ti(r,n),n=t;do{switch(n.tag){case 3:return n.flags|=65536,e=a&-a,n.lanes|=e,e=tc(n.stateNode,r,e),Za(n,e),!1;case 1:if(t=n.type,o=n.stateNode,!(n.flags&128)&&(typeof t.getDerivedStateFromError==`function`||o!==null&&typeof o.componentDidCatch==`function`&&(ru===null||!ru.has(o))))return n.flags|=65536,a&=-a,n.lanes|=a,a=nc(a),rc(a,e,n,r),Za(n,a),!1}n=n.return}while(n!==null);return!1}var ac=Error(i(461)),V=!1;function oc(e,t,n,r){t.child=e===null?Wa(t,null,n,r):Ua(t,e.child,n,r)}function sc(e,t,n,r,i){n=n.render;var a=t.ref;if(`ref`in r){var o={};for(var s in r)s!==`ref`&&(o[s]=r[s])}else o=r;return oa(t),r=Eo(e,t,n,o,a,i),s=Ao(),e!==null&&!V?(jo(e,t,i),jc(e,t,i)):(N&&s&&Li(t),t.flags|=1,oc(e,t,r,i),t.child)}function cc(e,t,n,r,i){if(e===null){var a=n.type;return typeof a==`function`&&!gi(a)&&a.defaultProps===void 0&&n.compare===null?(t.tag=15,t.type=a,lc(e,t,a,r,i)):(e=yi(n.type,null,r,t,t.mode,i),e.ref=t.ref,e.return=t,t.child=e)}if(a=e.child,!Mc(e,i)){var o=a.memoizedProps;if(n=n.compare,n=n===null?Ar:n,n(o,r)&&e.ref===t.ref)return jc(e,t,i)}return t.flags|=1,e=_i(a,r),e.ref=t.ref,e.return=t,t.child=e}function lc(e,t,n,r,i){if(e!==null){var a=e.memoizedProps;if(Ar(a,r)&&e.ref===t.ref){if(V=!1,t.pendingProps=r=a,Mc(e,i))e.flags&131072&&(V=!0);else return t.lanes=e.lanes,jc(e,t,i)}}return _c(e,t,n,r,i)}function uc(e,t,n,r){var i=r.children,a=e===null?null:e.memoizedState;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),r.mode===`hidden`){if(t.flags&128){if(a=a===null?n:a.baseLanes|n,e!==null){for(r=t.child=e.child,i=0;r!==null;)i=i|r.lanes|r.childLanes,r=r.sibling;r=i&~a}else r=0,t.child=null;return fc(e,t,a,n,r)}if(n&536870912)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&Ta(t,a===null?null:a.cachePool),a===null?oo():ao(t,a),po(t);else return r=t.lanes=536870912,fc(e,t,a===null?n:a.baseLanes|n,n,r)}else a===null?(e!==null&&Ta(t,null),oo(),mo(t)):(Ta(t,a.cachePool),ao(t,a),mo(t),t.memoizedState=null);return oc(e,t,i,n),t.child}function dc(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function fc(e,t,n,r,i){var a=wa();return a=a===null?null:{parent:P._currentValue,pool:a},t.memoizedState={baseLanes:n,cachePool:a},e!==null&&Ta(t,null),oo(),po(t),e!==null&&ia(e,t,r,!0),t.childLanes=i,null}function pc(e,t){return t=Ec({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function mc(e,t,n){return Ua(t,e.child,null,n),e=pc(t,t.pendingProps),e.flags|=2,ho(t),t.memoizedState=null,e}function hc(e,t,n){var r=t.pendingProps,a=!!(t.flags&128);if(t.flags&=-129,e===null){if(N){if(r.mode===`hidden`)return e=pc(t,r),t.lanes=536870912,dc(null,e);if(fo(t),(e=M)?(e=rf(e,Hi),e=e!==null&&e.data===`&`?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:Mi===null?null:{id:Ni,overflow:Pi},retryLane:536870912,hydrationErrors:null},n=Si(e),n.return=t,t.child=n,Bi=t,M=null)):e=null,e===null)throw Wi(t);return t.lanes=536870912,null}return pc(t,r)}var o=e.memoizedState;if(o!==null){var s=o.dehydrated;if(fo(t),a){if(t.flags&256)t.flags&=-257,t=mc(e,t,n);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(i(558))}else if(V||ia(e,t,n,!1),a=(n&e.childLanes)!==0,V||a){if(r=K,r!==null&&(s=st(r,n),s!==0&&s!==o.retryLane))throw o.retryLane=s,ui(e,s),hu(r,e,s),ac;Du(),t=mc(e,t,n)}else e=o.treeContext,M=cf(s.nextSibling),Bi=t,N=!0,Vi=null,Hi=!1,e!==null&&zi(t,e),t=pc(t,r),t.flags|=4096;return t}return e=_i(e.child,{mode:r.mode,children:r.children}),e.ref=t.ref,t.child=e,e.return=t,e}function gc(e,t){var n=t.ref;if(n===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof n!=`function`&&typeof n!=`object`)throw Error(i(284));(e===null||e.ref!==n)&&(t.flags|=4194816)}}function _c(e,t,n,r,i){return oa(t),n=Eo(e,t,n,r,void 0,i),r=Ao(),e!==null&&!V?(jo(e,t,i),jc(e,t,i)):(N&&r&&Li(t),t.flags|=1,oc(e,t,n,i),t.child)}function vc(e,t,n,r,i,a){return oa(t),t.updateQueue=null,n=Oo(t,r,n,i),Do(e),r=Ao(),e!==null&&!V?(jo(e,t,a),jc(e,t,a)):(N&&r&&Li(t),t.flags|=1,oc(e,t,n,a),t.child)}function yc(e,t,n,r,i){if(oa(t),t.stateNode===null){var a=pi,o=n.contextType;typeof o==`object`&&o&&(a=sa(o)),a=new n(r,a),t.memoizedState=a.state!==null&&a.state!==void 0?a.state:null,a.updater=Ks,t.stateNode=a,a._reactInternals=t,a=t.stateNode,a.props=r,a.state=t.memoizedState,a.refs={},Ka(t),o=n.contextType,a.context=typeof o==`object`&&o?sa(o):pi,a.state=t.memoizedState,o=n.getDerivedStateFromProps,typeof o==`function`&&(Gs(t,n,o,r),a.state=t.memoizedState),typeof n.getDerivedStateFromProps==`function`||typeof a.getSnapshotBeforeUpdate==`function`||typeof a.UNSAFE_componentWillMount!=`function`&&typeof a.componentWillMount!=`function`||(o=a.state,typeof a.componentWillMount==`function`&&a.componentWillMount(),typeof a.UNSAFE_componentWillMount==`function`&&a.UNSAFE_componentWillMount(),o!==a.state&&Ks.enqueueReplaceState(a,a.state,null),eo(t,r,a,i),$a(),a.state=t.memoizedState),typeof a.componentDidMount==`function`&&(t.flags|=4194308),r=!0}else if(e===null){a=t.stateNode;var s=t.memoizedProps,c=Ys(n,s);a.props=c;var l=a.context,u=n.contextType;o=pi,typeof u==`object`&&u&&(o=sa(u));var d=n.getDerivedStateFromProps;u=typeof d==`function`||typeof a.getSnapshotBeforeUpdate==`function`,s=t.pendingProps!==s,u||typeof a.UNSAFE_componentWillReceiveProps!=`function`&&typeof a.componentWillReceiveProps!=`function`||(s||l!==o)&&Js(t,a,r,o),Ga=!1;var f=t.memoizedState;a.state=f,eo(t,r,a,i),$a(),l=t.memoizedState,s||f!==l||Ga?(typeof d==`function`&&(Gs(t,n,d,r),l=t.memoizedState),(c=Ga||qs(t,n,c,r,f,l,o))?(u||typeof a.UNSAFE_componentWillMount!=`function`&&typeof a.componentWillMount!=`function`||(typeof a.componentWillMount==`function`&&a.componentWillMount(),typeof a.UNSAFE_componentWillMount==`function`&&a.UNSAFE_componentWillMount()),typeof a.componentDidMount==`function`&&(t.flags|=4194308)):(typeof a.componentDidMount==`function`&&(t.flags|=4194308),t.memoizedProps=r,t.memoizedState=l),a.props=r,a.state=l,a.context=o,r=c):(typeof a.componentDidMount==`function`&&(t.flags|=4194308),r=!1)}else{a=t.stateNode,qa(e,t),o=t.memoizedProps,u=Ys(n,o),a.props=u,d=t.pendingProps,f=a.context,l=n.contextType,c=pi,typeof l==`object`&&l&&(c=sa(l)),s=n.getDerivedStateFromProps,(l=typeof s==`function`||typeof a.getSnapshotBeforeUpdate==`function`)||typeof a.UNSAFE_componentWillReceiveProps!=`function`&&typeof a.componentWillReceiveProps!=`function`||(o!==d||f!==c)&&Js(t,a,r,c),Ga=!1,f=t.memoizedState,a.state=f,eo(t,r,a,i),$a();var p=t.memoizedState;o!==d||f!==p||Ga||e!==null&&e.dependencies!==null&&aa(e.dependencies)?(typeof s==`function`&&(Gs(t,n,s,r),p=t.memoizedState),(u=Ga||qs(t,n,u,r,f,p,c)||e!==null&&e.dependencies!==null&&aa(e.dependencies))?(l||typeof a.UNSAFE_componentWillUpdate!=`function`&&typeof a.componentWillUpdate!=`function`||(typeof a.componentWillUpdate==`function`&&a.componentWillUpdate(r,p,c),typeof a.UNSAFE_componentWillUpdate==`function`&&a.UNSAFE_componentWillUpdate(r,p,c)),typeof a.componentDidUpdate==`function`&&(t.flags|=4),typeof a.getSnapshotBeforeUpdate==`function`&&(t.flags|=1024)):(typeof a.componentDidUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=p),a.props=r,a.state=p,a.context=c,r=u):(typeof a.componentDidUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),r=!1)}return a=r,gc(e,t),r=!!(t.flags&128),a||r?(a=t.stateNode,n=r&&typeof n.getDerivedStateFromError!=`function`?null:a.render(),t.flags|=1,e!==null&&r?(t.child=Ua(t,e.child,null,i),t.child=Ua(t,null,n,i)):oc(e,t,n,i),t.memoizedState=a.state,e=t.child):e=jc(e,t,i),e}function bc(e,t,n,r){return Ji(),t.flags|=256,oc(e,t,n,r),t.child}var xc={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Sc(e){return{baseLanes:e,cachePool:Ea()}}function Cc(e,t,n){return e=e===null?0:e.childLanes&~n,t&&(e|=Jl),e}function wc(e,t,n){var r=t.pendingProps,a=!1,o=!!(t.flags&128),s;if((s=o)||(s=e!==null&&e.memoizedState===null?!1:!!(F.current&2)),s&&(a=!0,t.flags&=-129),s=!!(t.flags&32),t.flags&=-33,e===null){if(N){if(a?uo(t):mo(t),(e=M)?(e=rf(e,Hi),e=e!==null&&e.data!==`&`?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:Mi===null?null:{id:Ni,overflow:Pi},retryLane:536870912,hydrationErrors:null},n=Si(e),n.return=t,t.child=n,Bi=t,M=null)):e=null,e===null)throw Wi(t);return of(e)?t.lanes=32:t.lanes=536870912,null}var c=r.children;return r=r.fallback,a?(mo(t),a=t.mode,c=Ec({mode:`hidden`,children:c},a),r=bi(r,a,n,null),c.return=t,r.return=t,c.sibling=r,t.child=c,r=t.child,r.memoizedState=Sc(n),r.childLanes=Cc(e,s,n),t.memoizedState=xc,dc(null,r)):(uo(t),Tc(t,c))}var l=e.memoizedState;if(l!==null&&(c=l.dehydrated,c!==null)){if(o)t.flags&256?(uo(t),t.flags&=-257,t=Dc(e,t,n)):t.memoizedState===null?(mo(t),c=r.fallback,a=t.mode,r=Ec({mode:`visible`,children:r.children},a),c=bi(c,a,n,null),c.flags|=2,r.return=t,c.return=t,r.sibling=c,t.child=r,Ua(t,e.child,null,n),r=t.child,r.memoizedState=Sc(n),r.childLanes=Cc(e,s,n),t.memoizedState=xc,t=dc(null,r)):(mo(t),t.child=e.child,t.flags|=128,t=null);else if(uo(t),of(c)){if(s=c.nextSibling&&c.nextSibling.dataset,s)var u=s.dgst;s=u,r=Error(i(419)),r.stack=``,r.digest=s,Xi({value:r,source:null,stack:null}),t=Dc(e,t,n)}else if(V||ia(e,t,n,!1),s=(n&e.childLanes)!==0,V||s){if(s=K,s!==null&&(r=st(s,n),r!==0&&r!==l.retryLane))throw l.retryLane=r,ui(e,r),hu(s,e,r),ac;af(c)||Du(),t=Dc(e,t,n)}else af(c)?(t.flags|=192,t.child=e.child,t=null):(e=l.treeContext,M=cf(c.nextSibling),Bi=t,N=!0,Vi=null,Hi=!1,e!==null&&zi(t,e),t=Tc(t,r.children),t.flags|=4096);return t}return a?(mo(t),c=r.fallback,a=t.mode,l=e.child,u=l.sibling,r=_i(l,{mode:`hidden`,children:r.children}),r.subtreeFlags=l.subtreeFlags&65011712,u===null?(c=bi(c,a,n,null),c.flags|=2):c=_i(u,c),c.return=t,r.return=t,r.sibling=c,t.child=r,dc(null,r),r=t.child,c=e.child.memoizedState,c===null?c=Sc(n):(a=c.cachePool,a===null?a=Ea():(l=P._currentValue,a=a.parent===l?a:{parent:l,pool:l}),c={baseLanes:c.baseLanes|n,cachePool:a}),r.memoizedState=c,r.childLanes=Cc(e,s,n),t.memoizedState=xc,dc(e.child,r)):(uo(t),n=e.child,e=n.sibling,n=_i(n,{mode:`visible`,children:r.children}),n.return=t,n.sibling=null,e!==null&&(s=t.deletions,s===null?(t.deletions=[e],t.flags|=16):s.push(e)),t.child=n,t.memoizedState=null,n)}function Tc(e,t){return t=Ec({mode:`visible`,children:t},e.mode),t.return=e,e.child=t}function Ec(e,t){return e=hi(22,e,null,t),e.lanes=0,e}function Dc(e,t,n){return Ua(t,e.child,null,n),e=Tc(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function Oc(e,t,n){e.lanes|=t;var r=e.alternate;r!==null&&(r.lanes|=t),na(e.return,t,n)}function kc(e,t,n,r,i,a){var o=e.memoizedState;o===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:i,treeForkCount:a}:(o.isBackwards=t,o.rendering=null,o.renderingStartTime=0,o.last=r,o.tail=n,o.tailMode=i,o.treeForkCount=a)}function Ac(e,t,n){var r=t.pendingProps,i=r.revealOrder,a=r.tail;r=r.children;var o=F.current,s=!!(o&2);if(s?(o=o&1|2,t.flags|=128):o&=1,A(F,o),oc(e,t,r,n),r=N?ki:0,!s&&e!==null&&e.flags&128)a:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Oc(e,n,t);else if(e.tag===19)Oc(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break a;for(;e.sibling===null;){if(e.return===null||e.return===t)break a;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(i){case`forwards`:for(n=t.child,i=null;n!==null;)e=n.alternate,e!==null&&go(e)===null&&(i=n),n=n.sibling;n=i,n===null?(i=t.child,t.child=null):(i=n.sibling,n.sibling=null),kc(t,!1,i,n,a,r);break;case`backwards`:case`unstable_legacy-backwards`:for(n=null,i=t.child,t.child=null;i!==null;){if(e=i.alternate,e!==null&&go(e)===null){t.child=i;break}e=i.sibling,i.sibling=n,n=i,i=e}kc(t,!0,n,null,a,r);break;case`together`:kc(t,!1,null,null,void 0,r);break;default:t.memoizedState=null}return t.child}function jc(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),Gl|=t.lanes,(n&t.childLanes)===0){if(e!==null){if(ia(e,t,n,!1),(n&t.childLanes)===0)return null}else return null}if(e!==null&&t.child!==e.child)throw Error(i(153));if(t.child!==null){for(e=t.child,n=_i(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=_i(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function Mc(e,t){return(e.lanes&t)!==0||(e=e.dependencies,!!(e!==null&&aa(e)))}function Nc(e,t,n){switch(t.tag){case 3:_e(t,t.stateNode.containerInfo),ea(t,P,e.memoizedState.cache),Ji();break;case 27:case 5:ye(t);break;case 4:_e(t,t.stateNode.containerInfo);break;case 10:ea(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,fo(t),null;break;case 13:var r=t.memoizedState;if(r!==null)return r.dehydrated===null?(n&t.child.childLanes)===0?(uo(t),e=jc(e,t,n),e===null?null:e.sibling):wc(e,t,n):(uo(t),t.flags|=128,null);uo(t);break;case 19:var i=!!(e.flags&128);if(r=(n&t.childLanes)!==0,r||=(ia(e,t,n,!1),(n&t.childLanes)!==0),i){if(r)return Ac(e,t,n);t.flags|=128}if(i=t.memoizedState,i!==null&&(i.rendering=null,i.tail=null,i.lastEffect=null),A(F,F.current),r)break;return null;case 22:return t.lanes=0,uc(e,t,n,t.pendingProps);case 24:ea(t,P,e.memoizedState.cache)}return jc(e,t,n)}function Pc(e,t,n){if(e!==null){if(e.memoizedProps!==t.pendingProps)V=!0;else{if(!Mc(e,n)&&!(t.flags&128))return V=!1,Nc(e,t,n);V=!!(e.flags&131072)}}else V=!1,N&&t.flags&1048576&&Ii(t,ki,t.index);switch(t.lanes=0,t.tag){case 16:a:{var r=t.pendingProps;if(e=Na(t.elementType),t.type=e,typeof e==`function`)gi(e)?(r=Ys(e,r),t.tag=1,t=yc(null,t,e,r,n)):(t.tag=0,t=_c(null,t,e,r,n));else{if(e!=null){var a=e.$$typeof;if(a===C){t.tag=11,t=sc(null,t,e,r,n);break a}if(a===ne){t.tag=14,t=cc(null,t,e,r,n);break a}}throw t=E(e)||e,Error(i(306,t,``))}}return t;case 0:return _c(e,t,t.type,t.pendingProps,n);case 1:return r=t.type,a=Ys(r,t.pendingProps),yc(e,t,r,a,n);case 3:a:{if(_e(t,t.stateNode.containerInfo),e===null)throw Error(i(387));r=t.pendingProps;var o=t.memoizedState;a=o.element,qa(e,t),eo(t,r,null,n);var s=t.memoizedState;if(r=s.cache,ea(t,P,r),r!==o.cache&&ra(t,[P],n,!0),$a(),r=s.element,o.isDehydrated){if(o={element:r,isDehydrated:!1,cache:s.cache},t.updateQueue.baseState=o,t.memoizedState=o,t.flags&256){t=bc(e,t,r,n);break a}if(r!==a){a=Ti(Error(i(424)),t),Xi(a),t=bc(e,t,r,n);break a}switch(e=t.stateNode.containerInfo,e.nodeType){case 9:e=e.body;break;default:e=e.nodeName===`HTML`?e.ownerDocument.body:e}for(M=cf(e.firstChild),Bi=t,N=!0,Vi=null,Hi=!0,n=Wa(t,null,r,n),t.child=n;n;)n.flags=n.flags&-3|4096,n=n.sibling}else{if(Ji(),r===a){t=jc(e,t,n);break a}oc(e,t,r,n)}t=t.child}return t;case 26:return gc(e,t),e===null?(n=kf(t.type,null,t.pendingProps,null))?t.memoizedState=n:N||(n=t.type,e=t.pendingProps,r=Bd(he.current).createElement(n),r[pt]=t,r[mt]=e,Pd(r,n,e),Et(r),t.stateNode=r):t.memoizedState=kf(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return ye(t),e===null&&N&&(r=t.stateNode=ff(t.type,t.pendingProps,he.current),Bi=t,Hi=!0,a=M,Zd(t.type)?(lf=a,M=cf(r.firstChild)):M=a),oc(e,t,t.pendingProps.children,n),gc(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&N&&((a=r=M)&&(r=tf(r,t.type,t.pendingProps,Hi),r===null?a=!1:(t.stateNode=r,Bi=t,M=cf(r.firstChild),Hi=!1,a=!0)),a||Wi(t)),ye(t),a=t.type,o=t.pendingProps,s=e===null?null:e.memoizedProps,r=o.children,Ud(a,o)?r=null:s!==null&&Ud(a,s)&&(t.flags|=32),t.memoizedState!==null&&(a=Eo(e,t,ko,null,null,n),Qf._currentValue=a),gc(e,t),oc(e,t,r,n),t.child;case 6:return e===null&&N&&((e=n=M)&&(n=nf(n,t.pendingProps,Hi),n===null?e=!1:(t.stateNode=n,Bi=t,M=null,e=!0)),e||Wi(t)),null;case 13:return wc(e,t,n);case 4:return _e(t,t.stateNode.containerInfo),r=t.pendingProps,e===null?t.child=Ua(t,null,r,n):oc(e,t,r,n),t.child;case 11:return sc(e,t,t.type,t.pendingProps,n);case 7:return oc(e,t,t.pendingProps,n),t.child;case 8:return oc(e,t,t.pendingProps.children,n),t.child;case 12:return oc(e,t,t.pendingProps.children,n),t.child;case 10:return r=t.pendingProps,ea(t,t.type,r.value),oc(e,t,r.children,n),t.child;case 9:return a=t.type._context,r=t.pendingProps.children,oa(t),a=sa(a),r=r(a),t.flags|=1,oc(e,t,r,n),t.child;case 14:return cc(e,t,t.type,t.pendingProps,n);case 15:return lc(e,t,t.type,t.pendingProps,n);case 19:return Ac(e,t,n);case 31:return hc(e,t,n);case 22:return uc(e,t,n,t.pendingProps);case 24:return oa(t),r=sa(P),e===null?(a=wa(),a===null&&(a=K,o=pa(),a.pooledCache=o,o.refCount++,o!==null&&(a.pooledCacheLanes|=n),a=o),t.memoizedState={parent:r,cache:a},Ka(t),ea(t,P,a)):((e.lanes&n)!==0&&(qa(e,t),eo(t,null,null,n),$a()),a=e.memoizedState,o=t.memoizedState,a.parent===r?(r=o.cache,ea(t,P,r),r!==a.cache&&ra(t,[P],n,!0)):(a={parent:r,cache:r},t.memoizedState=a,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=a),ea(t,P,r))),oc(e,t,t.pendingProps.children,n),t.child;case 29:throw t.pendingProps}throw Error(i(156,t.tag))}function Fc(e){e.flags|=4}function Ic(e,t,n,r,i){if((t=!!(e.mode&32))&&(t=!1),t){if(e.flags|=16777216,(i&335544128)===i){if(e.stateNode.complete)e.flags|=8192;else if(wu())e.flags|=8192;else throw Pa=Aa,Oa}}else e.flags&=-16777217}function Lc(e,t){if(t.type!==`stylesheet`||t.state.loading&4)e.flags&=-16777217;else if(e.flags|=16777216,!Wf(t)){if(wu())e.flags|=8192;else throw Pa=Aa,Oa}}function Rc(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag===22?536870912:tt(),e.lanes|=t,Yl|=t)}function zc(e,t){if(!N)switch(e.tailMode){case`hidden`:t=e.tail;for(var n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null;break;case`collapsed`:n=e.tail;for(var r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:r.sibling=null}}function H(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,r=0;if(t)for(var i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags&65011712,r|=i.flags&65011712,i.return=e,i=i.sibling;else for(i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags,r|=i.flags,i.return=e,i=i.sibling;return e.subtreeFlags|=r,e.childLanes=n,t}function Bc(e,t,n){var r=t.pendingProps;switch(Ri(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return H(t),null;case 1:return H(t),null;case 3:return n=t.stateNode,r=null,e!==null&&(r=e.memoizedState.cache),t.memoizedState.cache!==r&&(t.flags|=2048),ta(P),ve(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(e===null||e.child===null)&&(qi(t)?Fc(t):e===null||e.memoizedState.isDehydrated&&!(t.flags&256)||(t.flags|=1024,Yi())),H(t),null;case 26:var a=t.type,o=t.memoizedState;return e===null?(Fc(t),o===null?(H(t),Ic(t,a,null,r,n)):(H(t),Lc(t,o))):o?o===e.memoizedState?(H(t),t.flags&=-16777217):(Fc(t),H(t),Lc(t,o)):(e=e.memoizedProps,e!==r&&Fc(t),H(t),Ic(t,a,e,r,n)),null;case 27:if(be(t),n=he.current,a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==r&&Fc(t);else{if(!r){if(t.stateNode===null)throw Error(i(166));return H(t),null}e=pe.current,qi(t)?Gi(t,e):(e=ff(a,r,n),t.stateNode=e,Fc(t))}return H(t),null;case 5:if(be(t),a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==r&&Fc(t);else{if(!r){if(t.stateNode===null)throw Error(i(166));return H(t),null}if(o=pe.current,qi(t))Gi(t,o);else{var s=Bd(he.current);switch(o){case 1:o=s.createElementNS(`http://www.w3.org/2000/svg`,a);break;case 2:o=s.createElementNS(`http://www.w3.org/1998/Math/MathML`,a);break;default:switch(a){case`svg`:o=s.createElementNS(`http://www.w3.org/2000/svg`,a);break;case`math`:o=s.createElementNS(`http://www.w3.org/1998/Math/MathML`,a);break;case`script`:o=s.createElement(`div`),o.innerHTML=`<script><\/script>`,o=o.removeChild(o.firstChild);break;case`select`:o=typeof r.is==`string`?s.createElement(`select`,{is:r.is}):s.createElement(`select`),r.multiple?o.multiple=!0:r.size&&(o.size=r.size);break;default:o=typeof r.is==`string`?s.createElement(a,{is:r.is}):s.createElement(a)}}o[pt]=t,o[mt]=r;a:for(s=t.child;s!==null;){if(s.tag===5||s.tag===6)o.appendChild(s.stateNode);else if(s.tag!==4&&s.tag!==27&&s.child!==null){s.child.return=s,s=s.child;continue}if(s===t)break a;for(;s.sibling===null;){if(s.return===null||s.return===t)break a;s=s.return}s.sibling.return=s.return,s=s.sibling}t.stateNode=o;a:switch(Pd(o,a,r),a){case`button`:case`input`:case`select`:case`textarea`:r=!!r.autoFocus;break a;case`img`:r=!0;break a;default:r=!1}r&&Fc(t)}}return H(t),Ic(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,n),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==r&&Fc(t);else{if(typeof r!=`string`&&t.stateNode===null)throw Error(i(166));if(e=he.current,qi(t)){if(e=t.stateNode,n=t.memoizedProps,r=null,a=Bi,a!==null)switch(a.tag){case 27:case 5:r=a.memoizedProps}e[pt]=t,e=!!(e.nodeValue===n||r!==null&&!0===r.suppressHydrationWarning||Md(e.nodeValue,n)),e||Wi(t,!0)}else e=Bd(e).createTextNode(r),e[pt]=t,t.stateNode=e}return H(t),null;case 31:if(n=t.memoizedState,e===null||e.memoizedState!==null){if(r=qi(t),n!==null){if(e===null){if(!r)throw Error(i(318));if(e=t.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(i(557));e[pt]=t}else Ji(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;H(t),e=!1}else n=Yi(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=n),e=!0;if(!e)return t.flags&256?(ho(t),t):(ho(t),null);if(t.flags&128)throw Error(i(558))}return H(t),null;case 13:if(r=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(a=qi(t),r!==null&&r.dehydrated!==null){if(e===null){if(!a)throw Error(i(318));if(a=t.memoizedState,a=a===null?null:a.dehydrated,!a)throw Error(i(317));a[pt]=t}else Ji(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;H(t),a=!1}else a=Yi(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=a),a=!0;if(!a)return t.flags&256?(ho(t),t):(ho(t),null)}return ho(t),t.flags&128?(t.lanes=n,t):(n=r!==null,e=e!==null&&e.memoizedState!==null,n&&(r=t.child,a=null,r.alternate!==null&&r.alternate.memoizedState!==null&&r.alternate.memoizedState.cachePool!==null&&(a=r.alternate.memoizedState.cachePool.pool),o=null,r.memoizedState!==null&&r.memoizedState.cachePool!==null&&(o=r.memoizedState.cachePool.pool),o!==a&&(r.flags|=2048)),n!==e&&n&&(t.child.flags|=8192),Rc(t,t.updateQueue),H(t),null);case 4:return ve(),e===null&&Sd(t.stateNode.containerInfo),H(t),null;case 10:return ta(t.type),H(t),null;case 19:if(k(F),r=t.memoizedState,r===null)return H(t),null;if(a=!!(t.flags&128),o=r.rendering,o===null){if(a)zc(r,!1);else{if(X!==0||e!==null&&e.flags&128)for(e=t.child;e!==null;){if(o=go(e),o!==null){for(t.flags|=128,zc(r,!1),e=o.updateQueue,t.updateQueue=e,Rc(t,e),t.subtreeFlags=0,e=n,n=t.child;n!==null;)vi(n,e),n=n.sibling;return A(F,F.current&1|2),N&&Fi(t,r.treeForkCount),t.child}e=e.sibling}r.tail!==null&&Me()>tu&&(t.flags|=128,a=!0,zc(r,!1),t.lanes=4194304)}}else{if(!a){if(e=go(o),e!==null){if(t.flags|=128,a=!0,e=e.updateQueue,t.updateQueue=e,Rc(t,e),zc(r,!0),r.tail===null&&r.tailMode===`hidden`&&!o.alternate&&!N)return H(t),null}else 2*Me()-r.renderingStartTime>tu&&n!==536870912&&(t.flags|=128,a=!0,zc(r,!1),t.lanes=4194304)}r.isBackwards?(o.sibling=t.child,t.child=o):(e=r.last,e===null?t.child=o:e.sibling=o,r.last=o)}return r.tail===null?(H(t),null):(e=r.tail,r.rendering=e,r.tail=e.sibling,r.renderingStartTime=Me(),e.sibling=null,n=F.current,A(F,a?n&1|2:n&1),N&&Fi(t,r.treeForkCount),e);case 22:case 23:return ho(t),so(),r=t.memoizedState!==null,e===null?r&&(t.flags|=8192):e.memoizedState!==null!==r&&(t.flags|=8192),r?n&536870912&&!(t.flags&128)&&(H(t),t.subtreeFlags&6&&(t.flags|=8192)):H(t),n=t.updateQueue,n!==null&&Rc(t,n.retryQueue),n=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),r=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(r=t.memoizedState.cachePool.pool),r!==n&&(t.flags|=2048),e!==null&&k(Ca),null;case 24:return n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),ta(P),H(t),null;case 25:return null;case 30:return null}throw Error(i(156,t.tag))}function Vc(e,t){switch(Ri(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return ta(P),ve(),e=t.flags,e&65536&&!(e&128)?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return be(t),null;case 31:if(t.memoizedState!==null){if(ho(t),t.alternate===null)throw Error(i(340));Ji()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(ho(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(i(340));Ji()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return k(F),null;case 4:return ve(),null;case 10:return ta(t.type),null;case 22:case 23:return ho(t),so(),e!==null&&k(Ca),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return ta(P),null;case 25:return null;default:return null}}function Hc(e,t){switch(Ri(t),t.tag){case 3:ta(P),ve();break;case 26:case 27:case 5:be(t);break;case 4:ve();break;case 31:t.memoizedState!==null&&ho(t);break;case 13:ho(t);break;case 19:k(F);break;case 10:ta(t.type);break;case 22:case 23:ho(t),so(),e!==null&&k(Ca);break;case 24:ta(P)}}function Uc(e,t){try{var n=t.updateQueue,r=n===null?null:n.lastEffect;if(r!==null){var i=r.next;n=i;do{if((n.tag&e)===e){r=void 0;var a=n.create,o=n.inst;r=a(),o.destroy=r}n=n.next}while(n!==i)}}catch(e){Z(t,t.return,e)}}function Wc(e,t,n){try{var r=t.updateQueue,i=r===null?null:r.lastEffect;if(i!==null){var a=i.next;r=a;do{if((r.tag&e)===e){var o=r.inst,s=o.destroy;if(s!==void 0){o.destroy=void 0,i=t;var c=n,l=s;try{l()}catch(e){Z(i,c,e)}}}r=r.next}while(r!==a)}}catch(e){Z(t,t.return,e)}}function Gc(e){var t=e.updateQueue;if(t!==null){var n=e.stateNode;try{no(t,n)}catch(t){Z(e,e.return,t)}}}function Kc(e,t,n){n.props=Ys(e.type,e.memoizedProps),n.state=e.memoizedState;try{n.componentWillUnmount()}catch(n){Z(e,t,n)}}function qc(e,t){try{var n=e.ref;if(n!==null){switch(e.tag){case 26:case 27:case 5:var r=e.stateNode;break;case 30:r=e.stateNode;break;default:r=e.stateNode}typeof n==`function`?e.refCleanup=n(r):n.current=r}}catch(n){Z(e,t,n)}}function Jc(e,t){var n=e.ref,r=e.refCleanup;if(n!==null){if(typeof r==`function`)try{r()}catch(n){Z(e,t,n)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof n==`function`)try{n(null)}catch(n){Z(e,t,n)}else n.current=null}}function Yc(e){var t=e.type,n=e.memoizedProps,r=e.stateNode;try{a:switch(t){case`button`:case`input`:case`select`:case`textarea`:n.autoFocus&&r.focus();break a;case`img`:n.src?r.src=n.src:n.srcSet&&(r.srcset=n.srcSet)}}catch(t){Z(e,e.return,t)}}function Xc(e,t,n){try{var r=e.stateNode;Fd(r,e.type,n,t),r[mt]=t}catch(t){Z(e,e.return,t)}}function Zc(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Zd(e.type)||e.tag===4}function Qc(e){a:for(;;){for(;e.sibling===null;){if(e.return===null||Zc(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Zd(e.type)||e.flags&2||e.child===null||e.tag===4)continue a;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function $c(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?(n.nodeType===9?n.body:n.nodeName===`HTML`?n.ownerDocument.body:n).insertBefore(e,t):(t=n.nodeType===9?n.body:n.nodeName===`HTML`?n.ownerDocument.body:n,t.appendChild(e),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=sn));else if(r!==4&&(r===27&&Zd(e.type)&&(n=e.stateNode,t=null),e=e.child,e!==null))for($c(e,t,n),e=e.sibling;e!==null;)$c(e,t,n),e=e.sibling}function el(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.insertBefore(e,t):n.appendChild(e);else if(r!==4&&(r===27&&Zd(e.type)&&(n=e.stateNode),e=e.child,e!==null))for(el(e,t,n),e=e.sibling;e!==null;)el(e,t,n),e=e.sibling}function tl(e){var t=e.stateNode,n=e.memoizedProps;try{for(var r=e.type,i=t.attributes;i.length;)t.removeAttributeNode(i[0]);Pd(t,r,n),t[pt]=e,t[mt]=n}catch(t){Z(e,e.return,t)}}var nl=!1,U=!1,rl=!1,il=typeof WeakSet==`function`?WeakSet:Set,al=null;function ol(e,t){if(e=e.containerInfo,Rd=sp,e=Pr(e),Fr(e)){if(`selectionStart`in e)var n={start:e.selectionStart,end:e.selectionEnd};else a:{n=(n=e.ownerDocument)&&n.defaultView||window;var r=n.getSelection&&n.getSelection();if(r&&r.rangeCount!==0){n=r.anchorNode;var a=r.anchorOffset,o=r.focusNode;r=r.focusOffset;try{n.nodeType,o.nodeType}catch{n=null;break a}var s=0,c=-1,l=-1,u=0,d=0,f=e,p=null;b:for(;;){for(var m;f!==n||a!==0&&f.nodeType!==3||(c=s+a),f!==o||r!==0&&f.nodeType!==3||(l=s+r),f.nodeType===3&&(s+=f.nodeValue.length),(m=f.firstChild)!==null;)p=f,f=m;for(;;){if(f===e)break b;if(p===n&&++u===a&&(c=s),p===o&&++d===r&&(l=s),(m=f.nextSibling)!==null)break;f=p,p=f.parentNode}f=m}n=c===-1||l===-1?null:{start:c,end:l}}else n=null}n||={start:0,end:0}}else n=null;for(zd={focusedElem:e,selectionRange:n},sp=!1,al=t;al!==null;)if(t=al,e=t.child,t.subtreeFlags&1028&&e!==null)e.return=t,al=e;else for(;al!==null;){switch(t=al,o=t.alternate,e=t.flags,t.tag){case 0:if(e&4&&(e=t.updateQueue,e=e===null?null:e.events,e!==null))for(n=0;n<e.length;n++)a=e[n],a.ref.impl=a.nextImpl;break;case 11:case 15:break;case 1:if(e&1024&&o!==null){e=void 0,n=t,a=o.memoizedProps,o=o.memoizedState,r=n.stateNode;try{var h=Ys(n.type,a);e=r.getSnapshotBeforeUpdate(h,o),r.__reactInternalSnapshotBeforeUpdate=e}catch(e){Z(n,n.return,e)}}break;case 3:if(e&1024){if(e=t.stateNode.containerInfo,n=e.nodeType,n===9)ef(e);else if(n===1)switch(e.nodeName){case`HEAD`:case`HTML`:case`BODY`:ef(e);break;default:e.textContent=``}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if(e&1024)throw Error(i(163))}if(e=t.sibling,e!==null){e.return=t.return,al=e;break}al=t.return}}function sl(e,t,n){var r=n.flags;switch(n.tag){case 0:case 11:case 15:xl(e,n),r&4&&Uc(5,n);break;case 1:if(xl(e,n),r&4){if(e=n.stateNode,t===null)try{e.componentDidMount()}catch(e){Z(n,n.return,e)}else{var i=Ys(n.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(i,t,e.__reactInternalSnapshotBeforeUpdate)}catch(e){Z(n,n.return,e)}}}r&64&&Gc(n),r&512&&qc(n,n.return);break;case 3:if(xl(e,n),r&64&&(e=n.updateQueue,e!==null)){if(t=null,n.child!==null)switch(n.child.tag){case 27:case 5:t=n.child.stateNode;break;case 1:t=n.child.stateNode}try{no(e,t)}catch(e){Z(n,n.return,e)}}break;case 27:t===null&&r&4&&tl(n);case 26:case 5:xl(e,n),t===null&&r&4&&Yc(n),r&512&&qc(n,n.return);break;case 12:xl(e,n);break;case 31:xl(e,n),r&4&&fl(e,n);break;case 13:xl(e,n),r&4&&pl(e,n),r&64&&(e=n.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(n=Ju.bind(null,n),sf(e,n))));break;case 22:if(r=n.memoizedState!==null||nl,!r){t=t!==null&&t.memoizedState!==null||U,i=nl;var a=U;nl=r,(U=t)&&!a?Cl(e,n,!!(n.subtreeFlags&8772)):xl(e,n),nl=i,U=a}break;case 30:break;default:xl(e,n)}}function cl(e){var t=e.alternate;t!==null&&(e.alternate=null,cl(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&xt(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var W=null,ll=!1;function ul(e,t,n){for(n=n.child;n!==null;)dl(e,t,n),n=n.sibling}function dl(e,t,n){if(He&&typeof He.onCommitFiberUnmount==`function`)try{He.onCommitFiberUnmount(Ve,n)}catch{}switch(n.tag){case 26:U||Jc(n,t),ul(e,t,n),n.memoizedState?n.memoizedState.count--:n.stateNode&&(n=n.stateNode,n.parentNode.removeChild(n));break;case 27:U||Jc(n,t);var r=W,i=ll;Zd(n.type)&&(W=n.stateNode,ll=!1),ul(e,t,n),pf(n.stateNode),W=r,ll=i;break;case 5:U||Jc(n,t);case 6:if(r=W,i=ll,W=null,ul(e,t,n),W=r,ll=i,W!==null){if(ll)try{(W.nodeType===9?W.body:W.nodeName===`HTML`?W.ownerDocument.body:W).removeChild(n.stateNode)}catch(e){Z(n,t,e)}else try{W.removeChild(n.stateNode)}catch(e){Z(n,t,e)}}break;case 18:W!==null&&(ll?(e=W,Qd(e.nodeType===9?e.body:e.nodeName===`HTML`?e.ownerDocument.body:e,n.stateNode),Np(e)):Qd(W,n.stateNode));break;case 4:r=W,i=ll,W=n.stateNode.containerInfo,ll=!0,ul(e,t,n),W=r,ll=i;break;case 0:case 11:case 14:case 15:Wc(2,n,t),U||Wc(4,n,t),ul(e,t,n);break;case 1:U||(Jc(n,t),r=n.stateNode,typeof r.componentWillUnmount==`function`&&Kc(n,t,r)),ul(e,t,n);break;case 21:ul(e,t,n);break;case 22:U=(r=U)||n.memoizedState!==null,ul(e,t,n),U=r;break;default:ul(e,t,n)}}function fl(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{Np(e)}catch(e){Z(t,t.return,e)}}}function pl(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{Np(e)}catch(e){Z(t,t.return,e)}}function ml(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new il),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new il),t;default:throw Error(i(435,e.tag))}}function hl(e,t){var n=ml(e);t.forEach(function(t){if(!n.has(t)){n.add(t);var r=Yu.bind(null,e,t);t.then(r,r)}})}function gl(e,t){var n=t.deletions;if(n!==null)for(var r=0;r<n.length;r++){var a=n[r],o=e,s=t,c=s;a:for(;c!==null;){switch(c.tag){case 27:if(Zd(c.type)){W=c.stateNode,ll=!1;break a}break;case 5:W=c.stateNode,ll=!1;break a;case 3:case 4:W=c.stateNode.containerInfo,ll=!0;break a}c=c.return}if(W===null)throw Error(i(160));dl(o,s,a),W=null,ll=!1,o=a.alternate,o!==null&&(o.return=null),a.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)vl(t,e),t=t.sibling}var _l=null;function vl(e,t){var n=e.alternate,r=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:gl(t,e),yl(e),r&4&&(Wc(3,e,e.return),Uc(3,e),Wc(5,e,e.return));break;case 1:gl(t,e),yl(e),r&512&&(U||n===null||Jc(n,n.return)),r&64&&nl&&(e=e.updateQueue,e!==null&&(r=e.callbacks,r!==null&&(n=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=n===null?r:n.concat(r))));break;case 26:var a=_l;if(gl(t,e),yl(e),r&512&&(U||n===null||Jc(n,n.return)),r&4){var o=n===null?null:n.memoizedState;if(r=e.memoizedState,n===null){if(r===null){if(e.stateNode===null){a:{r=e.type,n=e.memoizedProps,a=a.ownerDocument||a;b:switch(r){case`title`:o=a.getElementsByTagName(`title`)[0],(!o||o[bt]||o[pt]||o.namespaceURI===`http://www.w3.org/2000/svg`||o.hasAttribute(`itemprop`))&&(o=a.createElement(r),a.head.insertBefore(o,a.querySelector(`head > title`))),Pd(o,r,n),o[pt]=e,Et(o),r=o;break a;case`link`:var s=Vf(`link`,`href`,a).get(r+(n.href||``));if(s){for(var c=0;c<s.length;c++)if(o=s[c],o.getAttribute(`href`)===(n.href==null||n.href===``?null:n.href)&&o.getAttribute(`rel`)===(n.rel==null?null:n.rel)&&o.getAttribute(`title`)===(n.title==null?null:n.title)&&o.getAttribute(`crossorigin`)===(n.crossOrigin==null?null:n.crossOrigin)){s.splice(c,1);break b}}o=a.createElement(r),Pd(o,r,n),a.head.appendChild(o);break;case`meta`:if(s=Vf(`meta`,`content`,a).get(r+(n.content||``))){for(c=0;c<s.length;c++)if(o=s[c],o.getAttribute(`content`)===(n.content==null?null:``+n.content)&&o.getAttribute(`name`)===(n.name==null?null:n.name)&&o.getAttribute(`property`)===(n.property==null?null:n.property)&&o.getAttribute(`http-equiv`)===(n.httpEquiv==null?null:n.httpEquiv)&&o.getAttribute(`charset`)===(n.charSet==null?null:n.charSet)){s.splice(c,1);break b}}o=a.createElement(r),Pd(o,r,n),a.head.appendChild(o);break;default:throw Error(i(468,r))}o[pt]=e,Et(o),r=o}e.stateNode=r}else Hf(a,e.type,e.stateNode)}else e.stateNode=If(a,r,e.memoizedProps)}else o===r?r===null&&e.stateNode!==null&&Xc(e,e.memoizedProps,n.memoizedProps):(o===null?n.stateNode!==null&&(n=n.stateNode,n.parentNode.removeChild(n)):o.count--,r===null?Hf(a,e.type,e.stateNode):If(a,r,e.memoizedProps))}break;case 27:gl(t,e),yl(e),r&512&&(U||n===null||Jc(n,n.return)),n!==null&&r&4&&Xc(e,e.memoizedProps,n.memoizedProps);break;case 5:if(gl(t,e),yl(e),r&512&&(U||n===null||Jc(n,n.return)),e.flags&32){a=e.stateNode;try{Qt(a,``)}catch(t){Z(e,e.return,t)}}r&4&&e.stateNode!=null&&(a=e.memoizedProps,Xc(e,a,n===null?a:n.memoizedProps)),r&1024&&(rl=!0);break;case 6:if(gl(t,e),yl(e),r&4){if(e.stateNode===null)throw Error(i(162));r=e.memoizedProps,n=e.stateNode;try{n.nodeValue=r}catch(t){Z(e,e.return,t)}}break;case 3:if(Bf=null,a=_l,_l=gf(t.containerInfo),gl(t,e),_l=a,yl(e),r&4&&n!==null&&n.memoizedState.isDehydrated)try{Np(t.containerInfo)}catch(t){Z(e,e.return,t)}rl&&(rl=!1,bl(e));break;case 4:r=_l,_l=gf(e.stateNode.containerInfo),gl(t,e),yl(e),_l=r;break;case 12:gl(t,e),yl(e);break;case 31:gl(t,e),yl(e),r&4&&(r=e.updateQueue,r!==null&&(e.updateQueue=null,hl(e,r)));break;case 13:gl(t,e),yl(e),e.child.flags&8192&&e.memoizedState!==null!=(n!==null&&n.memoizedState!==null)&&($l=Me()),r&4&&(r=e.updateQueue,r!==null&&(e.updateQueue=null,hl(e,r)));break;case 22:a=e.memoizedState!==null;var l=n!==null&&n.memoizedState!==null,u=nl,d=U;if(nl=u||a,U=d||l,gl(t,e),U=d,nl=u,yl(e),r&8192)a:for(t=e.stateNode,t._visibility=a?t._visibility&-2:t._visibility|1,a&&(n===null||l||nl||U||Sl(e)),n=null,t=e;;){if(t.tag===5||t.tag===26){if(n===null){l=n=t;try{if(o=l.stateNode,a)s=o.style,typeof s.setProperty==`function`?s.setProperty(`display`,`none`,`important`):s.display=`none`;else{c=l.stateNode;var f=l.memoizedProps.style,p=f!=null&&f.hasOwnProperty(`display`)?f.display:null;c.style.display=p==null||typeof p==`boolean`?``:(``+p).trim()}}catch(e){Z(l,l.return,e)}}}else if(t.tag===6){if(n===null){l=t;try{l.stateNode.nodeValue=a?``:l.memoizedProps}catch(e){Z(l,l.return,e)}}}else if(t.tag===18){if(n===null){l=t;try{var m=l.stateNode;a?$d(m,!0):$d(l.stateNode,!1)}catch(e){Z(l,l.return,e)}}}else if((t.tag!==22&&t.tag!==23||t.memoizedState===null||t===e)&&t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break a;for(;t.sibling===null;){if(t.return===null||t.return===e)break a;n===t&&(n=null),t=t.return}n===t&&(n=null),t.sibling.return=t.return,t=t.sibling}r&4&&(r=e.updateQueue,r!==null&&(n=r.retryQueue,n!==null&&(r.retryQueue=null,hl(e,n))));break;case 19:gl(t,e),yl(e),r&4&&(r=e.updateQueue,r!==null&&(e.updateQueue=null,hl(e,r)));break;case 30:break;case 21:break;default:gl(t,e),yl(e)}}function yl(e){var t=e.flags;if(t&2){try{for(var n,r=e.return;r!==null;){if(Zc(r)){n=r;break}r=r.return}if(n==null)throw Error(i(160));switch(n.tag){case 27:var a=n.stateNode;el(e,Qc(e),a);break;case 5:var o=n.stateNode;n.flags&32&&(Qt(o,``),n.flags&=-33),el(e,Qc(e),o);break;case 3:case 4:var s=n.stateNode.containerInfo;$c(e,Qc(e),s);break;default:throw Error(i(161))}}catch(t){Z(e,e.return,t)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function bl(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;bl(t),t.tag===5&&t.flags&1024&&t.stateNode.reset(),e=e.sibling}}function xl(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)sl(e,t.alternate,t),t=t.sibling}function Sl(e){for(e=e.child;e!==null;){var t=e;switch(t.tag){case 0:case 11:case 14:case 15:Wc(4,t,t.return),Sl(t);break;case 1:Jc(t,t.return);var n=t.stateNode;typeof n.componentWillUnmount==`function`&&Kc(t,t.return,n),Sl(t);break;case 27:pf(t.stateNode);case 26:case 5:Jc(t,t.return),Sl(t);break;case 22:t.memoizedState===null&&Sl(t);break;case 30:Sl(t);break;default:Sl(t)}e=e.sibling}}function Cl(e,t,n){for(n&&=!!(t.subtreeFlags&8772),t=t.child;t!==null;){var r=t.alternate,i=e,a=t,o=a.flags;switch(a.tag){case 0:case 11:case 15:Cl(i,a,n),Uc(4,a);break;case 1:if(Cl(i,a,n),r=a,i=r.stateNode,typeof i.componentDidMount==`function`)try{i.componentDidMount()}catch(e){Z(r,r.return,e)}if(r=a,i=r.updateQueue,i!==null){var s=r.stateNode;try{var c=i.shared.hiddenCallbacks;if(c!==null)for(i.shared.hiddenCallbacks=null,i=0;i<c.length;i++)to(c[i],s)}catch(e){Z(r,r.return,e)}}n&&o&64&&Gc(a),qc(a,a.return);break;case 27:tl(a);case 26:case 5:Cl(i,a,n),n&&r===null&&o&4&&Yc(a),qc(a,a.return);break;case 12:Cl(i,a,n);break;case 31:Cl(i,a,n),n&&o&4&&fl(i,a);break;case 13:Cl(i,a,n),n&&o&4&&pl(i,a);break;case 22:a.memoizedState===null&&Cl(i,a,n),qc(a,a.return);break;case 30:break;default:Cl(i,a,n)}t=t.sibling}}function wl(e,t){var n=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==n&&(e!=null&&e.refCount++,n!=null&&ma(n))}function Tl(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&ma(e))}function El(e,t,n,r){if(t.subtreeFlags&10256)for(t=t.child;t!==null;)Dl(e,t,n,r),t=t.sibling}function Dl(e,t,n,r){var i=t.flags;switch(t.tag){case 0:case 11:case 15:El(e,t,n,r),i&2048&&Uc(9,t);break;case 1:El(e,t,n,r);break;case 3:El(e,t,n,r),i&2048&&(e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&ma(e)));break;case 12:if(i&2048){El(e,t,n,r),e=t.stateNode;try{var a=t.memoizedProps,o=a.id,s=a.onPostCommit;typeof s==`function`&&s(o,t.alternate===null?`mount`:`update`,e.passiveEffectDuration,-0)}catch(e){Z(t,t.return,e)}}else El(e,t,n,r);break;case 31:El(e,t,n,r);break;case 13:El(e,t,n,r);break;case 23:break;case 22:a=t.stateNode,o=t.alternate,t.memoizedState===null?a._visibility&2?El(e,t,n,r):(a._visibility|=2,Ol(e,t,n,r,!!(t.subtreeFlags&10256)||!1)):a._visibility&2?El(e,t,n,r):kl(e,t),i&2048&&wl(o,t);break;case 24:El(e,t,n,r),i&2048&&Tl(t.alternate,t);break;default:El(e,t,n,r)}}function Ol(e,t,n,r,i){for(i&&=!!(t.subtreeFlags&10256)||!1,t=t.child;t!==null;){var a=e,o=t,s=n,c=r,l=o.flags;switch(o.tag){case 0:case 11:case 15:Ol(a,o,s,c,i),Uc(8,o);break;case 23:break;case 22:var u=o.stateNode;o.memoizedState===null?(u._visibility|=2,Ol(a,o,s,c,i)):u._visibility&2?Ol(a,o,s,c,i):kl(a,o),i&&l&2048&&wl(o.alternate,o);break;case 24:Ol(a,o,s,c,i),i&&l&2048&&Tl(o.alternate,o);break;default:Ol(a,o,s,c,i)}t=t.sibling}}function kl(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var n=e,r=t,i=r.flags;switch(r.tag){case 22:kl(n,r),i&2048&&wl(r.alternate,r);break;case 24:kl(n,r),i&2048&&Tl(r.alternate,r);break;default:kl(n,r)}t=t.sibling}}var Al=8192;function jl(e,t,n){if(e.subtreeFlags&Al)for(e=e.child;e!==null;)Ml(e,t,n),e=e.sibling}function Ml(e,t,n){switch(e.tag){case 26:jl(e,t,n),e.flags&Al&&e.memoizedState!==null&&Gf(n,_l,e.memoizedState,e.memoizedProps);break;case 5:jl(e,t,n);break;case 3:case 4:var r=_l;_l=gf(e.stateNode.containerInfo),jl(e,t,n),_l=r;break;case 22:e.memoizedState===null&&(r=e.alternate,r!==null&&r.memoizedState!==null?(r=Al,Al=16777216,jl(e,t,n),Al=r):jl(e,t,n));break;default:jl(e,t,n)}}function Nl(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function Pl(e){var t=e.deletions;if(e.flags&16){if(t!==null)for(var n=0;n<t.length;n++){var r=t[n];al=r,Ll(r,e)}Nl(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)Fl(e),e=e.sibling}function Fl(e){switch(e.tag){case 0:case 11:case 15:Pl(e),e.flags&2048&&Wc(9,e,e.return);break;case 3:Pl(e);break;case 12:Pl(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,Il(e)):Pl(e);break;default:Pl(e)}}function Il(e){var t=e.deletions;if(e.flags&16){if(t!==null)for(var n=0;n<t.length;n++){var r=t[n];al=r,Ll(r,e)}Nl(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:Wc(8,t,t.return),Il(t);break;case 22:n=t.stateNode,n._visibility&2&&(n._visibility&=-3,Il(t));break;default:Il(t)}e=e.sibling}}function Ll(e,t){for(;al!==null;){var n=al;switch(n.tag){case 0:case 11:case 15:Wc(8,n,t);break;case 23:case 22:if(n.memoizedState!==null&&n.memoizedState.cachePool!==null){var r=n.memoizedState.cachePool.pool;r!=null&&r.refCount++}break;case 24:ma(n.memoizedState.cache)}if(r=n.child,r!==null)r.return=n,al=r;else a:for(n=e;al!==null;){r=al;var i=r.sibling,a=r.return;if(cl(r),r===n){al=null;break a}if(i!==null){i.return=a,al=i;break a}al=a}}}var Rl={getCacheForType:function(e){var t=sa(P),n=t.data.get(e);return n===void 0&&(n=e(),t.data.set(e,n)),n},cacheSignal:function(){return sa(P).controller.signal}},zl=typeof WeakMap==`function`?WeakMap:Map,G=0,K=null,q=null,J=0,Y=0,Bl=null,Vl=!1,Hl=!1,Ul=!1,Wl=0,X=0,Gl=0,Kl=0,ql=0,Jl=0,Yl=0,Xl=null,Zl=null,Ql=!1,$l=0,eu=0,tu=1/0,nu=null,ru=null,iu=0,au=null,ou=null,su=0,cu=0,lu=null,uu=null,du=0,fu=null;function pu(){return G&2&&J!==0?J&-J:D.T===null?ut():dd()}function mu(){if(Jl===0){if(!(J&536870912)||N){var e=Ye;Ye<<=1,!(Ye&3932160)&&(Ye=262144),Jl=e}else Jl=536870912}return e=co.current,e!==null&&(e.flags|=32),Jl}function hu(e,t,n){(e===K&&(Y===2||Y===9)||e.cancelPendingCommit!==null)&&(Su(e,0),yu(e,J,Jl,!1)),rt(e,n),(!(G&2)||e!==K)&&(e===K&&(!(G&2)&&(Kl|=n),X===4&&yu(e,J,Jl,!1)),rd(e))}function gu(e,t,n){if(G&6)throw Error(i(327));var r=!n&&!(t&127)&&(t&e.expiredLanes)===0||$e(e,t),a=r?Au(e,t):Ou(e,t,!0),o=r;do{if(a===0){Hl&&!r&&yu(e,t,0,!1);break}if(n=e.current.alternate,o&&!vu(n)){a=Ou(e,t,!1),o=!1;continue}if(a===2){if(o=t,e.errorRecoveryDisabledLanes&o)var s=0;else s=e.pendingLanes&-536870913,s=s===0?s&536870912?536870912:0:s;if(s!==0){t=s;a:{var c=e;a=Xl;var l=c.current.memoizedState.isDehydrated;if(l&&(Su(c,s).flags|=256),s=Ou(c,s,!1),s!==2){if(Ul&&!l){c.errorRecoveryDisabledLanes|=o,Kl|=o,a=4;break a}o=Zl,Zl=a,o!==null&&(Zl===null?Zl=o:Zl.push.apply(Zl,o))}a=s}if(o=!1,a!==2)continue}}if(a===1){Su(e,0),yu(e,t,0,!0);break}a:{switch(r=e,o=a,o){case 0:case 1:throw Error(i(345));case 4:if((t&4194048)!==t)break;case 6:yu(r,t,Jl,!Vl);break a;case 2:Zl=null;break;case 3:case 5:break;default:throw Error(i(329))}if((t&62914560)===t&&(a=$l+300-Me(),10<a)){if(yu(r,t,Jl,!Vl),Qe(r,0,!0)!==0)break a;su=t,r.timeoutHandle=Kd(_u.bind(null,r,n,Zl,nu,Ql,t,Jl,Kl,Yl,Vl,o,`Throttled`,-0,0),a);break a}_u(r,n,Zl,nu,Ql,t,Jl,Kl,Yl,Vl,o,null,-0,0)}break}while(1);rd(e)}function _u(e,t,n,r,i,a,o,s,c,l,u,d,f,p){if(e.timeoutHandle=-1,d=t.subtreeFlags,d&8192||(d&16785408)==16785408){d={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:sn},Ml(t,a,d);var m=(a&62914560)===a?$l-Me():(a&4194048)===a?eu-Me():0;if(m=qf(d,m),m!==null){su=a,e.cancelPendingCommit=m(Lu.bind(null,e,t,a,n,r,i,o,s,c,u,d,null,f,p)),yu(e,a,o,!l);return}}Lu(e,t,a,n,r,i,o,s,c)}function vu(e){for(var t=e;;){var n=t.tag;if((n===0||n===11||n===15)&&t.flags&16384&&(n=t.updateQueue,n!==null&&(n=n.stores,n!==null)))for(var r=0;r<n.length;r++){var i=n[r],a=i.getSnapshot;i=i.value;try{if(!kr(a(),i))return!1}catch{return!1}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function yu(e,t,n,r){t&=~ql,t&=~Kl,e.suspendedLanes|=t,e.pingedLanes&=~t,r&&(e.warmLanes|=t),r=e.expirationTimes;for(var i=t;0<i;){var a=31-We(i),o=1<<a;r[a]=-1,i&=~o}n!==0&&at(e,n,t)}function bu(){return G&6?!0:(id(0,!1),!1)}function xu(){if(q!==null){if(Y===0)var e=q.return;else e=q,$i=Qi=null,Mo(e),La=null,Ra=0,e=q;for(;e!==null;)Hc(e.alternate,e),e=e.return;q=null}}function Su(e,t){var n=e.timeoutHandle;n!==-1&&(e.timeoutHandle=-1,qd(n)),n=e.cancelPendingCommit,n!==null&&(e.cancelPendingCommit=null,n()),su=0,xu(),K=e,q=n=_i(e.current,null),J=t,Y=0,Bl=null,Vl=!1,Hl=$e(e,t),Ul=!1,Yl=Jl=ql=Kl=Gl=X=0,Zl=Xl=null,Ql=!1,t&8&&(t|=t&32);var r=e.entangledLanes;if(r!==0)for(e=e.entanglements,r&=t;0<r;){var i=31-We(r),a=1<<i;t|=e[i],r&=~a}return Wl=t,si(),n}function Cu(e,t){I=null,D.H=Vs,t===Da||t===ka?(t=Fa(),Y=3):t===Oa?(t=Fa(),Y=4):Y=t===ac?8:typeof t==`object`&&t&&typeof t.then==`function`?6:1,Bl=t,q===null&&(X=1,$s(e,Ti(t,e.current)))}function wu(){var e=co.current;return e===null?!0:(J&4194048)===J?lo===null:(J&62914560)===J||J&536870912?e===lo:!1}function Tu(){var e=D.H;return D.H=Vs,e===null?Vs:e}function Eu(){var e=D.A;return D.A=Rl,e}function Du(){X=4,Vl||(J&4194048)!==J&&co.current!==null||(Hl=!0),!(Gl&134217727)&&!(Kl&134217727)||K===null||yu(K,J,Jl,!1)}function Ou(e,t,n){var r=G;G|=2;var i=Tu(),a=Eu();(K!==e||J!==t)&&(nu=null,Su(e,t)),t=!1;var o=X;a:do try{if(Y!==0&&q!==null){var s=q,c=Bl;switch(Y){case 8:xu(),o=6;break a;case 3:case 2:case 9:case 6:co.current===null&&(t=!0);var l=Y;if(Y=0,Bl=null,Pu(e,s,c,l),n&&Hl){o=0;break a}break;default:l=Y,Y=0,Bl=null,Pu(e,s,c,l)}}ku(),o=X;break}catch(t){Cu(e,t)}while(1);return t&&e.shellSuspendCounter++,$i=Qi=null,G=r,D.H=i,D.A=a,q===null&&(K=null,J=0,si()),o}function ku(){for(;q!==null;)Mu(q)}function Au(e,t){var n=G;G|=2;var r=Tu(),a=Eu();K!==e||J!==t?(nu=null,tu=Me()+500,Su(e,t)):Hl=$e(e,t);a:do try{if(Y!==0&&q!==null){t=q;var o=Bl;b:switch(Y){case 1:Y=0,Bl=null,Pu(e,t,o,1);break;case 2:case 9:if(ja(o)){Y=0,Bl=null,Nu(t);break}t=function(){Y!==2&&Y!==9||K!==e||(Y=7),rd(e)},o.then(t,t);break a;case 3:Y=7;break a;case 4:Y=5;break a;case 7:ja(o)?(Y=0,Bl=null,Nu(t)):(Y=0,Bl=null,Pu(e,t,o,7));break;case 5:var s=null;switch(q.tag){case 26:s=q.memoizedState;case 5:case 27:var c=q;if(s?Wf(s):c.stateNode.complete){Y=0,Bl=null;var l=c.sibling;if(l!==null)q=l;else{var u=c.return;u===null?q=null:(q=u,Fu(u))}break b}}Y=0,Bl=null,Pu(e,t,o,5);break;case 6:Y=0,Bl=null,Pu(e,t,o,6);break;case 8:xu(),X=6;break a;default:throw Error(i(462))}}ju();break}catch(t){Cu(e,t)}while(1);return $i=Qi=null,D.H=r,D.A=a,G=n,q===null?(K=null,J=0,si(),X):0}function ju(){for(;q!==null&&!j();)Mu(q)}function Mu(e){var t=Pc(e.alternate,e,Wl);e.memoizedProps=e.pendingProps,t===null?Fu(e):q=t}function Nu(e){var t=e,n=t.alternate;switch(t.tag){case 15:case 0:t=vc(n,t,t.pendingProps,t.type,void 0,J);break;case 11:t=vc(n,t,t.pendingProps,t.type.render,t.ref,J);break;case 5:Mo(t);default:Hc(n,t),t=q=vi(t,Wl),t=Pc(n,t,Wl)}e.memoizedProps=e.pendingProps,t===null?Fu(e):q=t}function Pu(e,t,n,r){$i=Qi=null,Mo(t),La=null,Ra=0;var i=t.return;try{if(ic(e,i,t,n,J)){X=1,$s(e,Ti(n,e.current)),q=null;return}}catch(t){if(i!==null)throw q=i,t;X=1,$s(e,Ti(n,e.current)),q=null;return}t.flags&32768?(N||r===1?e=!0:Hl||J&536870912?e=!1:(Vl=e=!0,(r===2||r===9||r===3||r===6)&&(r=co.current,r!==null&&r.tag===13&&(r.flags|=16384))),Iu(t,e)):Fu(t)}function Fu(e){var t=e;do{if(t.flags&32768){Iu(t,Vl);return}e=t.return;var n=Bc(t.alternate,t,Wl);if(n!==null){q=n;return}if(t=t.sibling,t!==null){q=t;return}q=t=e}while(t!==null);X===0&&(X=5)}function Iu(e,t){do{var n=Vc(e.alternate,e);if(n!==null){n.flags&=32767,q=n;return}if(n=e.return,n!==null&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&(e=e.sibling,e!==null)){q=e;return}q=e=n}while(e!==null);X=6,q=null}function Lu(e,t,n,r,a,o,s,c,l){e.cancelPendingCommit=null;do Hu();while(iu!==0);if(G&6)throw Error(i(327));if(t!==null){if(t===e.current)throw Error(i(177));if(o=t.lanes|t.childLanes,o|=oi,it(e,n,o,s,c,l),e===K&&(q=K=null,J=0),ou=t,au=e,su=n,cu=o,lu=a,uu=r,t.subtreeFlags&10256||t.flags&10256?(e.callbackNode=null,e.callbackPriority=0,Xu(Ie,function(){return Uu(),null})):(e.callbackNode=null,e.callbackPriority=0),r=!!(t.flags&13878),t.subtreeFlags&13878||r){r=D.T,D.T=null,a=O.p,O.p=2,s=G,G|=4;try{ol(e,t,n)}finally{G=s,O.p=a,D.T=r}}iu=1,Ru(),zu(),Bu()}}function Ru(){if(iu===1){iu=0;var e=au,t=ou,n=!!(t.flags&13878);if(t.subtreeFlags&13878||n){n=D.T,D.T=null;var r=O.p;O.p=2;var i=G;G|=4;try{vl(t,e);var a=zd,o=Pr(e.containerInfo),s=a.focusedElem,c=a.selectionRange;if(o!==s&&s&&s.ownerDocument&&Nr(s.ownerDocument.documentElement,s)){if(c!==null&&Fr(s)){var l=c.start,u=c.end;if(u===void 0&&(u=l),`selectionStart`in s)s.selectionStart=l,s.selectionEnd=Math.min(u,s.value.length);else{var d=s.ownerDocument||document,f=d&&d.defaultView||window;if(f.getSelection){var p=f.getSelection(),m=s.textContent.length,h=Math.min(c.start,m),g=c.end===void 0?h:Math.min(c.end,m);!p.extend&&h>g&&(o=g,g=h,h=o);var _=Mr(s,h),v=Mr(s,g);if(_&&v&&(p.rangeCount!==1||p.anchorNode!==_.node||p.anchorOffset!==_.offset||p.focusNode!==v.node||p.focusOffset!==v.offset)){var y=d.createRange();y.setStart(_.node,_.offset),p.removeAllRanges(),h>g?(p.addRange(y),p.extend(v.node,v.offset)):(y.setEnd(v.node,v.offset),p.addRange(y))}}}}for(d=[],p=s;p=p.parentNode;)p.nodeType===1&&d.push({element:p,left:p.scrollLeft,top:p.scrollTop});for(typeof s.focus==`function`&&s.focus(),s=0;s<d.length;s++){var b=d[s];b.element.scrollLeft=b.left,b.element.scrollTop=b.top}}sp=!!Rd,zd=Rd=null}finally{G=i,O.p=r,D.T=n}}e.current=t,iu=2}}function zu(){if(iu===2){iu=0;var e=au,t=ou,n=!!(t.flags&8772);if(t.subtreeFlags&8772||n){n=D.T,D.T=null;var r=O.p;O.p=2;var i=G;G|=4;try{sl(e,t.alternate,t)}finally{G=i,O.p=r,D.T=n}}iu=3}}function Bu(){if(iu===4||iu===3){iu=0,je();var e=au,t=ou,n=su,r=uu;t.subtreeFlags&10256||t.flags&10256?iu=5:(iu=0,ou=au=null,Vu(e,e.pendingLanes));var i=e.pendingLanes;if(i===0&&(ru=null),lt(n),t=t.stateNode,He&&typeof He.onCommitFiberRoot==`function`)try{He.onCommitFiberRoot(Ve,t,void 0,(t.current.flags&128)==128)}catch{}if(r!==null){t=D.T,i=O.p,O.p=2,D.T=null;try{for(var a=e.onRecoverableError,o=0;o<r.length;o++){var s=r[o];a(s.value,{componentStack:s.stack})}}finally{D.T=t,O.p=i}}su&3&&Hu(),rd(e),i=e.pendingLanes,n&261930&&i&42?e===fu?du++:(du=0,fu=e):du=0,id(0,!1)}}function Vu(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,ma(t)))}function Hu(){return Ru(),zu(),Bu(),Uu()}function Uu(){if(iu!==5)return!1;var e=au,t=cu;cu=0;var n=lt(su),r=D.T,a=O.p;try{O.p=32>n?32:n,D.T=null,n=lu,lu=null;var o=au,s=su;if(iu=0,ou=au=null,su=0,G&6)throw Error(i(331));var c=G;if(G|=4,Fl(o.current),Dl(o,o.current,s,n),G=c,id(0,!1),He&&typeof He.onPostCommitFiberRoot==`function`)try{He.onPostCommitFiberRoot(Ve,o)}catch{}return!0}finally{O.p=a,D.T=r,Vu(e,t)}}function Wu(e,t,n){t=Ti(n,t),t=tc(e.stateNode,t,2),e=Ya(e,t,2),e!==null&&(rt(e,2),rd(e))}function Z(e,t,n){if(e.tag===3)Wu(e,e,n);else for(;t!==null;){if(t.tag===3){Wu(t,e,n);break}if(t.tag===1){var r=t.stateNode;if(typeof t.type.getDerivedStateFromError==`function`||typeof r.componentDidCatch==`function`&&(ru===null||!ru.has(r))){e=Ti(n,e),n=nc(2),r=Ya(t,n,2),r!==null&&(rc(n,r,t,e),rt(r,2),rd(r));break}}t=t.return}}function Gu(e,t,n){var r=e.pingCache;if(r===null){r=e.pingCache=new zl;var i=new Set;r.set(t,i)}else i=r.get(t),i===void 0&&(i=new Set,r.set(t,i));i.has(n)||(Ul=!0,i.add(n),e=Ku.bind(null,e,t,n),t.then(e,e))}function Ku(e,t,n){var r=e.pingCache;r!==null&&r.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,K===e&&(J&n)===n&&(X===4||X===3&&(J&62914560)===J&&300>Me()-$l?!(G&2)&&Su(e,0):ql|=n,Yl===J&&(Yl=0)),rd(e)}function qu(e,t){t===0&&(t=tt()),e=ui(e,t),e!==null&&(rt(e,t),rd(e))}function Ju(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),qu(e,n)}function Yu(e,t){var n=0;switch(e.tag){case 31:case 13:var r=e.stateNode,a=e.memoizedState;a!==null&&(n=a.retryLane);break;case 19:r=e.stateNode;break;case 22:r=e.stateNode._retryCache;break;default:throw Error(i(314))}r!==null&&r.delete(t),qu(e,n)}function Xu(e,t){return ke(e,t)}var Zu=null,Qu=null,$u=!1,ed=!1,td=!1,nd=0;function rd(e){e!==Qu&&e.next===null&&(Qu===null?Zu=Qu=e:Qu=Qu.next=e),ed=!0,$u||($u=!0,ud())}function id(e,t){if(!td&&ed){td=!0;do for(var n=!1,r=Zu;r!==null;){if(!t){if(e!==0){var i=r.pendingLanes;if(i===0)var a=0;else{var o=r.suspendedLanes,s=r.pingedLanes;a=(1<<31-We(42|e)+1)-1,a&=i&~(o&~s),a=a&201326741?a&201326741|1:a?a|2:0}a!==0&&(n=!0,ld(r,a))}else a=J,a=Qe(r,r===K?a:0,r.cancelPendingCommit!==null||r.timeoutHandle!==-1),!(a&3)||$e(r,a)||(n=!0,ld(r,a))}r=r.next}while(n);td=!1}}function ad(){od()}function od(){ed=$u=!1;var e=0;nd!==0&&Gd()&&(e=nd);for(var t=Me(),n=null,r=Zu;r!==null;){var i=r.next,a=sd(r,t);a===0?(r.next=null,n===null?Zu=i:n.next=i,i===null&&(Qu=n)):(n=r,(e!==0||a&3)&&(ed=!0)),r=i}iu!==0&&iu!==5||id(e,!1),nd!==0&&(nd=0)}function sd(e,t){for(var n=e.suspendedLanes,r=e.pingedLanes,i=e.expirationTimes,a=e.pendingLanes&-62914561;0<a;){var o=31-We(a),s=1<<o,c=i[o];c===-1?((s&n)===0||(s&r)!==0)&&(i[o]=et(s,t)):c<=t&&(e.expiredLanes|=s),a&=~s}if(t=K,n=J,n=Qe(e,e===t?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),r=e.callbackNode,n===0||e===t&&(Y===2||Y===9)||e.cancelPendingCommit!==null)return r!==null&&r!==null&&Ae(r),e.callbackNode=null,e.callbackPriority=0;if(!(n&3)||$e(e,n)){if(t=n&-n,t===e.callbackPriority)return t;switch(r!==null&&Ae(r),lt(n)){case 2:case 8:n=Fe;break;case 32:n=Ie;break;case 268435456:n=Re;break;default:n=Ie}return r=cd.bind(null,e),n=ke(n,r),e.callbackPriority=t,e.callbackNode=n,t}return r!==null&&r!==null&&Ae(r),e.callbackPriority=2,e.callbackNode=null,2}function cd(e,t){if(iu!==0&&iu!==5)return e.callbackNode=null,e.callbackPriority=0,null;var n=e.callbackNode;if(Hu()&&e.callbackNode!==n)return null;var r=J;return r=Qe(e,e===K?r:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),r===0?null:(gu(e,r,t),sd(e,Me()),e.callbackNode!=null&&e.callbackNode===n?cd.bind(null,e):null)}function ld(e,t){if(Hu())return null;gu(e,t,!0)}function ud(){Yd(function(){G&6?ke(Pe,ad):od()})}function dd(){if(nd===0){var e=_a;e===0&&(e=Je,Je<<=1,!(Je&261888)&&(Je=256)),nd=e}return nd}function fd(e){return e==null||typeof e==`symbol`||typeof e==`boolean`?null:typeof e==`function`?e:on(``+e)}function pd(e,t){var n=t.ownerDocument.createElement(`input`);return n.name=t.name,n.value=t.value,e.id&&n.setAttribute(`form`,e.id),t.parentNode.insertBefore(n,t),e=new FormData(e),n.parentNode.removeChild(n),e}function md(e,t,n,r,i){if(t===`submit`&&n&&n.stateNode===i){var a=fd((i[mt]||null).action),o=r.submitter;o&&(t=(t=o[mt]||null)?fd(t.formAction):o.getAttribute(`formAction`),t!==null&&(a=t,o=null));var s=new On(`action`,`action`,null,r,i);e.push({event:s,listeners:[{instance:null,listener:function(){if(r.defaultPrevented){if(nd!==0){var e=o?pd(i,o):new FormData(i);Ds(n,{pending:!0,data:e,method:i.method,action:a},null,e)}}else typeof a==`function`&&(s.preventDefault(),e=o?pd(i,o):new FormData(i),Ds(n,{pending:!0,data:e,method:i.method,action:a},a,e))},currentTarget:i}]})}}for(var hd=0;hd<ti.length;hd++){var gd=ti[hd];ni(gd.toLowerCase(),`on`+(gd[0].toUpperCase()+gd.slice(1)))}ni(qr,`onAnimationEnd`),ni(Jr,`onAnimationIteration`),ni(Yr,`onAnimationStart`),ni(`dblclick`,`onDoubleClick`),ni(`focusin`,`onFocus`),ni(`focusout`,`onBlur`),ni(Xr,`onTransitionRun`),ni(Zr,`onTransitionStart`),ni(Qr,`onTransitionCancel`),ni($r,`onTransitionEnd`),At(`onMouseEnter`,[`mouseout`,`mouseover`]),At(`onMouseLeave`,[`mouseout`,`mouseover`]),At(`onPointerEnter`,[`pointerout`,`pointerover`]),At(`onPointerLeave`,[`pointerout`,`pointerover`]),kt(`onChange`,`change click focusin focusout input keydown keyup selectionchange`.split(` `)),kt(`onSelect`,`focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange`.split(` `)),kt(`onBeforeInput`,[`compositionend`,`keypress`,`textInput`,`paste`]),kt(`onCompositionEnd`,`compositionend focusout keydown keypress keyup mousedown`.split(` `)),kt(`onCompositionStart`,`compositionstart focusout keydown keypress keyup mousedown`.split(` `)),kt(`onCompositionUpdate`,`compositionupdate focusout keydown keypress keyup mousedown`.split(` `));var _d=`abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting`.split(` `),vd=new Set(`beforetoggle cancel close invalid load scroll scrollend toggle`.split(` `).concat(_d));function yd(e,t){t=!!(t&4);for(var n=0;n<e.length;n++){var r=e[n],i=r.event;r=r.listeners;a:{var a=void 0;if(t)for(var o=r.length-1;0<=o;o--){var s=r[o],c=s.instance,l=s.currentTarget;if(s=s.listener,c!==a&&i.isPropagationStopped())break a;a=s,i.currentTarget=l;try{a(i)}catch(e){ri(e)}i.currentTarget=null,a=c}else for(o=0;o<r.length;o++){if(s=r[o],c=s.instance,l=s.currentTarget,s=s.listener,c!==a&&i.isPropagationStopped())break a;a=s,i.currentTarget=l;try{a(i)}catch(e){ri(e)}i.currentTarget=null,a=c}}}}function Q(e,t){var n=t[gt];n===void 0&&(n=t[gt]=new Set);var r=e+`__bubble`;n.has(r)||(Cd(t,e,2,!1),n.add(r))}function bd(e,t,n){var r=0;t&&(r|=4),Cd(n,e,r,t)}var xd=`_reactListening`+Math.random().toString(36).slice(2);function Sd(e){if(!e[xd]){e[xd]=!0,Dt.forEach(function(t){t!==`selectionchange`&&(vd.has(t)||bd(t,!1,e),bd(t,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[xd]||(t[xd]=!0,bd(`selectionchange`,!1,t))}}function Cd(e,t,n,r){switch(mp(t)){case 2:var i=cp;break;case 8:i=lp;break;default:i=up}n=i.bind(null,t,n,e),i=void 0,!_n||t!==`touchstart`&&t!==`touchmove`&&t!==`wheel`||(i=!0),r?i===void 0?e.addEventListener(t,n,!0):e.addEventListener(t,n,{capture:!0,passive:i}):i===void 0?e.addEventListener(t,n,!1):e.addEventListener(t,n,{passive:i})}function wd(e,t,n,r,i){var a=r;if(!(t&1)&&!(t&2)&&r!==null)a:for(;;){if(r===null)return;var s=r.tag;if(s===3||s===4){var c=r.stateNode.containerInfo;if(c===i)break;if(s===4)for(s=r.return;s!==null;){var l=s.tag;if((l===3||l===4)&&s.stateNode.containerInfo===i)return;s=s.return}for(;c!==null;){if(s=St(c),s===null)return;if(l=s.tag,l===5||l===6||l===26||l===27){r=a=s;continue a}c=c.parentNode}}r=r.return}mn(function(){var r=a,i=ln(n),s=[];a:{var c=ei.get(e);if(c!==void 0){var l=On,u=e;switch(e){case`keypress`:if(Cn(n)===0)break a;case`keydown`:case`keyup`:l=Kn;break;case`focusin`:u=`focus`,l=Ln;break;case`focusout`:u=`blur`,l=Ln;break;case`beforeblur`:case`afterblur`:l=Ln;break;case`click`:if(n.button===2)break a;case`auxclick`:case`dblclick`:case`mousedown`:case`mousemove`:case`mouseup`:case`mouseout`:case`mouseover`:case`contextmenu`:l=Fn;break;case`drag`:case`dragend`:case`dragenter`:case`dragexit`:case`dragleave`:case`dragover`:case`dragstart`:case`drop`:l=In;break;case`touchcancel`:case`touchend`:case`touchmove`:case`touchstart`:l=Jn;break;case qr:case Jr:case Yr:l=Rn;break;case $r:l=Yn;break;case`scroll`:case`scrollend`:l=An;break;case`wheel`:l=Xn;break;case`copy`:case`cut`:case`paste`:l=zn;break;case`gotpointercapture`:case`lostpointercapture`:case`pointercancel`:case`pointerdown`:case`pointermove`:case`pointerout`:case`pointerover`:case`pointerup`:l=qn;break;case`toggle`:case`beforetoggle`:l=Zn}var d=!!(t&4),f=!d&&(e===`scroll`||e===`scrollend`),p=d?c===null?null:c+`Capture`:c;d=[];for(var m=r,h;m!==null;){var g=m;if(h=g.stateNode,g=g.tag,g!==5&&g!==26&&g!==27||h===null||p===null||(g=hn(m,p),g!=null&&d.push(Td(m,g,h))),f)break;m=m.return}0<d.length&&(c=new l(c,u,null,n,i),s.push({event:c,listeners:d}))}}if(!(t&7)){a:{if(c=e===`mouseover`||e===`pointerover`,l=e===`mouseout`||e===`pointerout`,c&&n!==cn&&(u=n.relatedTarget||n.fromElement)&&(St(u)||u[ht]))break a;if((l||c)&&(c=i.window===i?i:(c=i.ownerDocument)?c.defaultView||c.parentWindow:window,l?(u=n.relatedTarget||n.toElement,l=r,u=u?St(u):null,u!==null&&(f=o(u),d=u.tag,u!==f||d!==5&&d!==27&&d!==6)&&(u=null)):(l=null,u=r),l!==u)){if(d=Fn,g=`onMouseLeave`,p=`onMouseEnter`,m=`mouse`,(e===`pointerout`||e===`pointerover`)&&(d=qn,g=`onPointerLeave`,p=`onPointerEnter`,m=`pointer`),f=l==null?c:wt(l),h=u==null?c:wt(u),c=new d(g,m+`leave`,l,n,i),c.target=f,c.relatedTarget=h,g=null,St(i)===r&&(d=new d(p,m+`enter`,u,n,i),d.target=h,d.relatedTarget=f,g=d),f=g,l&&u)b:{for(d=Dd,p=l,m=u,h=0,g=p;g;g=d(g))h++;g=0;for(var _=m;_;_=d(_))g++;for(;0<h-g;)p=d(p),h--;for(;0<g-h;)m=d(m),g--;for(;h--;){if(p===m||m!==null&&p===m.alternate){d=p;break b}p=d(p),m=d(m)}d=null}else d=null;l!==null&&Od(s,c,l,d,!1),u!==null&&f!==null&&Od(s,f,u,d,!0)}}a:{if(c=r?wt(r):window,l=c.nodeName&&c.nodeName.toLowerCase(),l===`select`||l===`input`&&c.type===`file`)var v=_r;else if(dr(c)){if(vr)v=Dr;else{v=Tr;var y=wr}}else l=c.nodeName,!l||l.toLowerCase()!==`input`||c.type!==`checkbox`&&c.type!==`radio`?r&&nn(r.elementType)&&(v=_r):v=Er;if(v&&=v(e,r)){fr(s,v,n,i);break a}y&&y(e,c,r),e===`focusout`&&r&&c.type===`number`&&r.memoizedProps.value!=null&&Jt(c,`number`,c.value)}switch(y=r?wt(r):window,e){case`focusin`:(dr(y)||y.contentEditable===`true`)&&(Lr=y,Rr=r,zr=null);break;case`focusout`:zr=Rr=Lr=null;break;case`mousedown`:Br=!0;break;case`contextmenu`:case`mouseup`:case`dragend`:Br=!1,Vr(s,n,i);break;case`selectionchange`:if(Ir)break;case`keydown`:case`keyup`:Vr(s,n,i)}var b;if($n)b:{switch(e){case`compositionstart`:var x=`onCompositionStart`;break b;case`compositionend`:x=`onCompositionEnd`;break b;case`compositionupdate`:x=`onCompositionUpdate`;break b}x=void 0}else sr?ar(e,n)&&(x=`onCompositionEnd`):e===`keydown`&&n.keyCode===229&&(x=`onCompositionStart`);x&&(nr&&n.locale!==`ko`&&(sr||x!==`onCompositionStart`?x===`onCompositionEnd`&&sr&&(b=Sn()):(yn=i,bn=`value`in yn?yn.value:yn.textContent,sr=!0)),y=Ed(r,x),0<y.length&&(x=new Bn(x,e,null,n,i),s.push({event:x,listeners:y}),b?x.data=b:(b=or(n),b!==null&&(x.data=b)))),(b=tr?cr(e,n):lr(e,n))&&(x=Ed(r,`onBeforeInput`),0<x.length&&(y=new Bn(`onBeforeInput`,`beforeinput`,null,n,i),s.push({event:y,listeners:x}),y.data=b)),md(s,e,r,n,i)}yd(s,t)})}function Td(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Ed(e,t){for(var n=t+`Capture`,r=[];e!==null;){var i=e,a=i.stateNode;if(i=i.tag,i!==5&&i!==26&&i!==27||a===null||(i=hn(e,n),i!=null&&r.unshift(Td(e,i,a)),i=hn(e,t),i!=null&&r.push(Td(e,i,a))),e.tag===3)return r;e=e.return}return[]}function Dd(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function Od(e,t,n,r,i){for(var a=t._reactName,o=[];n!==null&&n!==r;){var s=n,c=s.alternate,l=s.stateNode;if(s=s.tag,c!==null&&c===r)break;s!==5&&s!==26&&s!==27||l===null||(c=l,i?(l=hn(n,a),l!=null&&o.unshift(Td(n,l,c))):i||(l=hn(n,a),l!=null&&o.push(Td(n,l,c)))),n=n.return}o.length!==0&&e.push({event:t,listeners:o})}var kd=/\r\n?/g,Ad=/\u0000|\uFFFD/g;function jd(e){return(typeof e==`string`?e:``+e).replace(kd,`
`).replace(Ad,``)}function Md(e,t){return t=jd(t),jd(e)===t}function $(e,t,n,r,a,o){switch(n){case`children`:typeof r==`string`?t===`body`||t===`textarea`&&r===``||Qt(e,r):(typeof r==`number`||typeof r==`bigint`)&&t!==`body`&&Qt(e,``+r);break;case`className`:It(e,`class`,r);break;case`tabIndex`:It(e,`tabindex`,r);break;case`dir`:case`role`:case`viewBox`:case`width`:case`height`:It(e,n,r);break;case`style`:tn(e,r,o);break;case`data`:if(t!==`object`){It(e,`data`,r);break}case`src`:case`href`:if(r===``&&(t!==`a`||n!==`href`)){e.removeAttribute(n);break}if(r==null||typeof r==`function`||typeof r==`symbol`||typeof r==`boolean`){e.removeAttribute(n);break}r=on(``+r),e.setAttribute(n,r);break;case`action`:case`formAction`:if(typeof r==`function`){e.setAttribute(n,`javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')`);break}if(typeof o==`function`&&(n===`formAction`?(t!==`input`&&$(e,t,`name`,a.name,a,null),$(e,t,`formEncType`,a.formEncType,a,null),$(e,t,`formMethod`,a.formMethod,a,null),$(e,t,`formTarget`,a.formTarget,a,null)):($(e,t,`encType`,a.encType,a,null),$(e,t,`method`,a.method,a,null),$(e,t,`target`,a.target,a,null))),r==null||typeof r==`symbol`||typeof r==`boolean`){e.removeAttribute(n);break}r=on(``+r),e.setAttribute(n,r);break;case`onClick`:r!=null&&(e.onclick=sn);break;case`onScroll`:r!=null&&Q(`scroll`,e);break;case`onScrollEnd`:r!=null&&Q(`scrollend`,e);break;case`dangerouslySetInnerHTML`:if(r!=null){if(typeof r!=`object`||!(`__html`in r))throw Error(i(61));if(n=r.__html,n!=null){if(a.children!=null)throw Error(i(60));e.innerHTML=n}}break;case`multiple`:e.multiple=r&&typeof r!=`function`&&typeof r!=`symbol`;break;case`muted`:e.muted=r&&typeof r!=`function`&&typeof r!=`symbol`;break;case`suppressContentEditableWarning`:case`suppressHydrationWarning`:case`defaultValue`:case`defaultChecked`:case`innerHTML`:case`ref`:break;case`autoFocus`:break;case`xlinkHref`:if(r==null||typeof r==`function`||typeof r==`boolean`||typeof r==`symbol`){e.removeAttribute(`xlink:href`);break}n=on(``+r),e.setAttributeNS(`http://www.w3.org/1999/xlink`,`xlink:href`,n);break;case`contentEditable`:case`spellCheck`:case`draggable`:case`value`:case`autoReverse`:case`externalResourcesRequired`:case`focusable`:case`preserveAlpha`:r!=null&&typeof r!=`function`&&typeof r!=`symbol`?e.setAttribute(n,``+r):e.removeAttribute(n);break;case`inert`:case`allowFullScreen`:case`async`:case`autoPlay`:case`controls`:case`default`:case`defer`:case`disabled`:case`disablePictureInPicture`:case`disableRemotePlayback`:case`formNoValidate`:case`hidden`:case`loop`:case`noModule`:case`noValidate`:case`open`:case`playsInline`:case`readOnly`:case`required`:case`reversed`:case`scoped`:case`seamless`:case`itemScope`:r&&typeof r!=`function`&&typeof r!=`symbol`?e.setAttribute(n,``):e.removeAttribute(n);break;case`capture`:case`download`:!0===r?e.setAttribute(n,``):!1!==r&&r!=null&&typeof r!=`function`&&typeof r!=`symbol`?e.setAttribute(n,r):e.removeAttribute(n);break;case`cols`:case`rows`:case`size`:case`span`:r!=null&&typeof r!=`function`&&typeof r!=`symbol`&&!isNaN(r)&&1<=r?e.setAttribute(n,r):e.removeAttribute(n);break;case`rowSpan`:case`start`:r==null||typeof r==`function`||typeof r==`symbol`||isNaN(r)?e.removeAttribute(n):e.setAttribute(n,r);break;case`popover`:Q(`beforetoggle`,e),Q(`toggle`,e),Ft(e,`popover`,r);break;case`xlinkActuate`:Lt(e,`http://www.w3.org/1999/xlink`,`xlink:actuate`,r);break;case`xlinkArcrole`:Lt(e,`http://www.w3.org/1999/xlink`,`xlink:arcrole`,r);break;case`xlinkRole`:Lt(e,`http://www.w3.org/1999/xlink`,`xlink:role`,r);break;case`xlinkShow`:Lt(e,`http://www.w3.org/1999/xlink`,`xlink:show`,r);break;case`xlinkTitle`:Lt(e,`http://www.w3.org/1999/xlink`,`xlink:title`,r);break;case`xlinkType`:Lt(e,`http://www.w3.org/1999/xlink`,`xlink:type`,r);break;case`xmlBase`:Lt(e,`http://www.w3.org/XML/1998/namespace`,`xml:base`,r);break;case`xmlLang`:Lt(e,`http://www.w3.org/XML/1998/namespace`,`xml:lang`,r);break;case`xmlSpace`:Lt(e,`http://www.w3.org/XML/1998/namespace`,`xml:space`,r);break;case`is`:Ft(e,`is`,r);break;case`innerText`:case`textContent`:break;default:(!(2<n.length)||n[0]!==`o`&&n[0]!==`O`||n[1]!==`n`&&n[1]!==`N`)&&(n=rn.get(n)||n,Ft(e,n,r))}}function Nd(e,t,n,r,a,o){switch(n){case`style`:tn(e,r,o);break;case`dangerouslySetInnerHTML`:if(r!=null){if(typeof r!=`object`||!(`__html`in r))throw Error(i(61));if(n=r.__html,n!=null){if(a.children!=null)throw Error(i(60));e.innerHTML=n}}break;case`children`:typeof r==`string`?Qt(e,r):(typeof r==`number`||typeof r==`bigint`)&&Qt(e,``+r);break;case`onScroll`:r!=null&&Q(`scroll`,e);break;case`onScrollEnd`:r!=null&&Q(`scrollend`,e);break;case`onClick`:r!=null&&(e.onclick=sn);break;case`suppressContentEditableWarning`:case`suppressHydrationWarning`:case`innerHTML`:case`ref`:break;case`innerText`:case`textContent`:break;default:if(!Ot.hasOwnProperty(n))a:{if(n[0]===`o`&&n[1]===`n`&&(a=n.endsWith(`Capture`),t=n.slice(2,a?n.length-7:void 0),o=e[mt]||null,o=o==null?null:o[n],typeof o==`function`&&e.removeEventListener(t,o,a),typeof r==`function`)){typeof o!=`function`&&o!==null&&(n in e?e[n]=null:e.hasAttribute(n)&&e.removeAttribute(n)),e.addEventListener(t,r,a);break a}n in e?e[n]=r:!0===r?e.setAttribute(n,``):Ft(e,n,r)}}}function Pd(e,t,n){switch(t){case`div`:case`span`:case`svg`:case`path`:case`a`:case`g`:case`p`:case`li`:break;case`img`:Q(`error`,e),Q(`load`,e);var r=!1,a=!1,o;for(o in n)if(n.hasOwnProperty(o)){var s=n[o];if(s!=null)switch(o){case`src`:r=!0;break;case`srcSet`:a=!0;break;case`children`:case`dangerouslySetInnerHTML`:throw Error(i(137,t));default:$(e,t,o,s,n,null)}}a&&$(e,t,`srcSet`,n.srcSet,n,null),r&&$(e,t,`src`,n.src,n,null);return;case`input`:Q(`invalid`,e);var c=o=s=a=null,l=null,u=null;for(r in n)if(n.hasOwnProperty(r)){var d=n[r];if(d!=null)switch(r){case`name`:a=d;break;case`type`:s=d;break;case`checked`:l=d;break;case`defaultChecked`:u=d;break;case`value`:o=d;break;case`defaultValue`:c=d;break;case`children`:case`dangerouslySetInnerHTML`:if(d!=null)throw Error(i(137,t));break;default:$(e,t,r,d,n,null)}}qt(e,o,c,l,u,s,a,!1);return;case`select`:for(a in Q(`invalid`,e),r=s=o=null,n)if(n.hasOwnProperty(a)&&(c=n[a],c!=null))switch(a){case`value`:o=c;break;case`defaultValue`:s=c;break;case`multiple`:r=c;default:$(e,t,a,c,n,null)}t=o,n=s,e.multiple=!!r,t==null?n!=null&&Yt(e,!!r,n,!0):Yt(e,!!r,t,!1);return;case`textarea`:for(s in Q(`invalid`,e),o=a=r=null,n)if(n.hasOwnProperty(s)&&(c=n[s],c!=null))switch(s){case`value`:r=c;break;case`defaultValue`:a=c;break;case`children`:o=c;break;case`dangerouslySetInnerHTML`:if(c!=null)throw Error(i(91));break;default:$(e,t,s,c,n,null)}Zt(e,r,a,o);return;case`option`:for(l in n)if(n.hasOwnProperty(l)&&(r=n[l],r!=null))switch(l){case`selected`:e.selected=r&&typeof r!=`function`&&typeof r!=`symbol`;break;default:$(e,t,l,r,n,null)}return;case`dialog`:Q(`beforetoggle`,e),Q(`toggle`,e),Q(`cancel`,e),Q(`close`,e);break;case`iframe`:case`object`:Q(`load`,e);break;case`video`:case`audio`:for(r=0;r<_d.length;r++)Q(_d[r],e);break;case`image`:Q(`error`,e),Q(`load`,e);break;case`details`:Q(`toggle`,e);break;case`embed`:case`source`:case`link`:Q(`error`,e),Q(`load`,e);case`area`:case`base`:case`br`:case`col`:case`hr`:case`keygen`:case`meta`:case`param`:case`track`:case`wbr`:case`menuitem`:for(u in n)if(n.hasOwnProperty(u)&&(r=n[u],r!=null))switch(u){case`children`:case`dangerouslySetInnerHTML`:throw Error(i(137,t));default:$(e,t,u,r,n,null)}return;default:if(nn(t)){for(d in n)n.hasOwnProperty(d)&&(r=n[d],r!==void 0&&Nd(e,t,d,r,n,void 0));return}}for(c in n)n.hasOwnProperty(c)&&(r=n[c],r!=null&&$(e,t,c,r,n,null))}function Fd(e,t,n,r){switch(t){case`div`:case`span`:case`svg`:case`path`:case`a`:case`g`:case`p`:case`li`:break;case`input`:var a=null,o=null,s=null,c=null,l=null,u=null,d=null;for(m in n){var f=n[m];if(n.hasOwnProperty(m)&&f!=null)switch(m){case`checked`:break;case`value`:break;case`defaultValue`:l=f;default:r.hasOwnProperty(m)||$(e,t,m,null,r,f)}}for(var p in r){var m=r[p];if(f=n[p],r.hasOwnProperty(p)&&(m!=null||f!=null))switch(p){case`type`:o=m;break;case`name`:a=m;break;case`checked`:u=m;break;case`defaultChecked`:d=m;break;case`value`:s=m;break;case`defaultValue`:c=m;break;case`children`:case`dangerouslySetInnerHTML`:if(m!=null)throw Error(i(137,t));break;default:m!==f&&$(e,t,p,m,r,f)}}Kt(e,s,c,l,u,d,o,a);return;case`select`:for(o in m=s=c=p=null,n)if(l=n[o],n.hasOwnProperty(o)&&l!=null)switch(o){case`value`:break;case`multiple`:m=l;default:r.hasOwnProperty(o)||$(e,t,o,null,r,l)}for(a in r)if(o=r[a],l=n[a],r.hasOwnProperty(a)&&(o!=null||l!=null))switch(a){case`value`:p=o;break;case`defaultValue`:c=o;break;case`multiple`:s=o;default:o!==l&&$(e,t,a,o,r,l)}t=c,n=s,r=m,p==null?!!r!=!!n&&(t==null?Yt(e,!!n,n?[]:``,!1):Yt(e,!!n,t,!0)):Yt(e,!!n,p,!1);return;case`textarea`:for(c in m=p=null,n)if(a=n[c],n.hasOwnProperty(c)&&a!=null&&!r.hasOwnProperty(c))switch(c){case`value`:break;case`children`:break;default:$(e,t,c,null,r,a)}for(s in r)if(a=r[s],o=n[s],r.hasOwnProperty(s)&&(a!=null||o!=null))switch(s){case`value`:p=a;break;case`defaultValue`:m=a;break;case`children`:break;case`dangerouslySetInnerHTML`:if(a!=null)throw Error(i(91));break;default:a!==o&&$(e,t,s,a,r,o)}Xt(e,p,m);return;case`option`:for(var h in n)if(p=n[h],n.hasOwnProperty(h)&&p!=null&&!r.hasOwnProperty(h))switch(h){case`selected`:e.selected=!1;break;default:$(e,t,h,null,r,p)}for(l in r)if(p=r[l],m=n[l],r.hasOwnProperty(l)&&p!==m&&(p!=null||m!=null))switch(l){case`selected`:e.selected=p&&typeof p!=`function`&&typeof p!=`symbol`;break;default:$(e,t,l,p,r,m)}return;case`img`:case`link`:case`area`:case`base`:case`br`:case`col`:case`embed`:case`hr`:case`keygen`:case`meta`:case`param`:case`source`:case`track`:case`wbr`:case`menuitem`:for(var g in n)p=n[g],n.hasOwnProperty(g)&&p!=null&&!r.hasOwnProperty(g)&&$(e,t,g,null,r,p);for(u in r)if(p=r[u],m=n[u],r.hasOwnProperty(u)&&p!==m&&(p!=null||m!=null))switch(u){case`children`:case`dangerouslySetInnerHTML`:if(p!=null)throw Error(i(137,t));break;default:$(e,t,u,p,r,m)}return;default:if(nn(t)){for(var _ in n)p=n[_],n.hasOwnProperty(_)&&p!==void 0&&!r.hasOwnProperty(_)&&Nd(e,t,_,void 0,r,p);for(d in r)p=r[d],m=n[d],!r.hasOwnProperty(d)||p===m||p===void 0&&m===void 0||Nd(e,t,d,p,r,m);return}}for(var v in n)p=n[v],n.hasOwnProperty(v)&&p!=null&&!r.hasOwnProperty(v)&&$(e,t,v,null,r,p);for(f in r)p=r[f],m=n[f],!r.hasOwnProperty(f)||p===m||p==null&&m==null||$(e,t,f,p,r,m)}function Id(e){switch(e){case`css`:case`script`:case`font`:case`img`:case`image`:case`input`:case`link`:return!0;default:return!1}}function Ld(){if(typeof performance.getEntriesByType==`function`){for(var e=0,t=0,n=performance.getEntriesByType(`resource`),r=0;r<n.length;r++){var i=n[r],a=i.transferSize,o=i.initiatorType,s=i.duration;if(a&&s&&Id(o)){for(o=0,s=i.responseEnd,r+=1;r<n.length;r++){var c=n[r],l=c.startTime;if(l>s)break;var u=c.transferSize,d=c.initiatorType;u&&Id(d)&&(c=c.responseEnd,o+=u*(c<s?1:(s-l)/(c-l)))}if(--r,t+=8*(a+o)/(i.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e==`number`)?e:5}var Rd=null,zd=null;function Bd(e){return e.nodeType===9?e:e.ownerDocument}function Vd(e){switch(e){case`http://www.w3.org/2000/svg`:return 1;case`http://www.w3.org/1998/Math/MathML`:return 2;default:return 0}}function Hd(e,t){if(e===0)switch(t){case`svg`:return 1;case`math`:return 2;default:return 0}return e===1&&t===`foreignObject`?0:e}function Ud(e,t){return e===`textarea`||e===`noscript`||typeof t.children==`string`||typeof t.children==`number`||typeof t.children==`bigint`||typeof t.dangerouslySetInnerHTML==`object`&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var Wd=null;function Gd(){var e=window.event;return e&&e.type===`popstate`?e!==Wd&&(Wd=e,!0):(Wd=null,!1)}var Kd=typeof setTimeout==`function`?setTimeout:void 0,qd=typeof clearTimeout==`function`?clearTimeout:void 0,Jd=typeof Promise==`function`?Promise:void 0,Yd=typeof queueMicrotask==`function`?queueMicrotask:Jd===void 0?Kd:function(e){return Jd.resolve(null).then(e).catch(Xd)};function Xd(e){setTimeout(function(){throw e})}function Zd(e){return e===`head`}function Qd(e,t){var n=t,r=0;do{var i=n.nextSibling;if(e.removeChild(n),i&&i.nodeType===8){if(n=i.data,n===`/$`||n===`/&`){if(r===0){e.removeChild(i),Np(t);return}r--}else if(n===`$`||n===`$?`||n===`$~`||n===`$!`||n===`&`)r++;else if(n===`html`)pf(e.ownerDocument.documentElement);else if(n===`head`){n=e.ownerDocument.head,pf(n);for(var a=n.firstChild;a;){var o=a.nextSibling,s=a.nodeName;a[bt]||s===`SCRIPT`||s===`STYLE`||s===`LINK`&&a.rel.toLowerCase()===`stylesheet`||n.removeChild(a),a=o}}else n===`body`&&pf(e.ownerDocument.body)}n=i}while(n);Np(t)}function $d(e,t){var n=e;e=0;do{var r=n.nextSibling;if(n.nodeType===1?t?(n._stashedDisplay=n.style.display,n.style.display=`none`):(n.style.display=n._stashedDisplay||``,n.getAttribute(`style`)===``&&n.removeAttribute(`style`)):n.nodeType===3&&(t?(n._stashedText=n.nodeValue,n.nodeValue=``):n.nodeValue=n._stashedText||``),r&&r.nodeType===8){if(n=r.data,n===`/$`){if(e===0)break;e--}else n!==`$`&&n!==`$?`&&n!==`$~`&&n!==`$!`||e++}n=r}while(n)}function ef(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var n=t;switch(t=t.nextSibling,n.nodeName){case`HTML`:case`HEAD`:case`BODY`:ef(n),xt(n);continue;case`SCRIPT`:case`STYLE`:continue;case`LINK`:if(n.rel.toLowerCase()===`stylesheet`)continue}e.removeChild(n)}}function tf(e,t,n,r){for(;e.nodeType===1;){var i=n;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!r&&(e.nodeName!==`INPUT`||e.type!==`hidden`))break}else if(!r){if(t===`input`&&e.type===`hidden`){var a=i.name==null?null:``+i.name;if(i.type===`hidden`&&e.getAttribute(`name`)===a)return e}else return e}else if(!e[bt])switch(t){case`meta`:if(!e.hasAttribute(`itemprop`))break;return e;case`link`:if(a=e.getAttribute(`rel`),a===`stylesheet`&&e.hasAttribute(`data-precedence`)||a!==i.rel||e.getAttribute(`href`)!==(i.href==null||i.href===``?null:i.href)||e.getAttribute(`crossorigin`)!==(i.crossOrigin==null?null:i.crossOrigin)||e.getAttribute(`title`)!==(i.title==null?null:i.title))break;return e;case`style`:if(e.hasAttribute(`data-precedence`))break;return e;case`script`:if(a=e.getAttribute(`src`),(a!==(i.src==null?null:i.src)||e.getAttribute(`type`)!==(i.type==null?null:i.type)||e.getAttribute(`crossorigin`)!==(i.crossOrigin==null?null:i.crossOrigin))&&a&&e.hasAttribute(`async`)&&!e.hasAttribute(`itemprop`))break;return e;default:return e}if(e=cf(e.nextSibling),e===null)break}return null}function nf(e,t,n){if(t===``)return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!==`INPUT`||e.type!==`hidden`)&&!n||(e=cf(e.nextSibling),e===null))return null;return e}function rf(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!==`INPUT`||e.type!==`hidden`)&&!t||(e=cf(e.nextSibling),e===null))return null;return e}function af(e){return e.data===`$?`||e.data===`$~`}function of(e){return e.data===`$!`||e.data===`$?`&&e.ownerDocument.readyState!==`loading`}function sf(e,t){var n=e.ownerDocument;if(e.data===`$~`)e._reactRetry=t;else if(e.data!==`$?`||n.readyState!==`loading`)t();else{var r=function(){t(),n.removeEventListener(`DOMContentLoaded`,r)};n.addEventListener(`DOMContentLoaded`,r),e._reactRetry=r}}function cf(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t===`$`||t===`$!`||t===`$?`||t===`$~`||t===`&`||t===`F!`||t===`F`)break;if(t===`/$`||t===`/&`)return null}}return e}var lf=null;function uf(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n===`/$`||n===`/&`){if(t===0)return cf(e.nextSibling);t--}else n!==`$`&&n!==`$!`&&n!==`$?`&&n!==`$~`&&n!==`&`||t++}e=e.nextSibling}return null}function df(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n===`$`||n===`$!`||n===`$?`||n===`$~`||n===`&`){if(t===0)return e;t--}else n!==`/$`&&n!==`/&`||t++}e=e.previousSibling}return null}function ff(e,t,n){switch(t=Bd(n),e){case`html`:if(e=t.documentElement,!e)throw Error(i(452));return e;case`head`:if(e=t.head,!e)throw Error(i(453));return e;case`body`:if(e=t.body,!e)throw Error(i(454));return e;default:throw Error(i(451))}}function pf(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);xt(e)}var mf=new Map,hf=new Set;function gf(e){return typeof e.getRootNode==`function`?e.getRootNode():e.nodeType===9?e:e.ownerDocument}var _f=O.d;O.d={f:vf,r:yf,D:Sf,C:Cf,L:wf,m:Tf,X:Df,S:Ef,M:Of};function vf(){var e=_f.f(),t=bu();return e||t}function yf(e){var t=Ct(e);t!==null&&t.tag===5&&t.type===`form`?ks(t):_f.r(e)}var bf=typeof document>`u`?null:document;function xf(e,t,n){var r=bf;if(r&&typeof t==`string`&&t){var i=Gt(t);i=`link[rel="`+e+`"][href="`+i+`"]`,typeof n==`string`&&(i+=`[crossorigin="`+n+`"]`),hf.has(i)||(hf.add(i),e={rel:e,crossOrigin:n,href:t},r.querySelector(i)===null&&(t=r.createElement(`link`),Pd(t,`link`,e),Et(t),r.head.appendChild(t)))}}function Sf(e){_f.D(e),xf(`dns-prefetch`,e,null)}function Cf(e,t){_f.C(e,t),xf(`preconnect`,e,t)}function wf(e,t,n){_f.L(e,t,n);var r=bf;if(r&&e&&t){var i=`link[rel="preload"][as="`+Gt(t)+`"]`;t===`image`&&n&&n.imageSrcSet?(i+=`[imagesrcset="`+Gt(n.imageSrcSet)+`"]`,typeof n.imageSizes==`string`&&(i+=`[imagesizes="`+Gt(n.imageSizes)+`"]`)):i+=`[href="`+Gt(e)+`"]`;var a=i;switch(t){case`style`:a=Af(e);break;case`script`:a=Pf(e)}mf.has(a)||(e=h({rel:`preload`,href:t===`image`&&n&&n.imageSrcSet?void 0:e,as:t},n),mf.set(a,e),r.querySelector(i)!==null||t===`style`&&r.querySelector(jf(a))||t===`script`&&r.querySelector(Ff(a))||(t=r.createElement(`link`),Pd(t,`link`,e),Et(t),r.head.appendChild(t)))}}function Tf(e,t){_f.m(e,t);var n=bf;if(n&&e){var r=t&&typeof t.as==`string`?t.as:`script`,i=`link[rel="modulepreload"][as="`+Gt(r)+`"][href="`+Gt(e)+`"]`,a=i;switch(r){case`audioworklet`:case`paintworklet`:case`serviceworker`:case`sharedworker`:case`worker`:case`script`:a=Pf(e)}if(!mf.has(a)&&(e=h({rel:`modulepreload`,href:e},t),mf.set(a,e),n.querySelector(i)===null)){switch(r){case`audioworklet`:case`paintworklet`:case`serviceworker`:case`sharedworker`:case`worker`:case`script`:if(n.querySelector(Ff(a)))return}r=n.createElement(`link`),Pd(r,`link`,e),Et(r),n.head.appendChild(r)}}}function Ef(e,t,n){_f.S(e,t,n);var r=bf;if(r&&e){var i=Tt(r).hoistableStyles,a=Af(e);t||=`default`;var o=i.get(a);if(!o){var s={loading:0,preload:null};if(o=r.querySelector(jf(a)))s.loading=5;else{e=h({rel:`stylesheet`,href:e,"data-precedence":t},n),(n=mf.get(a))&&Rf(e,n);var c=o=r.createElement(`link`);Et(c),Pd(c,`link`,e),c._p=new Promise(function(e,t){c.onload=e,c.onerror=t}),c.addEventListener(`load`,function(){s.loading|=1}),c.addEventListener(`error`,function(){s.loading|=2}),s.loading|=4,Lf(o,t,r)}o={type:`stylesheet`,instance:o,count:1,state:s},i.set(a,o)}}}function Df(e,t){_f.X(e,t);var n=bf;if(n&&e){var r=Tt(n).hoistableScripts,i=Pf(e),a=r.get(i);a||(a=n.querySelector(Ff(i)),a||(e=h({src:e,async:!0},t),(t=mf.get(i))&&zf(e,t),a=n.createElement(`script`),Et(a),Pd(a,`link`,e),n.head.appendChild(a)),a={type:`script`,instance:a,count:1,state:null},r.set(i,a))}}function Of(e,t){_f.M(e,t);var n=bf;if(n&&e){var r=Tt(n).hoistableScripts,i=Pf(e),a=r.get(i);a||(a=n.querySelector(Ff(i)),a||(e=h({src:e,async:!0,type:`module`},t),(t=mf.get(i))&&zf(e,t),a=n.createElement(`script`),Et(a),Pd(a,`link`,e),n.head.appendChild(a)),a={type:`script`,instance:a,count:1,state:null},r.set(i,a))}}function kf(e,t,n,r){var a=(a=he.current)?gf(a):null;if(!a)throw Error(i(446));switch(e){case`meta`:case`title`:return null;case`style`:return typeof n.precedence==`string`&&typeof n.href==`string`?(t=Af(n.href),n=Tt(a).hoistableStyles,r=n.get(t),r||(r={type:`style`,instance:null,count:0,state:null},n.set(t,r)),r):{type:`void`,instance:null,count:0,state:null};case`link`:if(n.rel===`stylesheet`&&typeof n.href==`string`&&typeof n.precedence==`string`){e=Af(n.href);var o=Tt(a).hoistableStyles,s=o.get(e);if(s||(a=a.ownerDocument||a,s={type:`stylesheet`,instance:null,count:0,state:{loading:0,preload:null}},o.set(e,s),(o=a.querySelector(jf(e)))&&!o._p&&(s.instance=o,s.state.loading=5),mf.has(e)||(n={rel:`preload`,as:`style`,href:n.href,crossOrigin:n.crossOrigin,integrity:n.integrity,media:n.media,hrefLang:n.hrefLang,referrerPolicy:n.referrerPolicy},mf.set(e,n),o||Nf(a,e,n,s.state))),t&&r===null)throw Error(i(528,``));return s}if(t&&r!==null)throw Error(i(529,``));return null;case`script`:return t=n.async,n=n.src,typeof n==`string`&&t&&typeof t!=`function`&&typeof t!=`symbol`?(t=Pf(n),n=Tt(a).hoistableScripts,r=n.get(t),r||(r={type:`script`,instance:null,count:0,state:null},n.set(t,r)),r):{type:`void`,instance:null,count:0,state:null};default:throw Error(i(444,e))}}function Af(e){return`href="`+Gt(e)+`"`}function jf(e){return`link[rel="stylesheet"][`+e+`]`}function Mf(e){return h({},e,{"data-precedence":e.precedence,precedence:null})}function Nf(e,t,n,r){e.querySelector(`link[rel="preload"][as="style"][`+t+`]`)?r.loading=1:(t=e.createElement(`link`),r.preload=t,t.addEventListener(`load`,function(){return r.loading|=1}),t.addEventListener(`error`,function(){return r.loading|=2}),Pd(t,`link`,n),Et(t),e.head.appendChild(t))}function Pf(e){return`[src="`+Gt(e)+`"]`}function Ff(e){return`script[async]`+e}function If(e,t,n){if(t.count++,t.instance===null)switch(t.type){case`style`:var r=e.querySelector(`style[data-href~="`+Gt(n.href)+`"]`);if(r)return t.instance=r,Et(r),r;var a=h({},n,{"data-href":n.href,"data-precedence":n.precedence,href:null,precedence:null});return r=(e.ownerDocument||e).createElement(`style`),Et(r),Pd(r,`style`,a),Lf(r,n.precedence,e),t.instance=r;case`stylesheet`:a=Af(n.href);var o=e.querySelector(jf(a));if(o)return t.state.loading|=4,t.instance=o,Et(o),o;r=Mf(n),(a=mf.get(a))&&Rf(r,a),o=(e.ownerDocument||e).createElement(`link`),Et(o);var s=o;return s._p=new Promise(function(e,t){s.onload=e,s.onerror=t}),Pd(o,`link`,r),t.state.loading|=4,Lf(o,n.precedence,e),t.instance=o;case`script`:return o=Pf(n.src),(a=e.querySelector(Ff(o)))?(t.instance=a,Et(a),a):(r=n,(a=mf.get(o))&&(r=h({},n),zf(r,a)),e=e.ownerDocument||e,a=e.createElement(`script`),Et(a),Pd(a,`link`,r),e.head.appendChild(a),t.instance=a);case`void`:return null;default:throw Error(i(443,t.type))}else t.type===`stylesheet`&&!(t.state.loading&4)&&(r=t.instance,t.state.loading|=4,Lf(r,n.precedence,e));return t.instance}function Lf(e,t,n){for(var r=n.querySelectorAll(`link[rel="stylesheet"][data-precedence],style[data-precedence]`),i=r.length?r[r.length-1]:null,a=i,o=0;o<r.length;o++){var s=r[o];if(s.dataset.precedence===t)a=s;else if(a!==i)break}a?a.parentNode.insertBefore(e,a.nextSibling):(t=n.nodeType===9?n.head:n,t.insertBefore(e,t.firstChild))}function Rf(e,t){e.crossOrigin??=t.crossOrigin,e.referrerPolicy??=t.referrerPolicy,e.title??=t.title}function zf(e,t){e.crossOrigin??=t.crossOrigin,e.referrerPolicy??=t.referrerPolicy,e.integrity??=t.integrity}var Bf=null;function Vf(e,t,n){if(Bf===null){var r=new Map,i=Bf=new Map;i.set(n,r)}else i=Bf,r=i.get(n),r||(r=new Map,i.set(n,r));if(r.has(e))return r;for(r.set(e,null),n=n.getElementsByTagName(e),i=0;i<n.length;i++){var a=n[i];if(!(a[bt]||a[pt]||e===`link`&&a.getAttribute(`rel`)===`stylesheet`)&&a.namespaceURI!==`http://www.w3.org/2000/svg`){var o=a.getAttribute(t)||``;o=e+o;var s=r.get(o);s?s.push(a):r.set(o,[a])}}return r}function Hf(e,t,n){e=e.ownerDocument||e,e.head.insertBefore(n,t===`title`?e.querySelector(`head > title`):null)}function Uf(e,t,n){if(n===1||t.itemProp!=null)return!1;switch(e){case`meta`:case`title`:return!0;case`style`:if(typeof t.precedence!=`string`||typeof t.href!=`string`||t.href===``)break;return!0;case`link`:if(typeof t.rel!=`string`||typeof t.href!=`string`||t.href===``||t.onLoad||t.onError)break;switch(t.rel){case`stylesheet`:return e=t.disabled,typeof t.precedence==`string`&&e==null;default:return!0}case`script`:if(t.async&&typeof t.async!=`function`&&typeof t.async!=`symbol`&&!t.onLoad&&!t.onError&&t.src&&typeof t.src==`string`)return!0}return!1}function Wf(e){return!(e.type===`stylesheet`&&!(e.state.loading&3))}function Gf(e,t,n,r){if(n.type===`stylesheet`&&(typeof r.media!=`string`||!1!==matchMedia(r.media).matches)&&!(n.state.loading&4)){if(n.instance===null){var i=Af(r.href),a=t.querySelector(jf(i));if(a){t=a._p,typeof t==`object`&&t&&typeof t.then==`function`&&(e.count++,e=Jf.bind(e),t.then(e,e)),n.state.loading|=4,n.instance=a,Et(a);return}a=t.ownerDocument||t,r=Mf(r),(i=mf.get(i))&&Rf(r,i),a=a.createElement(`link`),Et(a);var o=a;o._p=new Promise(function(e,t){o.onload=e,o.onerror=t}),Pd(a,`link`,r),n.instance=a}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(n,t),(t=n.state.preload)&&!(n.state.loading&3)&&(e.count++,n=Jf.bind(e),t.addEventListener(`load`,n),t.addEventListener(`error`,n))}}var Kf=0;function qf(e,t){return e.stylesheets&&e.count===0&&Xf(e,e.stylesheets),0<e.count||0<e.imgCount?function(n){var r=setTimeout(function(){if(e.stylesheets&&Xf(e,e.stylesheets),e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}},6e4+t);0<e.imgBytes&&Kf===0&&(Kf=62500*Ld());var i=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&Xf(e,e.stylesheets),e.unsuspend)){var t=e.unsuspend;e.unsuspend=null,t()}},(e.imgBytes>Kf?50:800)+t);return e.unsuspend=n,function(){e.unsuspend=null,clearTimeout(r),clearTimeout(i)}}:null}function Jf(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)Xf(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}}var Yf=null;function Xf(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,Yf=new Map,t.forEach(Zf,e),Yf=null,Jf.call(e))}function Zf(e,t){if(!(t.state.loading&4)){var n=Yf.get(e);if(n)var r=n.get(null);else{n=new Map,Yf.set(e,n);for(var i=e.querySelectorAll(`link[data-precedence],style[data-precedence]`),a=0;a<i.length;a++){var o=i[a];(o.nodeName===`LINK`||o.getAttribute(`media`)!==`not all`)&&(n.set(o.dataset.precedence,o),r=o)}r&&n.set(null,r)}i=t.instance,o=i.getAttribute(`data-precedence`),a=n.get(o)||r,a===r&&n.set(null,i),n.set(o,i),this.count++,r=Jf.bind(this),i.addEventListener(`load`,r),i.addEventListener(`error`,r),a?a.parentNode.insertBefore(i,a.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(i,e.firstChild)),t.state.loading|=4}}var Qf={$$typeof:S,Provider:null,Consumer:null,_currentValue:le,_currentValue2:le,_threadCount:0};function $f(e,t,n,r,i,a,o,s,c){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=nt(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=nt(0),this.hiddenUpdates=nt(null),this.identifierPrefix=r,this.onUncaughtError=i,this.onCaughtError=a,this.onRecoverableError=o,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=c,this.incompleteTransitions=new Map}function ep(e,t,n,r,i,a,o,s,c,l,u,d){return e=new $f(e,t,n,o,c,l,u,d,s),t=1,!0===a&&(t|=24),a=hi(3,null,null,t),e.current=a,a.stateNode=e,t=pa(),t.refCount++,e.pooledCache=t,t.refCount++,a.memoizedState={element:r,isDehydrated:n,cache:t},Ka(a),e}function tp(e){return e?(e=pi,e):pi}function np(e,t,n,r,i,a){i=tp(i),r.context===null?r.context=i:r.pendingContext=i,r=Ja(t),r.payload={element:n},a=a===void 0?null:a,a!==null&&(r.callback=a),n=Ya(e,r,t),n!==null&&(hu(n,e,t),Xa(n,e,t))}function rp(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function ip(e,t){rp(e,t),(e=e.alternate)&&rp(e,t)}function ap(e){if(e.tag===13||e.tag===31){var t=ui(e,67108864);t!==null&&hu(t,e,67108864),ip(e,67108864)}}function op(e){if(e.tag===13||e.tag===31){var t=pu();t=ct(t);var n=ui(e,t);n!==null&&hu(n,e,t),ip(e,t)}}var sp=!0;function cp(e,t,n,r){var i=D.T;D.T=null;var a=O.p;try{O.p=2,up(e,t,n,r)}finally{O.p=a,D.T=i}}function lp(e,t,n,r){var i=D.T;D.T=null;var a=O.p;try{O.p=8,up(e,t,n,r)}finally{O.p=a,D.T=i}}function up(e,t,n,r){if(sp){var i=dp(r);if(i===null)wd(e,t,r,fp,n),Cp(e,r);else if(Tp(i,e,t,n,r))r.stopPropagation();else if(Cp(e,r),t&4&&-1<Sp.indexOf(e)){for(;i!==null;){var a=Ct(i);if(a!==null)switch(a.tag){case 3:if(a=a.stateNode,a.current.memoizedState.isDehydrated){var o=Ze(a.pendingLanes);if(o!==0){var s=a;for(s.pendingLanes|=2,s.entangledLanes|=2;o;){var c=1<<31-We(o);s.entanglements[1]|=c,o&=~c}rd(a),!(G&6)&&(tu=Me()+500,id(0,!1))}}break;case 31:case 13:s=ui(a,2),s!==null&&hu(s,a,2),bu(),ip(a,2)}if(a=dp(r),a===null&&wd(e,t,r,fp,n),a===i)break;i=a}i!==null&&r.stopPropagation()}else wd(e,t,r,null,n)}}function dp(e){return e=ln(e),pp(e)}var fp=null;function pp(e){if(fp=null,e=St(e),e!==null){var t=o(e);if(t===null)e=null;else{var n=t.tag;if(n===13){if(e=s(t),e!==null)return e;e=null}else if(n===31){if(e=c(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return fp=e,null}function mp(e){switch(e){case`beforetoggle`:case`cancel`:case`click`:case`close`:case`contextmenu`:case`copy`:case`cut`:case`auxclick`:case`dblclick`:case`dragend`:case`dragstart`:case`drop`:case`focusin`:case`focusout`:case`input`:case`invalid`:case`keydown`:case`keypress`:case`keyup`:case`mousedown`:case`mouseup`:case`paste`:case`pause`:case`play`:case`pointercancel`:case`pointerdown`:case`pointerup`:case`ratechange`:case`reset`:case`resize`:case`seeked`:case`submit`:case`toggle`:case`touchcancel`:case`touchend`:case`touchstart`:case`volumechange`:case`change`:case`selectionchange`:case`textInput`:case`compositionstart`:case`compositionend`:case`compositionupdate`:case`beforeblur`:case`afterblur`:case`beforeinput`:case`blur`:case`fullscreenchange`:case`focus`:case`hashchange`:case`popstate`:case`select`:case`selectstart`:return 2;case`drag`:case`dragenter`:case`dragexit`:case`dragleave`:case`dragover`:case`mousemove`:case`mouseout`:case`mouseover`:case`pointermove`:case`pointerout`:case`pointerover`:case`scroll`:case`touchmove`:case`wheel`:case`mouseenter`:case`mouseleave`:case`pointerenter`:case`pointerleave`:return 8;case`message`:switch(Ne()){case Pe:return 2;case Fe:return 8;case Ie:case Le:return 32;case Re:return 268435456;default:return 32}default:return 32}}var hp=!1,gp=null,_p=null,vp=null,yp=new Map,bp=new Map,xp=[],Sp=`mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset`.split(` `);function Cp(e,t){switch(e){case`focusin`:case`focusout`:gp=null;break;case`dragenter`:case`dragleave`:_p=null;break;case`mouseover`:case`mouseout`:vp=null;break;case`pointerover`:case`pointerout`:yp.delete(t.pointerId);break;case`gotpointercapture`:case`lostpointercapture`:bp.delete(t.pointerId)}}function wp(e,t,n,r,i,a){return e===null||e.nativeEvent!==a?(e={blockedOn:t,domEventName:n,eventSystemFlags:r,nativeEvent:a,targetContainers:[i]},t!==null&&(t=Ct(t),t!==null&&ap(t)),e):(e.eventSystemFlags|=r,t=e.targetContainers,i!==null&&t.indexOf(i)===-1&&t.push(i),e)}function Tp(e,t,n,r,i){switch(t){case`focusin`:return gp=wp(gp,e,t,n,r,i),!0;case`dragenter`:return _p=wp(_p,e,t,n,r,i),!0;case`mouseover`:return vp=wp(vp,e,t,n,r,i),!0;case`pointerover`:var a=i.pointerId;return yp.set(a,wp(yp.get(a)||null,e,t,n,r,i)),!0;case`gotpointercapture`:return a=i.pointerId,bp.set(a,wp(bp.get(a)||null,e,t,n,r,i)),!0}return!1}function Ep(e){var t=St(e.target);if(t!==null){var n=o(t);if(n!==null){if(t=n.tag,t===13){if(t=s(n),t!==null){e.blockedOn=t,dt(e.priority,function(){op(n)});return}}else if(t===31){if(t=c(n),t!==null){e.blockedOn=t,dt(e.priority,function(){op(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function Dp(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=dp(e.nativeEvent);if(n===null){n=e.nativeEvent;var r=new n.constructor(n.type,n);cn=r,n.target.dispatchEvent(r),cn=null}else return t=Ct(n),t!==null&&ap(t),e.blockedOn=n,!1;t.shift()}return!0}function Op(e,t,n){Dp(e)&&n.delete(t)}function kp(){hp=!1,gp!==null&&Dp(gp)&&(gp=null),_p!==null&&Dp(_p)&&(_p=null),vp!==null&&Dp(vp)&&(vp=null),yp.forEach(Op),bp.forEach(Op)}function Ap(e,n){e.blockedOn===n&&(e.blockedOn=null,hp||(hp=!0,t.unstable_scheduleCallback(t.unstable_NormalPriority,kp)))}var jp=null;function Mp(e){jp!==e&&(jp=e,t.unstable_scheduleCallback(t.unstable_NormalPriority,function(){jp===e&&(jp=null);for(var t=0;t<e.length;t+=3){var n=e[t],r=e[t+1],i=e[t+2];if(typeof r!=`function`){if(pp(r||n)===null)continue;break}var a=Ct(n);a!==null&&(e.splice(t,3),t-=3,Ds(a,{pending:!0,data:i,method:n.method,action:r},r,i))}}))}function Np(e){function t(t){return Ap(t,e)}gp!==null&&Ap(gp,e),_p!==null&&Ap(_p,e),vp!==null&&Ap(vp,e),yp.forEach(t),bp.forEach(t);for(var n=0;n<xp.length;n++){var r=xp[n];r.blockedOn===e&&(r.blockedOn=null)}for(;0<xp.length&&(n=xp[0],n.blockedOn===null);)Ep(n),n.blockedOn===null&&xp.shift();if(n=(e.ownerDocument||e).$$reactFormReplay,n!=null)for(r=0;r<n.length;r+=3){var i=n[r],a=n[r+1],o=i[mt]||null;if(typeof a==`function`)o||Mp(n);else if(o){var s=null;if(a&&a.hasAttribute(`formAction`)){if(i=a,o=a[mt]||null)s=o.formAction;else if(pp(i)!==null)continue}else s=o.action;typeof s==`function`?n[r+1]=s:(n.splice(r,3),r-=3),Mp(n)}}}function Pp(){function e(e){e.canIntercept&&e.info===`react-transition`&&e.intercept({handler:function(){return new Promise(function(e){return i=e})},focusReset:`manual`,scroll:`manual`})}function t(){i!==null&&(i(),i=null),r||setTimeout(n,20)}function n(){if(!r&&!navigation.transition){var e=navigation.currentEntry;e&&e.url!=null&&navigation.navigate(e.url,{state:e.getState(),info:`react-transition`,history:`replace`})}}if(typeof navigation==`object`){var r=!1,i=null;return navigation.addEventListener(`navigate`,e),navigation.addEventListener(`navigatesuccess`,t),navigation.addEventListener(`navigateerror`,t),setTimeout(n,100),function(){r=!0,navigation.removeEventListener(`navigate`,e),navigation.removeEventListener(`navigatesuccess`,t),navigation.removeEventListener(`navigateerror`,t),i!==null&&(i(),i=null)}}}function Fp(e){this._internalRoot=e}Ip.prototype.render=Fp.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(i(409));var n=t.current;np(n,pu(),e,t,null,null)},Ip.prototype.unmount=Fp.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;np(e.current,2,null,e,null,null),bu(),t[ht]=null}};function Ip(e){this._internalRoot=e}Ip.prototype.unstable_scheduleHydration=function(e){if(e){var t=ut();e={blockedOn:null,target:e,priority:t};for(var n=0;n<xp.length&&t!==0&&t<xp[n].priority;n++);xp.splice(n,0,e),n===0&&Ep(e)}};var Lp=n.version;if(Lp!==`19.2.8`)throw Error(i(527,Lp,`19.2.8`));O.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render==`function`?Error(i(188)):(e=Object.keys(e).join(`,`),Error(i(268,e)));return e=d(t),e=e===null?null:p(e),e=e===null?null:e.stateNode,e};var Rp={bundleType:0,version:`19.2.8`,rendererPackageName:`react-dom`,currentDispatcherRef:D,reconcilerVersion:`19.2.8`};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`){var zp=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!zp.isDisabled&&zp.supportsFiber)try{Ve=zp.inject(Rp),He=zp}catch{}}e.createRoot=function(e,t){if(!a(e))throw Error(i(299));var n=!1,r=``,o=Xs,s=Zs,c=Qs;return t!=null&&(!0===t.unstable_strictMode&&(n=!0),t.identifierPrefix!==void 0&&(r=t.identifierPrefix),t.onUncaughtError!==void 0&&(o=t.onUncaughtError),t.onCaughtError!==void 0&&(s=t.onCaughtError),t.onRecoverableError!==void 0&&(c=t.onRecoverableError)),t=ep(e,1,!1,null,null,n,r,null,o,s,c,Pp),e[ht]=t.current,Sd(e),new Fp(t)}})),g=o(((e,t)=>{function n(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>`u`||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!=`function`))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(e){console.error(e)}}n(),t.exports=h()})),_=c(u(),1),v=g(),y=(...e)=>e.filter((e,t,n)=>!!e&&e.trim()!==``&&n.indexOf(e)===t).join(` `).trim(),b=e=>e.replace(/([a-z0-9])([A-Z])/g,`$1-$2`).toLowerCase(),x=e=>e.replace(/^([A-Z])|[\s-_]+(\w)/g,(e,t,n)=>n?n.toUpperCase():t.toLowerCase()),ee=e=>{let t=x(e);return t.charAt(0).toUpperCase()+t.slice(1)},S={xmlns:`http://www.w3.org/2000/svg`,width:24,height:24,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:2,strokeLinecap:`round`,strokeLinejoin:`round`},C=e=>{for(let t in e)if(t.startsWith(`aria-`)||t===`role`||t===`title`)return!0;return!1},te=(0,_.createContext)({}),w=()=>(0,_.useContext)(te),ne=(0,_.forwardRef)(({color:e,size:t,strokeWidth:n,absoluteStrokeWidth:r,className:i=``,children:a,iconNode:o,...s},c)=>{let{size:l=24,strokeWidth:u=2,absoluteStrokeWidth:d=!1,color:f=`currentColor`,className:p=``}=w()??{},m=r??d?Number(n??u)*24/Number(t??l):n??u;return(0,_.createElement)(`svg`,{ref:c,...S,width:t??l??S.width,height:t??l??S.height,stroke:e??f,strokeWidth:m,className:y(`lucide`,p,i),...!a&&!C(s)&&{"aria-hidden":`true`},...s},[...o.map(([e,t])=>(0,_.createElement)(e,t)),...Array.isArray(a)?a:[a]])}),T=(e,t)=>{let n=(0,_.forwardRef)(({className:n,...r},i)=>(0,_.createElement)(ne,{ref:i,iconNode:t,className:y(`lucide-${b(ee(e))}`,`lucide-${e}`,n),...r}));return n.displayName=ee(e),n},re=T(`arrow-left`,[[`path`,{d:`m12 19-7-7 7-7`,key:`1l729n`}],[`path`,{d:`M19 12H5`,key:`x3x0zl`}]]),ie=T(`arrow-right`,[[`path`,{d:`M5 12h14`,key:`1ays0h`}],[`path`,{d:`m12 5 7 7-7 7`,key:`xquz4c`}]]),ae=T(`bell`,[[`path`,{d:`M10.268 21a2 2 0 0 0 3.464 0`,key:`vwvbt9`}],[`path`,{d:`M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326`,key:`11g9vi`}]]),oe=T(`car`,[[`path`,{d:`M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2`,key:`5owen`}],[`circle`,{cx:`7`,cy:`17`,r:`2`,key:`u2ysq9`}],[`path`,{d:`M9 17h6`,key:`r8uit2`}],[`circle`,{cx:`17`,cy:`17`,r:`2`,key:`axvx0g`}]]),se=T(`chevron-down`,[[`path`,{d:`m6 9 6 6 6-6`,key:`qrunsl`}]]),E=T(`circle-check`,[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`path`,{d:`m16 9-5.5 5.5L8 12`,key:`xofnsj`}]]),ce=T(`circle-question-mark`,[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`path`,{d:`M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3`,key:`1u773s`}],[`path`,{d:`M12 17h.01`,key:`p32p05`}]]),D=T(`disc`,[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`circle`,{cx:`12`,cy:`12`,r:`2`,key:`1c9p78`}]]),O=T(`droplets`,[[`path`,{d:`M7 16.3c2.2 0 4-1.83 4-4.05 0-1.16-.57-2.26-1.71-3.19S7.29 6.75 7 5.3c-.29 1.45-1.14 2.84-2.29 3.76S3 11.1 3 12.25c0 2.22 1.8 4.05 4 4.05z`,key:`1ptgy4`}],[`path`,{d:`M12.56 6.6A10.97 10.97 0 0 0 14 3.02c.5 2.5 2 4.9 4 6.5s3 3.5 3 5.5a6.98 6.98 0 0 1-11.91 4.97`,key:`1sl1rz`}]]),le=T(`house`,[[`path`,{d:`M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8`,key:`5wwlr5`}],[`path`,{d:`M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z`,key:`r6nss1`}]]),ue=T(`lock`,[[`rect`,{width:`18`,height:`11`,x:`3`,y:`11`,rx:`2`,ry:`2`,key:`1w4ew1`}],[`path`,{d:`M7 11V7a5 5 0 0 1 10 0v4`,key:`fwvmzm`}]]),de=T(`log-out`,[[`path`,{d:`m16 17 5-5-5-5`,key:`1bji2h`}],[`path`,{d:`M21 12H9`,key:`dn1m92`}],[`path`,{d:`M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4`,key:`1uf3rs`}]]),fe=T(`mail`,[[`path`,{d:`m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7`,key:`132q7q`}],[`rect`,{x:`2`,y:`4`,width:`20`,height:`16`,rx:`2`,key:`izxlao`}]]),k=T(`map-pin`,[[`path`,{d:`M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0`,key:`1r0f0z`}],[`circle`,{cx:`12`,cy:`10`,r:`3`,key:`ilqhr7`}]]),A=T(`menu`,[[`path`,{d:`M4 5h16`,key:`1tepv9`}],[`path`,{d:`M4 12h16`,key:`1lakjw`}],[`path`,{d:`M4 19h16`,key:`1djgab`}]]),pe=T(`package`,[[`path`,{d:`M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z`,key:`1a0edw`}],[`path`,{d:`M12 22V12`,key:`d0xqtd`}],[`polyline`,{points:`3.29 7 12 12 20.71 7`,key:`ousv84`}],[`path`,{d:`m7.5 4.27 9 5.15`,key:`1c824w`}]]),me=T(`phone-call`,[[`path`,{d:`M13 2a9 9 0 0 1 9 9`,key:`1itnx2`}],[`path`,{d:`M13 6a5 5 0 0 1 5 5`,key:`11nki7`}],[`path`,{d:`M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384`,key:`9njp5v`}]]),he=T(`phone-off`,[[`path`,{d:`M10.1 13.9a14 14 0 0 0 3.732 2.668 1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2 18 18 0 0 1-12.728-5.272`,key:`1wngk7`}],[`path`,{d:`M22 2 2 22`,key:`y4kqgn`}],[`path`,{d:`M4.76 13.582A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 .244.473`,key:`10hv5p`}]]),ge=T(`printer`,[[`path`,{d:`M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2`,key:`143wyd`}],[`path`,{d:`M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6`,key:`1itne7`}],[`rect`,{x:`6`,y:`14`,width:`12`,height:`8`,rx:`1`,key:`1ue0tg`}]]),_e=T(`qr-code`,[[`rect`,{width:`5`,height:`5`,x:`3`,y:`3`,rx:`1`,key:`1tu5fj`}],[`rect`,{width:`5`,height:`5`,x:`16`,y:`3`,rx:`1`,key:`1v8r4q`}],[`rect`,{width:`5`,height:`5`,x:`3`,y:`16`,rx:`1`,key:`1x03jg`}],[`path`,{d:`M21 16h-3a2 2 0 0 0-2 2v3`,key:`177gqh`}],[`path`,{d:`M21 21v.01`,key:`ents32`}],[`path`,{d:`M12 7v3a2 2 0 0 1-2 2H7`,key:`8crl2c`}],[`path`,{d:`M3 12h.01`,key:`nlz23k`}],[`path`,{d:`M12 3h.01`,key:`n36tog`}],[`path`,{d:`M12 16v.01`,key:`133mhm`}],[`path`,{d:`M16 12h1`,key:`1slzba`}],[`path`,{d:`M21 12v.01`,key:`1lwtk9`}],[`path`,{d:`M12 21v-1`,key:`1880an`}]]),ve=T(`receipt`,[[`path`,{d:`M12 17V7`,key:`pyj7ub`}],[`path`,{d:`M16 8h-6a2 2 0 0 0 0 4h4a2 2 0 0 1 0 4H8`,key:`1elt7d`}],[`path`,{d:`M4 3a1 1 0 0 1 1-1 1.3 1.3 0 0 1 .7.2l.933.6a1.3 1.3 0 0 0 1.4 0l.934-.6a1.3 1.3 0 0 1 1.4 0l.933.6a1.3 1.3 0 0 0 1.4 0l.933-.6a1.3 1.3 0 0 1 1.4 0l.934.6a1.3 1.3 0 0 0 1.4 0l.933-.6A1.3 1.3 0 0 1 19 2a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1 1.3 1.3 0 0 1-.7-.2l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.934.6a1.3 1.3 0 0 1-1.4 0l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-1.4 0l-.934-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-.7.2 1 1 0 0 1-1-1z`,key:`ycz6yz`}]]),ye=T(`search`,[[`path`,{d:`m21 21-4.34-4.34`,key:`14j7rj`}],[`circle`,{cx:`11`,cy:`11`,r:`8`,key:`4ej97u`}]]),be=T(`shield-check`,[[`path`,{d:`M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z`,key:`oel41y`}],[`path`,{d:`m9 12 2 2 4-4`,key:`dzmm74`}]]),xe=T(`shield`,[[`path`,{d:`M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z`,key:`oel41y`}]]),Se=T(`shopping-bag`,[[`path`,{d:`M16 10a4 4 0 0 1-8 0`,key:`1ltviw`}],[`path`,{d:`M3.103 6.034h17.794`,key:`awc11p`}],[`path`,{d:`M3.4 5.467a2 2 0 0 0-.4 1.2V20a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6.667a2 2 0 0 0-.4-1.2l-2-2.667A2 2 0 0 0 17 2H7a2 2 0 0 0-1.6.8z`,key:`o988cm`}]]),Ce=T(`smartphone`,[[`rect`,{width:`14`,height:`20`,x:`5`,y:`2`,rx:`2`,ry:`2`,key:`1yt0o3`}],[`path`,{d:`M12 18h.01`,key:`mhygvu`}]]),we=T(`sparkles`,[[`path`,{d:`M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z`,key:`1s2grr`}],[`path`,{d:`M20 2v4`,key:`1rf3ol`}],[`path`,{d:`M22 4h-4`,key:`gwowj6`}],[`circle`,{cx:`4`,cy:`20`,r:`2`,key:`6kqj1y`}]]),Te=T(`triangle-alert`,[[`path`,{d:`m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3`,key:`wmoenq`}],[`path`,{d:`M12 9v4`,key:`juzpu7`}],[`path`,{d:`M12 17h.01`,key:`p32p05`}]]),Ee=T(`truck`,[[`path`,{d:`M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2`,key:`wrbu53`}],[`path`,{d:`M15 18H9`,key:`1lyqi6`}],[`path`,{d:`M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14`,key:`lysw3i`}],[`circle`,{cx:`17`,cy:`18`,r:`2`,key:`332jqn`}],[`circle`,{cx:`7`,cy:`18`,r:`2`,key:`19iecd`}]]),De=T(`user`,[[`path`,{d:`M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2`,key:`975kel`}],[`circle`,{cx:`12`,cy:`7`,r:`4`,key:`17ys0d`}]]),Oe=T(`wrench`,[[`path`,{d:`M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984z`,key:`1ngwbx`}]]),ke=T(`x`,[[`path`,{d:`M18 6 6 18`,key:`1bl5f8`}],[`path`,{d:`m6 6 12 12`,key:`d8bk6v`}]]),Ae=o((e=>{var t=Symbol.for(`react.transitional.element`),n=Symbol.for(`react.fragment`);function r(e,n,r){var i=null;if(r!==void 0&&(i=``+r),n.key!==void 0&&(i=``+n.key),`key`in n)for(var a in r={},n)a!==`key`&&(r[a]=n[a]);else r=n;return n=r.ref,{$$typeof:t,type:e,key:i,ref:n===void 0?null:n,props:r}}e.Fragment=n,e.jsx=r,e.jsxs=r})),j=o(((e,t)=>{t.exports=Ae()}))();function je({onOpenOrderTag:e,onOpenAccount:t,onNavigate:n,currentView:r}){let[i,a]=(0,_.useState)(!1),[o,s]=(0,_.useState)(!1);(0,_.useEffect)(()=>{let e=()=>{window.scrollY>20?a(!0):a(!1)};return window.addEventListener(`scroll`,e),()=>window.removeEventListener(`scroll`,e)},[]);let c=(e,t,r)=>{e.preventDefault(),s(!1),n&&n(t),r&&t===`home`&&setTimeout(()=>{let e=document.getElementById(r);e&&e.scrollIntoView({behavior:`smooth`})},50)};return(0,j.jsxs)(`header`,{className:`navbar-header ${i?`scrolled`:``}`,children:[(0,j.jsxs)(`div`,{className:`container nav-container`,children:[(0,j.jsx)(`a`,{href:`/`,className:`brand-logo`,onClick:e=>c(e,`home`),children:(0,j.jsx)(`img`,{src:`/carfrndlogo.png`,alt:`CarFrnd Logo`,className:`brand-logo-img`})}),(0,j.jsxs)(`nav`,{className:`desktop-nav`,children:[(0,j.jsxs)(`a`,{href:`#app-showcase`,className:`nav-link ${r===`home`?`active`:``}`,onClick:e=>c(e,`home`,`app-showcase`),children:[(0,j.jsx)(Ce,{className:`nav-icon`,size:16}),`How It Works`]}),(0,j.jsxs)(`a`,{href:`#live-services`,className:`nav-link`,onClick:e=>c(e,`home`,`live-services`),children:[(0,j.jsx)(Oe,{className:`nav-icon`,size:16}),`Auto Services`]}),(0,j.jsxs)(`a`,{href:`/track-order`,className:`nav-link ${r===`track-order`?`active-nav`:``}`,onClick:e=>c(e,`track-order`),children:[(0,j.jsx)(Ee,{className:`nav-icon`,size:16}),`Track Order`]}),(0,j.jsxs)(`a`,{href:`/activate-tag`,className:`nav-link ${r===`activate-tag`?`active-nav`:``}`,onClick:e=>c(e,`activate-tag`),children:[(0,j.jsx)(we,{className:`nav-icon`,size:16}),`Activate Tag`]}),(0,j.jsxs)(`a`,{href:`/bill`,className:`nav-link ${r===`bill`?`active-nav`:``}`,onClick:e=>c(e,`bill`),children:[(0,j.jsx)(ve,{className:`nav-icon`,size:16}),`Bill`]})]}),(0,j.jsxs)(`div`,{className:`nav-actions`,children:[(0,j.jsxs)(`button`,{className:`btn-primary btn-nav-cta`,onClick:e,children:[(0,j.jsx)(we,{size:15}),(0,j.jsx)(`span`,{children:`Get Tag ₹450`})]}),(0,j.jsxs)(`button`,{className:`btn-account-nav`,onClick:t,title:`My Account`,children:[(0,j.jsx)(De,{size:15}),(0,j.jsx)(`span`,{children:`Account`})]}),(0,j.jsx)(`button`,{className:`mobile-menu-btn`,onClick:()=>s(!o),"aria-label":`Toggle Menu`,children:o?(0,j.jsx)(ke,{size:26,color:`#0F172A`}):(0,j.jsx)(A,{size:26,color:`#0F172A`})})]})]}),o&&(0,j.jsxs)(`div`,{className:`mobile-drawer`,children:[(0,j.jsx)(`a`,{href:`/`,onClick:e=>c(e,`home`),children:`Home`}),(0,j.jsx)(`a`,{href:`#app-showcase`,onClick:e=>c(e,`home`,`app-showcase`),children:`How CarFrnd Tag Works`}),(0,j.jsx)(`a`,{href:`#live-services`,onClick:e=>c(e,`home`,`live-services`),children:`Auto Services`}),(0,j.jsx)(`a`,{href:`/track-order`,onClick:e=>c(e,`track-order`),children:`Track Order`}),(0,j.jsx)(`a`,{href:`/activate-tag`,onClick:e=>c(e,`activate-tag`),children:`Activate Tag`}),(0,j.jsx)(`a`,{href:`/bill`,onClick:e=>c(e,`bill`),children:`Bill / Tax Invoice`}),(0,j.jsx)(`a`,{href:`#`,onClick:e=>{e.preventDefault(),s(!1),t&&t()},children:`My Account`}),(0,j.jsx)(`div`,{className:`mobile-drawer-actions`,children:(0,j.jsx)(`button`,{className:`btn-primary full-w`,onClick:()=>{s(!1),e()},children:`Get Your CarFrnd Tag — ₹450`})})]}),(0,j.jsx)(`style`,{children:`
        .navbar-header {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          z-index: 100;
          height: 68px;
          display: flex;
          align-items: center;
          transition: all 0.3s ease;
          background: rgba(255, 255, 255, 0.98);
          backdrop-filter: blur(16px);
          -webkit-backdrop-filter: blur(16px);
          border-bottom: 1px solid rgba(226, 232, 240, 0.9);
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.03);
        }

        .navbar-header.scrolled {
          height: 62px;
          background: rgba(255, 255, 255, 0.99);
          border-bottom: 1px solid rgba(255, 43, 133, 0.2);
          box-shadow: 0 4px 15px rgba(15, 23, 42, 0.06);
        }

        .nav-container {
          display: flex;
          align-items: center;
          justify-content: space-between;
          width: 94%;
          max-width: 1360px;
          margin: 0 auto;
        }

        .brand-logo {
          display: flex;
          align-items: center;
          text-decoration: none;
          height: 52px;
          min-width: 175px;
          margin-right: 20px;
          overflow: visible;
        }

        .brand-logo-img {
          height: 60px;
          width: auto;
          object-fit: contain;
          transform: scale(2.2);
          transform-origin: left center;
          transition: transform 0.2s ease;
        }

        .brand-logo-img:hover {
          transform: scale(2.28);
        }

        .desktop-nav {
          display: flex;
          align-items: center;
          gap: 28px;
        }

        .nav-link {
          color: #334155;
          text-decoration: none;
          font-size: 0.92rem;
          font-weight: 700;
          display: flex;
          align-items: center;
          gap: 6px;
          transition: all 0.2s ease;
        }

        .nav-link:hover, .nav-link.active-nav {
          color: var(--magenta);
        }

        .nav-icon {
          color: var(--magenta);
        }

        .nav-badge {
          font-size: 0.62rem;
          font-weight: 900;
          background: #ECFDF5;
          color: #059669;
          border: 1px solid #A7F3D0;
          padding: 1px 5px;
          border-radius: 4px;
          margin-left: 2px;
        }

        .nav-actions {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .btn-scanner-shortcut {
          background: #FFF0F6;
          color: var(--magenta);
          border: 1px solid var(--magenta-border);
          padding: 8px 14px;
          border-radius: 10px;
          font-weight: 700;
          font-size: 0.85rem;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 6px;
          transition: all 0.2s ease;
        }

        .btn-scanner-shortcut:hover {
          background: var(--magenta);
          color: #FFFFFF;
          border-color: var(--magenta);
        }

        .btn-nav-cta {
          padding: 9px 18px;
          font-size: 0.86rem;
          border-radius: 10px;
        }

        .btn-account-nav {
          background: #F8FAFC;
          color: #1E293B;
          border: 1px solid #CBD5E1;
          padding: 8px 14px;
          border-radius: 10px;
          font-weight: 700;
          font-size: 0.85rem;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 6px;
          transition: all 0.2s ease;
        }

        .btn-account-nav:hover {
          background: var(--magenta-light);
          color: var(--magenta);
          border-color: var(--magenta-border);
        }

        .mobile-menu-btn {
          display: none;
          background: none;
          border: none;
          cursor: pointer;
          padding: 4px;
        }

        .mobile-drawer {
          position: absolute;
          top: 100%;
          left: 0;
          right: 0;
          background: #FFFFFF;
          border-bottom: 1px solid var(--border-light);
          padding: 20px 24px;
          display: flex;
          flex-direction: column;
          gap: 14px;
          box-shadow: 0 15px 35px rgba(0,0,0,0.1);
        }

        .mobile-drawer a {
          color: #0F172A;
          text-decoration: none;
          font-weight: 700;
          font-size: 1rem;
          padding: 8px 0;
          border-bottom: 1px solid #F1F5F9;
        }

        .mobile-drawer-actions {
          display: flex;
          flex-direction: column;
          gap: 10px;
          margin-top: 10px;
        }

        .full-w {
          width: 100%;
        }

        @media (max-width: 900px) {
          .navbar-header {
            height: 68px;
          }
          .navbar-header.scrolled {
            height: 62px;
          }
          .desktop-nav {
            display: none;
          }
          .mobile-menu-btn {
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .btn-scanner-shortcut {
            display: none;
          }
          .btn-nav-cta {
            display: none; /* Hide on mobile so it doesn't overlap logo/hamburger */
          }
          .btn-account-nav {
            display: none;
          }
          .brand-logo {
            height: 48px;
            min-width: 150px;
            margin-right: 0;
            margin-left: -12px;
          }
          .brand-logo-img {
            height: 52px;
            transform: scale(2.2);
            transform-origin: left center;
          }
        }
      `})]})}var Me=Object.defineProperty,Ne=Object.getOwnPropertySymbols,Pe=Object.prototype.hasOwnProperty,Fe=Object.prototype.propertyIsEnumerable,Ie=(e,t,n)=>t in e?Me(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n,Le=(e,t)=>{for(var n in t||={})Pe.call(t,n)&&Ie(e,n,t[n]);if(Ne)for(var n of Ne(t))Fe.call(t,n)&&Ie(e,n,t[n]);return e},Re=(e,t)=>{var n={};for(var r in e)Pe.call(e,r)&&t.indexOf(r)<0&&(n[r]=e[r]);if(e!=null&&Ne)for(var r of Ne(e))t.indexOf(r)<0&&Fe.call(e,r)&&(n[r]=e[r]);return n},ze;(e=>{let t=class t{constructor(e,n,r,a){if(this.version=e,this.errorCorrectionLevel=n,this.modules=[],this.isFunction=[],e<t.MIN_VERSION||e>t.MAX_VERSION)throw RangeError(`Version value out of range`);if(a<-1||a>7)throw RangeError(`Mask value out of range`);this.size=e*4+17;let o=[];for(let e=0;e<this.size;e++)o.push(!1);for(let e=0;e<this.size;e++)this.modules.push(o.slice()),this.isFunction.push(o.slice());this.drawFunctionPatterns();let s=this.addEccAndInterleave(r);if(this.drawCodewords(s),a==-1){let e=1e9;for(let t=0;t<8;t++){this.applyMask(t),this.drawFormatBits(t);let n=this.getPenaltyScore();n<e&&(a=t,e=n),this.applyMask(t)}}i(0<=a&&a<=7),this.mask=a,this.applyMask(a),this.drawFormatBits(a),this.isFunction=[]}static encodeText(n,r){let i=e.QrSegment.makeSegments(n);return t.encodeSegments(i,r)}static encodeBinary(n,r){let i=e.QrSegment.makeBytes(n);return t.encodeSegments([i],r)}static encodeSegments(e,r,a=1,s=40,c=-1,l=!0){if(!(t.MIN_VERSION<=a&&a<=s&&s<=t.MAX_VERSION)||c<-1||c>7)throw RangeError(`Invalid value`);let u,d;for(u=a;;u++){let n=t.getNumDataCodewords(u,r)*8,i=o.getTotalBits(e,u);if(i<=n){d=i;break}if(u>=s)throw RangeError(`Data too long`)}for(let e of[t.Ecc.MEDIUM,t.Ecc.QUARTILE,t.Ecc.HIGH])l&&d<=t.getNumDataCodewords(u,e)*8&&(r=e);let f=[];for(let t of e){n(t.mode.modeBits,4,f),n(t.numChars,t.mode.numCharCountBits(u),f);for(let e of t.getData())f.push(e)}i(f.length==d);let p=t.getNumDataCodewords(u,r)*8;i(f.length<=p),n(0,Math.min(4,p-f.length),f),n(0,(8-f.length%8)%8,f),i(f.length%8==0);for(let e=236;f.length<p;e^=253)n(e,8,f);let m=[];for(;m.length*8<f.length;)m.push(0);return f.forEach((e,t)=>m[t>>>3]|=e<<7-(t&7)),new t(u,r,m,c)}getModule(e,t){return 0<=e&&e<this.size&&0<=t&&t<this.size&&this.modules[t][e]}getModules(){return this.modules}drawFunctionPatterns(){for(let e=0;e<this.size;e++)this.setFunctionModule(6,e,e%2==0),this.setFunctionModule(e,6,e%2==0);this.drawFinderPattern(3,3),this.drawFinderPattern(this.size-4,3),this.drawFinderPattern(3,this.size-4);let e=this.getAlignmentPatternPositions(),t=e.length;for(let n=0;n<t;n++)for(let r=0;r<t;r++)n==0&&r==0||n==0&&r==t-1||n==t-1&&r==0||this.drawAlignmentPattern(e[n],e[r]);this.drawFormatBits(0),this.drawVersion()}drawFormatBits(e){let t=this.errorCorrectionLevel.formatBits<<3|e,n=t;for(let e=0;e<10;e++)n=n<<1^(n>>>9)*1335;let a=(t<<10|n)^21522;i(!(a>>>15));for(let e=0;e<=5;e++)this.setFunctionModule(8,e,r(a,e));this.setFunctionModule(8,7,r(a,6)),this.setFunctionModule(8,8,r(a,7)),this.setFunctionModule(7,8,r(a,8));for(let e=9;e<15;e++)this.setFunctionModule(14-e,8,r(a,e));for(let e=0;e<8;e++)this.setFunctionModule(this.size-1-e,8,r(a,e));for(let e=8;e<15;e++)this.setFunctionModule(8,this.size-15+e,r(a,e));this.setFunctionModule(8,this.size-8,!0)}drawVersion(){if(this.version<7)return;let e=this.version;for(let t=0;t<12;t++)e=e<<1^(e>>>11)*7973;let t=this.version<<12|e;i(!(t>>>18));for(let e=0;e<18;e++){let n=r(t,e),i=this.size-11+e%3,a=Math.floor(e/3);this.setFunctionModule(i,a,n),this.setFunctionModule(a,i,n)}}drawFinderPattern(e,t){for(let n=-4;n<=4;n++)for(let r=-4;r<=4;r++){let i=Math.max(Math.abs(r),Math.abs(n)),a=e+r,o=t+n;0<=a&&a<this.size&&0<=o&&o<this.size&&this.setFunctionModule(a,o,i!=2&&i!=4)}}drawAlignmentPattern(e,t){for(let n=-2;n<=2;n++)for(let r=-2;r<=2;r++)this.setFunctionModule(e+r,t+n,Math.max(Math.abs(r),Math.abs(n))!=1)}setFunctionModule(e,t,n){this.modules[t][e]=n,this.isFunction[t][e]=!0}addEccAndInterleave(e){let n=this.version,r=this.errorCorrectionLevel;if(e.length!=t.getNumDataCodewords(n,r))throw RangeError(`Invalid argument`);let a=t.NUM_ERROR_CORRECTION_BLOCKS[r.ordinal][n],o=t.ECC_CODEWORDS_PER_BLOCK[r.ordinal][n],s=Math.floor(t.getNumRawDataModules(n)/8),c=a-s%a,l=Math.floor(s/a),u=[],d=t.reedSolomonComputeDivisor(o);for(let n=0,r=0;n<a;n++){let i=e.slice(r,r+l-o+(n<c?0:1));r+=i.length;let a=t.reedSolomonComputeRemainder(i,d);n<c&&i.push(0),u.push(i.concat(a))}let f=[];for(let e=0;e<u[0].length;e++)u.forEach((t,n)=>{(e!=l-o||n>=c)&&f.push(t[e])});return i(f.length==s),f}drawCodewords(e){if(e.length!=Math.floor(t.getNumRawDataModules(this.version)/8))throw RangeError(`Invalid argument`);let n=0;for(let t=this.size-1;t>=1;t-=2){t==6&&(t=5);for(let i=0;i<this.size;i++)for(let a=0;a<2;a++){let o=t-a,s=t+1&2?i:this.size-1-i;!this.isFunction[s][o]&&n<e.length*8&&(this.modules[s][o]=r(e[n>>>3],7-(n&7)),n++)}}i(n==e.length*8)}applyMask(e){if(e<0||e>7)throw RangeError(`Mask value out of range`);for(let t=0;t<this.size;t++)for(let n=0;n<this.size;n++){let r;switch(e){case 0:r=(n+t)%2==0;break;case 1:r=t%2==0;break;case 2:r=n%3==0;break;case 3:r=(n+t)%3==0;break;case 4:r=(Math.floor(n/3)+Math.floor(t/2))%2==0;break;case 5:r=n*t%2+n*t%3==0;break;case 6:r=(n*t%2+n*t%3)%2==0;break;case 7:r=((n+t)%2+n*t%3)%2==0;break;default:throw Error(`Unreachable`)}!this.isFunction[t][n]&&r&&(this.modules[t][n]=!this.modules[t][n])}}getPenaltyScore(){let e=0;for(let n=0;n<this.size;n++){let r=!1,i=0,a=[0,0,0,0,0,0,0];for(let o=0;o<this.size;o++)this.modules[n][o]==r?(i++,i==5?e+=t.PENALTY_N1:i>5&&e++):(this.finderPenaltyAddHistory(i,a),r||(e+=this.finderPenaltyCountPatterns(a)*t.PENALTY_N3),r=this.modules[n][o],i=1);e+=this.finderPenaltyTerminateAndCount(r,i,a)*t.PENALTY_N3}for(let n=0;n<this.size;n++){let r=!1,i=0,a=[0,0,0,0,0,0,0];for(let o=0;o<this.size;o++)this.modules[o][n]==r?(i++,i==5?e+=t.PENALTY_N1:i>5&&e++):(this.finderPenaltyAddHistory(i,a),r||(e+=this.finderPenaltyCountPatterns(a)*t.PENALTY_N3),r=this.modules[o][n],i=1);e+=this.finderPenaltyTerminateAndCount(r,i,a)*t.PENALTY_N3}for(let n=0;n<this.size-1;n++)for(let r=0;r<this.size-1;r++){let i=this.modules[n][r];i==this.modules[n][r+1]&&i==this.modules[n+1][r]&&i==this.modules[n+1][r+1]&&(e+=t.PENALTY_N2)}let n=0;for(let e of this.modules)n=e.reduce((e,t)=>e+ +!!t,n);let r=this.size*this.size,a=Math.ceil(Math.abs(n*20-r*10)/r)-1;return i(0<=a&&a<=9),e+=a*t.PENALTY_N4,i(0<=e&&e<=2568888),e}getAlignmentPatternPositions(){if(this.version==1)return[];{let e=Math.floor(this.version/7)+2,t=this.version==32?26:Math.ceil((this.version*4+4)/(e*2-2))*2,n=[6];for(let r=this.size-7;n.length<e;r-=t)n.splice(1,0,r);return n}}static getNumRawDataModules(e){if(e<t.MIN_VERSION||e>t.MAX_VERSION)throw RangeError(`Version number out of range`);let n=(16*e+128)*e+64;if(e>=2){let t=Math.floor(e/7)+2;n-=(25*t-10)*t-55,e>=7&&(n-=36)}return i(208<=n&&n<=29648),n}static getNumDataCodewords(e,n){return Math.floor(t.getNumRawDataModules(e)/8)-t.ECC_CODEWORDS_PER_BLOCK[n.ordinal][e]*t.NUM_ERROR_CORRECTION_BLOCKS[n.ordinal][e]}static reedSolomonComputeDivisor(e){if(e<1||e>255)throw RangeError(`Degree out of range`);let n=[];for(let t=0;t<e-1;t++)n.push(0);n.push(1);let r=1;for(let i=0;i<e;i++){for(let e=0;e<n.length;e++)n[e]=t.reedSolomonMultiply(n[e],r),e+1<n.length&&(n[e]^=n[e+1]);r=t.reedSolomonMultiply(r,2)}return n}static reedSolomonComputeRemainder(e,n){let r=n.map(e=>0);for(let i of e){let e=i^r.shift();r.push(0),n.forEach((n,i)=>r[i]^=t.reedSolomonMultiply(n,e))}return r}static reedSolomonMultiply(e,t){if(e>>>8||t>>>8)throw RangeError(`Byte out of range`);let n=0;for(let r=7;r>=0;r--)n=n<<1^(n>>>7)*285,n^=(t>>>r&1)*e;return i(!(n>>>8)),n}finderPenaltyCountPatterns(e){let t=e[1];i(t<=this.size*3);let n=t>0&&e[2]==t&&e[3]==t*3&&e[4]==t&&e[5]==t;return(n&&e[0]>=t*4&&e[6]>=t?1:0)+(n&&e[6]>=t*4&&e[0]>=t?1:0)}finderPenaltyTerminateAndCount(e,t,n){return e&&(this.finderPenaltyAddHistory(t,n),t=0),t+=this.size,this.finderPenaltyAddHistory(t,n),this.finderPenaltyCountPatterns(n)}finderPenaltyAddHistory(e,t){t[0]==0&&(e+=this.size),t.pop(),t.unshift(e)}};t.MIN_VERSION=1,t.MAX_VERSION=40,t.PENALTY_N1=3,t.PENALTY_N2=3,t.PENALTY_N3=40,t.PENALTY_N4=10,t.ECC_CODEWORDS_PER_BLOCK=[[-1,7,10,15,20,26,18,20,24,30,18,20,24,26,30,22,24,28,30,28,28,28,28,30,30,26,28,30,30,30,30,30,30,30,30,30,30,30,30,30,30],[-1,10,16,26,18,24,16,18,22,22,26,30,22,22,24,24,28,28,26,26,26,26,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28],[-1,13,22,18,26,18,24,18,22,20,24,28,26,24,20,30,24,28,28,26,30,28,30,30,30,30,28,30,30,30,30,30,30,30,30,30,30,30,30,30,30],[-1,17,28,22,16,22,28,26,26,24,28,24,28,22,24,24,30,28,28,26,28,30,24,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30]],t.NUM_ERROR_CORRECTION_BLOCKS=[[-1,1,1,1,1,1,2,2,2,2,4,4,4,4,4,6,6,6,6,7,8,8,9,9,10,12,12,12,13,14,15,16,17,18,19,19,20,21,22,24,25],[-1,1,1,1,2,2,4,4,4,5,5,5,8,9,9,10,10,11,13,14,16,17,17,18,20,21,23,25,26,28,29,31,33,35,37,38,40,43,45,47,49],[-1,1,1,2,2,4,4,6,6,8,8,8,10,12,16,12,17,16,18,21,20,23,23,25,27,29,34,34,35,38,40,43,45,48,51,53,56,59,62,65,68],[-1,1,1,2,4,4,4,5,6,8,8,11,11,16,16,18,16,19,21,25,25,25,34,30,32,35,37,40,42,45,48,51,54,57,60,63,66,70,74,77,81]],e.QrCode=t;function n(e,t,n){if(t<0||t>31||e>>>t)throw RangeError(`Value out of range`);for(let r=t-1;r>=0;r--)n.push(e>>>r&1)}function r(e,t){return!!(e>>>t&1)}function i(e){if(!e)throw Error(`Assertion error`)}let a=class e{constructor(e,t,n){if(this.mode=e,this.numChars=t,this.bitData=n,t<0)throw RangeError(`Invalid argument`);this.bitData=n.slice()}static makeBytes(t){let r=[];for(let e of t)n(e,8,r);return new e(e.Mode.BYTE,t.length,r)}static makeNumeric(t){if(!e.isNumeric(t))throw RangeError(`String contains non-numeric characters`);let r=[];for(let e=0;e<t.length;){let i=Math.min(t.length-e,3);n(parseInt(t.substring(e,e+i),10),i*3+1,r),e+=i}return new e(e.Mode.NUMERIC,t.length,r)}static makeAlphanumeric(t){if(!e.isAlphanumeric(t))throw RangeError(`String contains unencodable characters in alphanumeric mode`);let r=[],i;for(i=0;i+2<=t.length;i+=2){let a=e.ALPHANUMERIC_CHARSET.indexOf(t.charAt(i))*45;a+=e.ALPHANUMERIC_CHARSET.indexOf(t.charAt(i+1)),n(a,11,r)}return i<t.length&&n(e.ALPHANUMERIC_CHARSET.indexOf(t.charAt(i)),6,r),new e(e.Mode.ALPHANUMERIC,t.length,r)}static makeSegments(t){return t==``?[]:e.isNumeric(t)?[e.makeNumeric(t)]:e.isAlphanumeric(t)?[e.makeAlphanumeric(t)]:[e.makeBytes(e.toUtf8ByteArray(t))]}static makeEci(t){let r=[];if(t<0)throw RangeError(`ECI assignment value out of range`);if(t<128)n(t,8,r);else if(t<16384)n(2,2,r),n(t,14,r);else if(t<1e6)n(6,3,r),n(t,21,r);else throw RangeError(`ECI assignment value out of range`);return new e(e.Mode.ECI,0,r)}static isNumeric(t){return e.NUMERIC_REGEX.test(t)}static isAlphanumeric(t){return e.ALPHANUMERIC_REGEX.test(t)}getData(){return this.bitData.slice()}static getTotalBits(e,t){let n=0;for(let r of e){let e=r.mode.numCharCountBits(t);if(r.numChars>=1<<e)return 1/0;n+=4+e+r.bitData.length}return n}static toUtf8ByteArray(e){e=encodeURI(e);let t=[];for(let n=0;n<e.length;n++)e.charAt(n)==`%`?(t.push(parseInt(e.substring(n+1,n+3),16)),n+=2):t.push(e.charCodeAt(n));return t}};a.NUMERIC_REGEX=/^[0-9]*$/,a.ALPHANUMERIC_REGEX=/^[A-Z0-9 $%*+.\/:-]*$/,a.ALPHANUMERIC_CHARSET=`0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:`;let o=a;e.QrSegment=a})(ze||={}),(e=>{(e=>{let t=class{constructor(e,t){this.ordinal=e,this.formatBits=t}};t.LOW=new t(0,1),t.MEDIUM=new t(1,0),t.QUARTILE=new t(2,3),t.HIGH=new t(3,2),e.Ecc=t})(e.QrCode||={})})(ze||={}),(e=>{(e=>{let t=class{constructor(e,t){this.modeBits=e,this.numBitsCharCount=t}numCharCountBits(e){return this.numBitsCharCount[Math.floor((e+7)/17)]}};t.NUMERIC=new t(1,[10,12,14]),t.ALPHANUMERIC=new t(2,[9,11,13]),t.BYTE=new t(4,[8,16,16]),t.KANJI=new t(8,[8,10,12]),t.ECI=new t(7,[0,0,0]),e.Mode=t})(e.QrSegment||={})})(ze||={});var Be=ze,Ve={L:Be.QrCode.Ecc.LOW,M:Be.QrCode.Ecc.MEDIUM,Q:Be.QrCode.Ecc.QUARTILE,H:Be.QrCode.Ecc.HIGH},He=128,Ue=`L`,We=`#FFFFFF`,Ge=`#000000`,Ke=!1,qe=1,Je=4,Ye=0,Xe=.1;function Ze(e,t=0){let n=[];return e.forEach(function(e,r){let i=null;e.forEach(function(a,o){if(!a&&i!==null){n.push(`M${i+t} ${r+t}h${o-i}v1H${i+t}z`),i=null;return}if(o===e.length-1){if(!a)return;i===null?n.push(`M${o+t},${r+t} h1v1H${o+t}z`):n.push(`M${i+t},${r+t} h${o+1-i}v1H${i+t}z`);return}a&&i===null&&(i=o)})}),n.join(``)}function Qe(e,t){return e.slice().map((e,n)=>n<t.y||n>=t.y+t.h?e:e.map((e,n)=>n<t.x||n>=t.x+t.w?e:!1))}function $e(e,t,n,r){if(r==null)return null;let i=e.length+n*2,a=Math.floor(t*Xe),o=i/t,s=(r.width||a)*o,c=(r.height||a)*o,l=r.x==null?e.length/2-s/2:r.x*o,u=r.y==null?e.length/2-c/2:r.y*o,d=r.opacity==null?1:r.opacity,f=null;if(r.excavate){let e=Math.floor(l),t=Math.floor(u);f={x:e,y:t,w:Math.ceil(s+l-e),h:Math.ceil(c+u-t)}}let p=r.crossOrigin;return{x:l,y:u,h:c,w:s,excavation:f,opacity:d,crossOrigin:p}}function et(e,t){return t==null?e?Je:Ye:Math.max(Math.floor(t),0)}function tt({value:e,level:t,minVersion:n,includeMargin:r,marginSize:i,imageSettings:a,size:o,boostLevel:s}){let c=_.useMemo(()=>{let r=(Array.isArray(e)?e:[e]).reduce((e,t)=>(e.push(...Be.QrSegment.makeSegments(t)),e),[]);return Be.QrCode.encodeSegments(r,Ve[t],n,void 0,void 0,s)},[e,t,n,s]),{cells:l,margin:u,numCells:d,calculatedImageSettings:f}=_.useMemo(()=>{let e=c.getModules(),t=et(r,i);return{cells:e,margin:t,numCells:e.length+t*2,calculatedImageSettings:$e(e,o,t,a)}},[c,o,a,r,i]);return{qrcode:c,margin:u,cells:l,numCells:d,calculatedImageSettings:f}}var nt=function(){try{new Path2D().addPath(new Path2D)}catch{return!1}return!0}(),rt=_.forwardRef(function(e,t){let n=e,{value:r,size:i=He,level:a=Ue,bgColor:o=We,fgColor:s=Ge,includeMargin:c=Ke,minVersion:l=qe,boostLevel:u,marginSize:d,imageSettings:f}=n,p=Re(n,[`value`,`size`,`level`,`bgColor`,`fgColor`,`includeMargin`,`minVersion`,`boostLevel`,`marginSize`,`imageSettings`]),{style:m}=p,h=Re(p,[`style`]),g=f?.src,v=_.useRef(null),y=_.useRef(null),b=_.useCallback(e=>{v.current=e,typeof t==`function`?t(e):t&&(t.current=e)},[t]),[x,ee]=_.useState(!1),{margin:S,cells:C,numCells:te,calculatedImageSettings:w}=tt({value:r,level:a,minVersion:l,boostLevel:u,includeMargin:c,marginSize:d,imageSettings:f,size:i});_.useEffect(()=>{if(v.current!=null){let e=v.current,t=e.getContext(`2d`);if(!t)return;let n=C,r=y.current,a=w!=null&&r!==null&&r.complete&&r.naturalHeight!==0&&r.naturalWidth!==0;a&&w.excavation!=null&&(n=Qe(C,w.excavation));let c=window.devicePixelRatio||1;e.height=e.width=i*c;let l=i/te*c;t.scale(l,l),t.fillStyle=o,t.fillRect(0,0,te,te),t.fillStyle=s,nt?t.fill(new Path2D(Ze(n,S))):C.forEach(function(e,n){e.forEach(function(e,r){e&&t.fillRect(r+S,n+S,1,1)})}),w&&(t.globalAlpha=w.opacity),a&&t.drawImage(r,w.x+S,w.y+S,w.w,w.h)}}),_.useEffect(()=>{ee(!1)},[g]);let ne=Le({height:i,width:i},m),T=null;return g!=null&&(T=_.createElement(`img`,{src:g,key:g,style:{display:`none`},onLoad:()=>{ee(!0)},ref:y,crossOrigin:w?.crossOrigin})),_.createElement(_.Fragment,null,_.createElement(`canvas`,Le({style:ne,height:i,width:i,ref:b,role:`img`},h)),T)});rt.displayName=`QRCodeCanvas`;var it=_.forwardRef(function(e,t){let n=e,{value:r,size:i=He,level:a=Ue,bgColor:o=We,fgColor:s=Ge,includeMargin:c=Ke,minVersion:l=qe,boostLevel:u,title:d,marginSize:f,imageSettings:p}=n,m=Re(n,[`value`,`size`,`level`,`bgColor`,`fgColor`,`includeMargin`,`minVersion`,`boostLevel`,`title`,`marginSize`,`imageSettings`]),{margin:h,cells:g,numCells:v,calculatedImageSettings:y}=tt({value:r,level:a,minVersion:l,boostLevel:u,includeMargin:c,marginSize:f,imageSettings:p,size:i}),b=g,x=null;p!=null&&y!=null&&(y.excavation!=null&&(b=Qe(g,y.excavation)),x=_.createElement(`image`,{href:p.src,height:y.h,width:y.w,x:y.x+h,y:y.y+h,preserveAspectRatio:`none`,opacity:y.opacity,crossOrigin:y.crossOrigin}));let ee=Ze(b,h);return _.createElement(`svg`,Le({height:i,width:i,viewBox:`0 0 ${v} ${v}`,ref:t,role:`img`},m),!!d&&_.createElement(`title`,null,d),_.createElement(`path`,{fill:o,d:`M0,0 h${v}v${v}H0z`,shapeRendering:`crispEdges`}),_.createElement(`path`,{fill:s,d:ee,shapeRendering:`crispEdges`}),x)});it.displayName=`QRCodeSVG`;function at({onOpenOrderTag:e,onOpenDoorstepWash:t}){return(0,j.jsxs)(`section`,{className:`hero-section`,children:[(0,j.jsx)(`div`,{className:`hero-bg-image`}),(0,j.jsx)(`div`,{className:`hero-bg-overlay`}),(0,j.jsx)(`div`,{className:`hero-bg-glow`}),(0,j.jsxs)(`div`,{className:`container hero-container`,children:[(0,j.jsxs)(`div`,{className:`hero-content`,children:[(0,j.jsxs)(`div`,{className:`glass-pill hero-badge animate-float`,children:[(0,j.jsx)(`span`,{className:`badge-dot`}),(0,j.jsx)(we,{size:13}),(0,j.jsx)(`span`,{children:`CARFRND TAG IS NOW LIVE`})]}),(0,j.jsxs)(`h1`,{className:`hero-title`,children:[`Your Car's Smart `,(0,j.jsx)(`br`,{}),(0,j.jsx)(`span`,{className:`magenta-gradient-text`,children:`Privacy Guard`}),` & `,(0,j.jsx)(`br`,{}),`Total Auto Care`]}),(0,j.jsxs)(`p`,{className:`hero-description`,children:[(0,j.jsx)(`strong`,{children:`CarFrnd Tag`}),` — your car's smart contact tag. Stay connected about your car without sharing your personal phone number. Anyone can notify you of blocking, lights left on, or towing alerts through secure masked communication.`]}),(0,j.jsxs)(`div`,{className:`hero-bullets`,children:[(0,j.jsxs)(`div`,{className:`bullet-item`,children:[(0,j.jsx)(E,{size:16,className:`bullet-icon`}),(0,j.jsx)(`span`,{children:`Your Phone Number Stays Private`})]}),(0,j.jsxs)(`div`,{className:`bullet-item`,children:[(0,j.jsx)(E,{size:16,className:`bullet-icon`}),(0,j.jsx)(`span`,{children:`No App Required to Scan`})]}),(0,j.jsxs)(`button`,{type:`button`,className:`bullet-item bullet-clickable`,onClick:t,title:`Click to view Doorstep Car Wash`,children:[(0,j.jsx)(E,{size:16,className:`bullet-icon`}),(0,j.jsx)(`span`,{children:`Doorstep Car Wash`})]})]}),(0,j.jsxs)(`div`,{className:`hero-ctas`,children:[(0,j.jsxs)(`button`,{className:`btn-primary hero-btn-main`,onClick:e,children:[(0,j.jsx)(we,{size:16}),`Get Your CarFrnd Tag — ₹450`]}),(0,j.jsx)(`a`,{href:`#app-showcase`,className:`btn-secondary hero-btn-sec`,children:`How It Works`})]})]}),(0,j.jsx)(`div`,{className:`hero-visual`,children:(0,j.jsxs)(`div`,{className:`qr-card-mockup glass-card`,children:[(0,j.jsx)(`div`,{className:`card-top-bar`,children:(0,j.jsxs)(`div`,{className:`brand-pill`,children:[(0,j.jsx)(be,{size:15,color:`#FF2B85`}),(0,j.jsx)(`span`,{children:`CarFrnd Tag`})]})}),(0,j.jsxs)(`div`,{className:`decal-surface`,children:[(0,j.jsx)(`div`,{className:`radar-line`}),(0,j.jsxs)(`div`,{className:`decal-inner`,children:[(0,j.jsxs)(`div`,{className:`qr-wrapper`,children:[(0,j.jsx)(it,{value:`https://carfrnd.com/scan?tag=KA560100MM1234&v=MH01AB1234`,size:96,level:`H`,fgColor:`#0F172A`,bgColor:`#FFFFFF`}),(0,j.jsx)(`div`,{className:`qr-logo-center`,children:(0,j.jsx)(oe,{size:14,color:`#FF2B85`})})]}),(0,j.jsxs)(`div`,{className:`decal-info`,children:[(0,j.jsx)(`span`,{className:`vehicle-num`,children:`MH 01 AB 1234`}),(0,j.jsx)(`span`,{className:`tag-id-code`,children:`Tag ID: KA560100MM1234`}),(0,j.jsxs)(`div`,{className:`privacy-badge`,children:[(0,j.jsx)(he,{size:12}),(0,j.jsx)(`span`,{children:`Masked Communication Protected`})]})]})]})]}),(0,j.jsx)(`div`,{className:`quick-scan-prompt`,style:{cursor:`default`},children:(0,j.jsxs)(`div`,{className:`scan-prompt-text`,children:[(0,j.jsx)(`span`,{className:`prompt-title`,children:`Scan this CarFrnd Tag with your Camera`}),(0,j.jsx)(`span`,{className:`prompt-sub`,children:`Scan to contact the car owner privately`})]})})]})})]}),(0,j.jsx)(`style`,{children:`
        .hero-section {
          position: relative;
          padding-top: 105px;
          padding-bottom: 36px;
          overflow: hidden;
          background: #FFFFFF;
        }

        .hero-bg-image {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background-image: url('https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1920&q=80');
          background-size: cover;
          background-position: center right;
          opacity: 0.95;
          pointer-events: none;
          z-index: 0;
          filter: contrast(1.1) saturate(1.2);
        }

        .hero-bg-overlay {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(90deg, #FFFFFF 24%, rgba(255, 255, 255, 0.65) 50%, rgba(255, 255, 255, 0) 100%),
                      linear-gradient(180deg, rgba(255, 255, 255, 0) 0%, rgba(248, 250, 252, 0.75) 100%);
          pointer-events: none;
          z-index: 0;
        }

        .hero-bg-glow {
          position: absolute;
          top: -120px;
          right: -80px;
          width: 500px;
          height: 500px;
          background: radial-gradient(circle, rgba(255, 43, 133, 0.16) 0%, rgba(255, 255, 255, 0) 70%);
          pointer-events: none;
          z-index: 0;
        }

        .hero-container {
          position: relative;
          z-index: 1;
          display: grid;
          grid-template-columns: 1.2fr 0.8fr;
          gap: 40px;
          align-items: center;
        }

        .hero-badge {
          margin-bottom: 16px;
        }

        .badge-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: var(--magenta);
        }

        .hero-title {
          font-size: 3.2rem;
          font-weight: 900;
          line-height: 1.12;
          margin-bottom: 18px;
          color: #0F172A;
        }

        .hero-description {
          font-size: 1.05rem;
          color: #475569;
          margin-bottom: 22px;
          line-height: 1.6;
          max-width: 560px;
        }

        .hero-bullets {
          display: flex;
          flex-wrap: wrap;
          gap: 10px 20px;
          margin-bottom: 28px;
        }

        .bullet-item {
          display: flex;
          align-items: center;
          gap: 7px;
          font-size: 0.9rem;
          font-weight: 700;
          color: #1E293B;
        }

        .bullet-icon {
          color: var(--magenta);
          flex-shrink: 0;
        }

        .bullet-clickable {
          background: none;
          border: none;
          cursor: pointer;
          padding: 0;
          font-family: inherit;
          transition: all 0.2s ease;
        }

        .bullet-clickable:hover span {
          color: var(--magenta);
          text-decoration: underline;
        }

        .hero-ctas {
          display: flex;
          align-items: center;
          gap: 14px;
          margin-bottom: 32px;
        }

        /* Right Visual QR Card Mockup */
        .hero-visual {
          display: flex;
          justify-content: center;
          width: 100%;
        }

        .qr-card-mockup {
          width: 100%;
          max-width: 390px;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: var(--radius-xl);
          padding: 22px;
          position: relative;
          box-shadow: 0 15px 35px rgba(15, 23, 42, 0.06);
        }

        .card-top-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 16px;
        }

        .brand-pill {
          display: flex;
          align-items: center;
          gap: 6px;
          background: var(--magenta-light);
          border: 1px solid var(--magenta-border);
          padding: 3px 10px;
          border-radius: 20px;
          font-size: 0.75rem;
          font-weight: 800;
          color: var(--magenta);
        }

        .status-indicator {
          font-size: 0.72rem;
          font-weight: 800;
          color: #059669;
          display: flex;
          align-items: center;
          gap: 5px;
        }

        .dot-green {
          width: 7px;
          height: 7px;
          background: #10B981;
          border-radius: 50%;
        }

        .decal-surface {
          background: linear-gradient(145deg, #1E293B 0%, #0F172A 100%);
          border-radius: 16px;
          padding: 20px;
          position: relative;
          overflow: hidden;
          margin-bottom: 16px;
          box-shadow: 0 8px 20px rgba(15, 23, 42, 0.12);
        }

        .radar-line {
          position: absolute;
          left: 0;
          right: 0;
          height: 2px;
          background: linear-gradient(90deg, transparent, #FF2B85, transparent);
          box-shadow: 0 0 12px #FF2B85;
          animation: radarScan 3s ease-in-out infinite;
          z-index: 5;
        }

        .decal-inner {
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          gap: 14px;
        }

        .qr-wrapper {
          position: relative;
          background: #FFFFFF;
          padding: 12px;
          border-radius: 14px;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 6px 16px rgba(0,0,0,0.2);
        }

        .qr-svg-graphic {
          color: #000000;
        }

        .qr-logo-center {
          position: absolute;
          width: 28px;
          height: 28px;
          background: #FFFFFF;
          border-radius: 50%;
          border: 2px solid #FF2B85;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .decal-info {
          display: flex;
          flex-direction: column;
          gap: 3px;
        }

        .vehicle-num {
          font-family: var(--font-heading);
          font-size: 1.25rem;
          font-weight: 900;
          letter-spacing: 0.05em;
          color: #FFFFFF;
        }

        .tag-id-code {
          font-family: monospace;
          font-size: 0.78rem;
          color: #FF73B3;
          font-weight: 700;
        }

        .privacy-badge {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 5px;
          background: rgba(16, 185, 129, 0.2);
          color: #34D399;
          border: 1px solid rgba(16, 185, 129, 0.4);
          padding: 3px 10px;
          border-radius: 12px;
          font-size: 0.72rem;
          font-weight: 700;
          margin-top: 3px;
        }

        .quick-scan-prompt {
          background: #FFF0F6;
          border: 1.5px dashed var(--magenta-border);
          border-radius: 12px;
          padding: 12px 14px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          cursor: pointer;
          transition: all 0.25s ease;
        }

        .quick-scan-prompt:hover {
          background: #FFE4F0;
          border-color: var(--magenta);
        }

        .scan-prompt-text {
          display: flex;
          flex-direction: column;
        }

        .prompt-title {
          font-size: 0.84rem;
          font-weight: 800;
          color: #0F172A;
        }

        .prompt-sub {
          font-size: 0.72rem;
          color: var(--magenta);
          font-weight: 600;
        }

        .prompt-arrow {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: var(--magenta);
          color: #FFFFFF;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        @media (max-width: 900px) {
          .hero-section {
            padding-top: 86px;
            padding-bottom: 40px;
          }
          .hero-container {
            grid-template-columns: 1fr;
            gap: 28px;
            text-align: center;
          }
          .hero-title {
            font-size: 2.3rem;
          }
          .hero-description {
            margin-left: auto;
            margin-right: auto;
            font-size: 0.96rem;
          }
          .hero-bullets {
            justify-content: center;
            gap: 8px 14px;
          }
          .bullet-item {
            font-size: 0.85rem;
          }
          .hero-ctas {
            justify-content: center;
            gap: 10px;
          }
        }

        @media (max-width: 480px) {
          .hero-title {
            font-size: 1.95rem;
          }
          .hero-ctas {
            flex-direction: column;
            width: 100%;
          }
          .hero-ctas button {
            width: 100%;
          }
        }
      `})]})}function ot({onOpenOrderTag:e}){let[t,n]=(0,_.useState)(1);return(0,_.useEffect)(()=>{let e=setInterval(()=>{n(e=>e>=3?1:e+1)},2800);return()=>clearInterval(e)},[]),(0,j.jsxs)(`section`,{id:`app-showcase`,className:`section-padding app-showcase-section`,children:[(0,j.jsxs)(`div`,{className:`container`,children:[(0,j.jsxs)(`div`,{className:`section-header text-center`,children:[(0,j.jsxs)(`div`,{className:`showcase-header-badges`,children:[(0,j.jsxs)(`div`,{className:`eco-pill-header`,children:[(0,j.jsx)(E,{size:13,color:`#059669`}),(0,j.jsx)(`span`,{children:`NO APP REQUIRED TO SCAN`})]}),(0,j.jsxs)(`div`,{className:`showcase-pill`,children:[(0,j.jsx)(`span`,{className:`pill-dot`}),(0,j.jsx)(`span`,{children:`CARFRND TAG`})]})]}),(0,j.jsx)(`h2`,{className:`showcase-title`,children:`See CarFrnd Tag in Action`}),(0,j.jsx)(`p`,{className:`showcase-subtitle`,children:`Your car's smart contact tag. See how CarFrnd Tag keeps you connected while keeping your phone number private.`})]}),(0,j.jsxs)(`div`,{className:`showcase-main-grid`,children:[(0,j.jsxs)(`div`,{className:`showcase-controls-col`,children:[(0,j.jsx)(`div`,{className:`screen-tabs-bar`,children:(0,j.jsxs)(`button`,{className:`screen-tab-btn active`,type:`button`,children:[(0,j.jsx)(xe,{size:16}),(0,j.jsx)(`span`,{children:`CarFrnd Tag`})]})}),(0,j.jsxs)(`div`,{className:`active-screen-info`,children:[(0,j.jsx)(`h3`,{className:`info-title`,children:`Your Car's Smart Contact Tag`}),(0,j.jsx)(`p`,{className:`info-desc`,children:`Stay connected about your car without sharing your personal phone number. Anyone can scan your CarFrnd Tag with their phone camera to notify you about your car without seeing your personal phone number.`})]}),(0,j.jsxs)(`div`,{className:`carfrnd-tag-perks-list`,children:[(0,j.jsxs)(`div`,{className:`perk-row`,children:[(0,j.jsx)(E,{size:16,color:`#059669`,className:`perk-icon`}),(0,j.jsx)(`span`,{children:`No app download required for the person scanning`})]}),(0,j.jsxs)(`div`,{className:`perk-row`,children:[(0,j.jsx)(E,{size:16,color:`#059669`,className:`perk-icon`}),(0,j.jsx)(`span`,{children:`Secure masked voice communication`})]}),(0,j.jsxs)(`div`,{className:`perk-row`,children:[(0,j.jsx)(E,{size:16,color:`#059669`,className:`perk-icon`}),(0,j.jsx)(`span`,{children:`Instant alerts for blocking, window open, or towing`})]})]}),(0,j.jsx)(`div`,{className:`showcase-actions-row`,children:(0,j.jsxs)(`button`,{className:`btn-primary showcase-cta-main`,onClick:e,children:[(0,j.jsx)(we,{size:16}),(0,j.jsx)(`span`,{children:`Get Your CarFrnd Tag — ₹450`})]})})]}),(0,j.jsx)(`div`,{className:`showcase-phone-col`,children:(0,j.jsxs)(`div`,{className:`phone-device-container`,children:[(0,j.jsx)(`div`,{className:`floating-bubble-top animate-float`,children:t===1?(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`span`,{className:`bubble-bold`,children:`CarFrnd Tag Scanned`}),(0,j.jsx)(`span`,{className:`bubble-sub`,children:`Camera Live • Tag Verified`})]}):t===2?(0,j.jsx)(j.Fragment,{children:(0,j.jsx)(`span`,{className:`bubble-bold`,children:`CarFrnd Tag Alert Sent`})}):(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(`span`,{className:`bubble-bold`,children:`Masked Call Active`}),(0,j.jsx)(`span`,{className:`bubble-sub`,children:`Phone Number Protected`})]})}),(0,j.jsxs)(`div`,{className:`floating-bubble-bottom`,children:[(0,j.jsx)(be,{size:18,color:`#10B981`}),(0,j.jsx)(`span`,{className:`rating-lbl`,children:`No App Required to Scan`})]}),(0,j.jsx)(`div`,{className:`phone-hardware-frame`,children:(0,j.jsxs)(`div`,{className:`phone-screen-viewport`,children:[(0,j.jsxs)(`div`,{className:`phone-status-bar`,children:[(0,j.jsx)(`span`,{className:`time`,children:`9:41`}),(0,j.jsx)(`div`,{className:`dynamic-island-notch`}),(0,j.jsxs)(`div`,{className:`status-icons`,children:[(0,j.jsx)(`span`,{children:`5G`}),(0,j.jsx)(`span`,{className:`battery`,children:`100%`})]})]}),(0,j.jsxs)(`div`,{className:`phone-content-body carfrnd-tag-screen-view animate-fade-in`,children:[(0,j.jsx)(`div`,{className:`screen-top-bar`,children:(0,j.jsxs)(`div`,{className:`screen-header-badge`,style:{background:`rgba(255, 43, 133, 0.15)`,color:`#FF2B85`},children:[(0,j.jsx)(xe,{size:12,color:`#FF2B85`}),(0,j.jsx)(`span`,{children:`CARFRND TAG`})]})}),(0,j.jsx)(`h4`,{className:`screen-hero-title`,children:`QR Safety Guard`}),(0,j.jsxs)(`div`,{className:`flow-step-tracker`,children:[(0,j.jsx)(`button`,{type:`button`,className:`step-dot ${t===1?`active`:``}`,onClick:()=>n(1),children:`1. Scan`}),(0,j.jsx)(`button`,{type:`button`,className:`step-dot ${t===2?`active`:``}`,onClick:()=>n(2),children:`2. Select Reason`}),(0,j.jsx)(`button`,{type:`button`,className:`step-dot ${t===3?`active`:``}`,onClick:()=>n(3),children:`3. Masked Call`})]}),t===1&&(0,j.jsxs)(`div`,{className:`mock-scanner-viewfinder`,children:[(0,j.jsx)(`div`,{className:`laser-scanner-line`}),(0,j.jsx)(`div`,{className:`qr-box-centered`,children:(0,j.jsx)(_e,{size:56,color:`#FFFFFF`,className:`mock-qr-icon`})}),(0,j.jsx)(`span`,{className:`scan-radar-txt`,children:`Scanning CarFrnd Tag...`}),(0,j.jsx)(`span`,{className:`scan-vnum-detect`,children:`Vehicle: MH 01 AB 1234`})]}),t===2&&(0,j.jsxs)(`div`,{className:`mock-issue-detected-card`,children:[(0,j.jsxs)(`div`,{className:`mock-vtag-row`,children:[(0,j.jsx)(`span`,{className:`vplate-bold`,children:`MH 01 AB 1234`}),(0,j.jsx)(`span`,{className:`vtag-id`,children:`Tag ID: KA560100MM1234`})]}),(0,j.jsxs)(`div`,{className:`alert-select-box`,children:[(0,j.jsx)(Te,{size:14,color:`#FF2B85`}),(0,j.jsx)(`span`,{children:`Car Blocking Driveway / Gate`}),(0,j.jsx)(E,{size:13,color:`#10B981`,style:{marginLeft:`auto`}})]}),(0,j.jsx)(`div`,{className:`alert-dispatched-note`,children:(0,j.jsx)(`span`,{children:`● Secure alert routing initiated...`})}),(0,j.jsx)(`button`,{className:`phone-primary-action-btn`,style:{marginTop:`4px`},children:`Connecting Masked Call...`})]}),t===3&&(0,j.jsxs)(`div`,{className:`mock-masked-call-connected`,children:[(0,j.jsx)(`div`,{className:`call-pulse-circle`,children:(0,j.jsx)(me,{size:22,color:`#10B981`})}),(0,j.jsx)(`span`,{className:`call-connected-txt`,children:`Masked Call Connected`}),(0,j.jsx)(`span`,{className:`call-sub-txt`,children:`Your Phone Number Stays Private`}),(0,j.jsxs)(`div`,{className:`call-meta-box`,children:[(0,j.jsx)(`span`,{children:`Scanner: Hidden`}),(0,j.jsx)(`span`,{children:`Car Owner: Hidden`})]}),(0,j.jsx)(`div`,{className:`call-timer-badge`,children:(0,j.jsx)(`span`,{children:`Call Active • 00:14`})})]})]}),(0,j.jsx)(`div`,{className:`phone-bottom-nav`,children:(0,j.jsxs)(`div`,{className:`p-brand-indicator`,children:[(0,j.jsx)(be,{size:14,color:`#FF2B85`}),(0,j.jsx)(`span`,{children:`CarFrnd Tag Secure Gateway`})]})})]})})]})})]})]}),(0,j.jsx)(`style`,{children:`
        .app-showcase-section {
          background: #FFFFFF;
          color: #0F172A;
          padding: 50px 0;
          position: relative;
          overflow: hidden;
          border-top: 1px solid #E2E8F0;
          border-bottom: 1px solid #E2E8F0;
        }

        .showcase-header-badges {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          flex-wrap: wrap;
          margin-bottom: 14px;
        }

        .eco-pill-header {
          background: #F0FDF4;
          border: 1px solid #BBF7D0;
          border-radius: 20px;
          padding: 4px 14px;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 0.72rem;
          font-weight: 800;
          color: #15803D;
          letter-spacing: 0.06em;
        }

        .showcase-pill {
          background: #ECFDF5;
          border: 1px solid #A7F3D0;
          border-radius: 20px;
          padding: 4px 14px;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 0.72rem;
          font-weight: 800;
          color: #059669;
          letter-spacing: 0.08em;
        }

        .pill-dot {
          width: 6px;
          height: 6px;
          background: #10B981;
          border-radius: 50%;
          box-shadow: 0 0 6px #10B981;
        }

        .showcase-title {
          font-size: 2.8rem;
          font-weight: 900;
          color: #0F172A;
          margin-bottom: 12px;
          letter-spacing: -0.02em;
        }

        .showcase-subtitle {
          font-size: 1.05rem;
          color: #64748B;
          max-width: 600px;
          margin: 0 auto 28px auto;
          line-height: 1.6;
        }

        .showcase-main-grid {
          display: grid;
          grid-template-columns: 1.15fr 0.85fr;
          gap: 48px;
          align-items: center;
        }

        .screen-tabs-bar {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 18px;
        }

        .screen-tab-btn {
          background: var(--magenta-light);
          border: 1.5px solid var(--magenta);
          color: var(--magenta);
          padding: 8px 18px;
          border-radius: 12px;
          font-family: var(--font-heading);
          font-size: 0.9rem;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          cursor: default;
        }

        .active-screen-info {
          margin-bottom: 22px;
        }

        .info-title {
          font-size: 1.85rem;
          font-weight: 900;
          color: #0F172A;
          margin-bottom: 10px;
          letter-spacing: -0.01em;
        }

        .info-desc {
          font-size: 1rem;
          color: #475569;
          line-height: 1.65;
          max-width: 540px;
        }

        .carfrnd-tag-perks-list {
          display: flex;
          flex-direction: column;
          gap: 10px;
          margin-bottom: 28px;
          padding: 16px 20px;
          background: #F8FAFC;
          border-radius: 14px;
          border: 1px solid #E2E8F0;
        }

        .perk-row {
          display: flex;
          align-items: center;
          gap: 10px;
          font-size: 0.88rem;
          font-weight: 600;
          color: #1E293B;
        }

        .perk-icon {
          flex-shrink: 0;
        }

        .showcase-actions-row {
          display: flex;
          align-items: center;
          gap: 14px;
          flex-wrap: wrap;
        }

        .showcase-cta-main,
        .showcase-cta-sec {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 12px 20px;
          font-size: 0.9rem;
        }

        /* Phone Mockup Column */
        .showcase-phone-col {
          display: flex;
          justify-content: center;
          width: 100%;
        }

        .phone-device-container {
          position: relative;
          width: 310px;
        }

        .floating-bubble-top {
          position: absolute;
          top: 30px;
          right: -25px;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          padding: 10px 14px;
          border-radius: 14px;
          display: flex;
          flex-direction: column;
          box-shadow: 0 12px 30px rgba(15, 23, 42, 0.14);
          z-index: 20;
          pointer-events: none;
          max-width: 210px;
        }

        .bubble-bold {
          font-size: 0.74rem;
          font-weight: 800;
          color: #0F172A;
        }

        .bubble-sub {
          font-size: 0.64rem;
          color: #64748B;
        }

        .floating-bubble-bottom {
          position: absolute;
          bottom: 40px;
          left: -20px;
          background: #0F172A;
          color: #FFFFFF;
          padding: 8px 14px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          gap: 8px;
          box-shadow: 0 10px 25px rgba(15, 23, 42, 0.2);
          z-index: 20;
          pointer-events: none;
        }

        .rating-lbl {
          font-size: 0.75rem;
          font-weight: 700;
          color: #FFFFFF;
        }

        /* Phone Frame */
        .phone-hardware-frame {
          background: #0F172A;
          border-radius: 36px;
          padding: 10px;
          border: 3px solid #E2E8F0;
          box-shadow: 0 20px 50px rgba(15, 23, 42, 0.12);
        }

        .phone-screen-viewport {
          background: #0F172A;
          border-radius: 26px;
          height: 480px;
          overflow: hidden;
          position: relative;
          display: flex;
          flex-direction: column;
        }

        .phone-status-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 8px 16px 4px 16px;
          font-size: 0.7rem;
          font-weight: 700;
          color: #E2E8F0;
        }

        .dynamic-island-notch {
          width: 64px;
          height: 12px;
          background: #000000;
          border-radius: 8px;
        }

        .status-icons {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 0.62rem;
        }

        .phone-content-body {
          padding: 12px 14px;
          flex: 1;
          display: flex;
          flex-direction: column;
        }

        .screen-top-bar {
          display: flex;
          margin-bottom: 6px;
        }

        .screen-header-badge {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          font-size: 0.65rem;
          font-weight: 800;
          padding: 2px 8px;
          border-radius: 12px;
        }

        .screen-hero-title {
          font-size: 1.15rem;
          font-weight: 900;
          color: #FFFFFF;
          margin-bottom: 10px;
        }

        .flow-step-tracker {
          display: flex;
          align-items: center;
          gap: 4px;
          background: rgba(255, 255, 255, 0.06);
          padding: 4px;
          border-radius: 8px;
          margin-bottom: 12px;
        }

        .step-dot {
          flex: 1;
          font-size: 0.62rem;
          font-weight: 700;
          color: #94A3B8;
          text-align: center;
          padding: 3px 0;
          border-radius: 6px;
          background: none;
          border: none;
          cursor: pointer;
          transition: all 0.2s;
        }

        .step-dot.active {
          background: var(--magenta);
          color: #FFFFFF;
        }

        .mock-scanner-viewfinder {
          background: #020617;
          border: 1.5px dashed rgba(255, 43, 133, 0.4);
          border-radius: 14px;
          height: 220px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          position: relative;
          overflow: hidden;
        }

        .laser-scanner-line {
          position: absolute;
          left: 0;
          right: 0;
          height: 2px;
          background: linear-gradient(90deg, transparent, #FF2B85, transparent);
          box-shadow: 0 0 10px #FF2B85;
          animation: radarScan 2s infinite ease-in-out;
        }

        .qr-box-centered {
          background: rgba(255, 255, 255, 0.1);
          padding: 10px;
          border-radius: 10px;
          margin-bottom: 8px;
        }

        .scan-radar-txt {
          font-size: 0.68rem;
          color: #E2E8F0;
          font-weight: 700;
        }

        .scan-vnum-detect {
          font-size: 0.62rem;
          color: var(--magenta);
          font-weight: 800;
          font-family: monospace;
          margin-top: 2px;
        }

        .mock-issue-detected-card {
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 12px;
          padding: 14px;
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .mock-vtag-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-bottom: 6px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .vplate-bold {
          font-size: 0.88rem;
          font-weight: 900;
          color: #FFFFFF;
          font-family: var(--font-heading);
        }

        .vtag-id {
          font-size: 0.65rem;
          color: var(--magenta);
          font-family: monospace;
          font-weight: 700;
        }

        .alert-select-box {
          background: rgba(255, 43, 133, 0.15);
          border: 1px solid var(--magenta-border);
          border-radius: 8px;
          padding: 8px 10px;
          display: flex;
          align-items: center;
          gap: 8px;
          color: #FFFFFF;
          font-size: 0.74rem;
          font-weight: 700;
        }

        .alert-dispatched-note {
          font-size: 0.65rem;
          color: #10B981;
          font-weight: 600;
        }

        .phone-primary-action-btn {
          width: 100%;
          background: var(--magenta);
          border: none;
          color: #FFFFFF;
          padding: 8px;
          border-radius: 8px;
          font-size: 0.72rem;
          font-weight: 800;
          cursor: pointer;
        }

        .mock-masked-call-connected {
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          padding: 18px 0;
          gap: 8px;
        }

        .call-pulse-circle {
          width: 52px;
          height: 52px;
          border-radius: 50%;
          background: rgba(16, 185, 129, 0.2);
          border: 2px solid #10B981;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 4px;
        }

        .call-connected-txt {
          font-size: 0.88rem;
          font-weight: 900;
          color: #FFFFFF;
        }

        .call-sub-txt {
          font-size: 0.68rem;
          color: #10B981;
          font-weight: 700;
        }

        .call-meta-box {
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 8px;
          padding: 8px 12px;
          display: flex;
          flex-direction: column;
          gap: 3px;
          font-size: 0.68rem;
          color: #E2E8F0;
          margin-top: 4px;
        }

        .call-timer-badge {
          background: rgba(16, 185, 129, 0.15);
          color: #34D399;
          font-size: 0.65rem;
          font-weight: 800;
          padding: 3px 8px;
          border-radius: 12px;
          margin-top: 4px;
        }

        .phone-bottom-nav {
          height: 38px;
          background: #020617;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
          display: flex;
          align-items: center;
          justify-content: center;
          margin-top: auto;
        }

        .p-brand-indicator {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 0.65rem;
          font-weight: 800;
          color: #94A3B8;
        }

        @media (max-width: 900px) {
          .app-showcase-section {
            padding: 36px 0;
          }
          .showcase-title {
            font-size: 2.1rem;
          }
          .showcase-subtitle {
            font-size: 0.95rem;
            margin-bottom: 24px;
          }
          .showcase-main-grid {
            grid-template-columns: 1fr;
            gap: 32px;
          }
          .showcase-controls-col {
            text-align: center;
          }
          .screen-tabs-bar {
            justify-content: center;
          }
          .info-title {
            font-size: 1.5rem;
          }
          .info-desc {
            margin: 0 auto;
          }
          .carfrnd-tag-perks-list {
            text-align: left;
          }
          .showcase-actions-row {
            justify-content: center;
          }
          .floating-bubble-top {
            right: -5px;
            top: 20px;
          }
          .floating-bubble-bottom {
            left: -5px;
            bottom: 20px;
          }
        }
      `})]})}var st={};(function e(t,n,r,i){var a=!!(t.Worker&&t.Blob&&t.Promise&&t.OffscreenCanvas&&t.OffscreenCanvasRenderingContext2D&&t.HTMLCanvasElement&&t.HTMLCanvasElement.prototype.transferControlToOffscreen&&t.URL&&t.URL.createObjectURL),o=typeof Path2D==`function`&&typeof DOMMatrix==`function`,s=(function(){if(!t.OffscreenCanvas)return!1;try{var e=new OffscreenCanvas(1,1),n=e.getContext(`2d`);n.fillRect(0,0,1,1);var r=e.transferToImageBitmap();n.createPattern(r,`no-repeat`)}catch{return!1}return!0})();function c(){}function l(e){var r=n.exports.Promise,i=r===void 0?t.Promise:r;return typeof i==`function`?new i(e):(e(c,c),null)}var u=(function(e,t){return{transform:function(n){if(e)return n;if(t.has(n))return t.get(n);var r=new OffscreenCanvas(n.width,n.height);return r.getContext(`2d`).drawImage(n,0,0),t.set(n,r),r},clear:function(){t.clear()}}})(s,new Map),d=function(){var e,t,n={},r=0;return typeof requestAnimationFrame==`function`&&typeof cancelAnimationFrame==`function`?(e=function(e){var t=Math.random();return n[t]=requestAnimationFrame(function i(a){r===a||r+16-1<a?(r=a,delete n[t],e()):n[t]=requestAnimationFrame(i)}),t},t=function(e){n[e]&&cancelAnimationFrame(n[e])}):(e=function(e){return setTimeout(e,16)},t=function(e){return clearTimeout(e)}),{frame:e,cancel:t}}(),f=(function(){var t,n,i={};function o(e){function t(t,n){e.postMessage({options:t||{},callback:n})}e.init=function(t){var n=t.transferControlToOffscreen();e.postMessage({canvas:n},[n])},e.fire=function(r,a,o){if(n)return t(r,null),n;var s=Math.random().toString(36).slice(2);return n=l(function(a){function c(t){t.data.callback===s&&(delete i[s],e.removeEventListener(`message`,c),n=null,u.clear(),o(),a())}e.addEventListener(`message`,c),t(r,s),i[s]=c.bind(null,{data:{callback:s}})}),n},e.reset=function(){for(var t in e.postMessage({reset:!0}),i)i[t](),delete i[t]}}return function(){if(t)return t;if(!r&&a){var n=[`var CONFETTI, SIZE = {}, module = {};`,`(`+e.toString()+`)(this, module, true, SIZE);`,`onmessage = function(msg) {`,`  if (msg.data.options) {`,`    CONFETTI(msg.data.options).then(function () {`,`      if (msg.data.callback) {`,`        postMessage({ callback: msg.data.callback });`,`      }`,`    });`,`  } else if (msg.data.reset) {`,`    CONFETTI && CONFETTI.reset();`,`  } else if (msg.data.resize) {`,`    SIZE.width = msg.data.resize.width;`,`    SIZE.height = msg.data.resize.height;`,`  } else if (msg.data.canvas) {`,`    SIZE.width = msg.data.canvas.width;`,`    SIZE.height = msg.data.canvas.height;`,`    CONFETTI = module.exports.create(msg.data.canvas);`,`  }`,`}`].join(`
`);try{t=new Worker(URL.createObjectURL(new Blob([n])))}catch(e){return typeof console<`u`&&typeof console.warn==`function`&&console.warn(`🎊 Could not load worker`,e),null}o(t)}return t}})(),p={particleCount:50,angle:90,spread:45,startVelocity:45,decay:.9,gravity:1,drift:0,ticks:200,x:.5,y:.5,shapes:[`square`,`circle`],zIndex:100,colors:[`#26ccff`,`#a25afd`,`#ff5e7e`,`#88ff5a`,`#fcff42`,`#ffa62d`,`#ff36ff`],disableForReducedMotion:!1,scalar:1};function m(e,t){return t?t(e):e}function h(e){return e!=null}function g(e,t,n){return m(e&&h(e[t])?e[t]:p[t],n)}function _(e){return e<0?0:Math.floor(e)}function v(e,t){return Math.floor(Math.random()*(t-e))+e}function y(e){return parseInt(e,16)}function b(e){return e.map(x)}function x(e){var t=String(e).replace(/[^0-9a-f]/gi,``);return t.length<6&&(t=t[0]+t[0]+t[1]+t[1]+t[2]+t[2]),{r:y(t.substring(0,2)),g:y(t.substring(2,4)),b:y(t.substring(4,6))}}function ee(e){var t=g(e,`origin`,Object);return t.x=g(t,`x`,Number),t.y=g(t,`y`,Number),t}function S(e){e.width=document.documentElement.clientWidth,e.height=document.documentElement.clientHeight}function C(e){var t=e.getBoundingClientRect();e.width=t.width,e.height=t.height}function te(e){var t=document.createElement(`canvas`);return t.style.position=`fixed`,t.style.top=`0px`,t.style.left=`0px`,t.style.pointerEvents=`none`,t.style.zIndex=e,t}function w(e,t,n,r,i,a,o,s,c){e.save(),e.translate(t,n),e.rotate(a),e.scale(r,i),e.arc(0,0,1,o,s,c),e.restore()}function ne(e){var t=e.angle*(Math.PI/180),n=e.spread*(Math.PI/180);return{x:e.x,y:e.y,wobble:Math.random()*10,wobbleSpeed:Math.min(.11,Math.random()*.1+.05),velocity:e.startVelocity*.5+Math.random()*e.startVelocity,angle2D:-t+(.5*n-Math.random()*n),tiltAngle:(Math.random()*.5+.25)*Math.PI,color:e.color,shape:e.shape,tick:0,totalTicks:e.ticks,decay:e.decay,drift:e.drift,random:Math.random()+2,tiltSin:0,tiltCos:0,wobbleX:0,wobbleY:0,gravity:e.gravity*3,ovalScalar:.6,scalar:e.scalar,flat:e.flat}}function T(e,t){t.x+=Math.cos(t.angle2D)*t.velocity+t.drift,t.y+=Math.sin(t.angle2D)*t.velocity+t.gravity,t.velocity*=t.decay,t.flat?(t.wobble=0,t.wobbleX=t.x+10*t.scalar,t.wobbleY=t.y+10*t.scalar,t.tiltSin=0,t.tiltCos=0,t.random=1):(t.wobble+=t.wobbleSpeed,t.wobbleX=t.x+10*t.scalar*Math.cos(t.wobble),t.wobbleY=t.y+10*t.scalar*Math.sin(t.wobble),t.tiltAngle+=.1,t.tiltSin=Math.sin(t.tiltAngle),t.tiltCos=Math.cos(t.tiltAngle),t.random=Math.random()+2);var n=t.tick++/t.totalTicks,r=t.x+t.random*t.tiltCos,i=t.y+t.random*t.tiltSin,a=t.wobbleX+t.random*t.tiltCos,s=t.wobbleY+t.random*t.tiltSin;if(e.fillStyle=`rgba(`+t.color.r+`, `+t.color.g+`, `+t.color.b+`, `+(1-n)+`)`,e.beginPath(),o&&t.shape.type===`path`&&typeof t.shape.path==`string`&&Array.isArray(t.shape.matrix))e.fill(se(t.shape.path,t.shape.matrix,t.x,t.y,Math.abs(a-r)*.1,Math.abs(s-i)*.1,Math.PI/10*t.wobble));else if(t.shape.type===`bitmap`){var c=Math.PI/10*t.wobble,l=Math.abs(a-r)*.1,d=Math.abs(s-i)*.1,f=t.shape.bitmap.width*t.scalar,p=t.shape.bitmap.height*t.scalar,m=new DOMMatrix([Math.cos(c)*l,Math.sin(c)*l,-Math.sin(c)*d,Math.cos(c)*d,t.x,t.y]);m.multiplySelf(new DOMMatrix(t.shape.matrix));var h=e.createPattern(u.transform(t.shape.bitmap),`no-repeat`);h.setTransform(m),e.globalAlpha=1-n,e.fillStyle=h,e.fillRect(t.x-f/2,t.y-p/2,f,p),e.globalAlpha=1}else if(t.shape===`circle`)e.ellipse?e.ellipse(t.x,t.y,Math.abs(a-r)*t.ovalScalar,Math.abs(s-i)*t.ovalScalar,Math.PI/10*t.wobble,0,2*Math.PI):w(e,t.x,t.y,Math.abs(a-r)*t.ovalScalar,Math.abs(s-i)*t.ovalScalar,Math.PI/10*t.wobble,0,2*Math.PI);else if(t.shape===`star`)for(var g=Math.PI/2*3,_=4*t.scalar,v=8*t.scalar,y=t.x,b=t.y,x=5,ee=Math.PI/x;x--;)y=t.x+Math.cos(g)*v,b=t.y+Math.sin(g)*v,e.lineTo(y,b),g+=ee,y=t.x+Math.cos(g)*_,b=t.y+Math.sin(g)*_,e.lineTo(y,b),g+=ee;else e.moveTo(Math.floor(t.x),Math.floor(t.y)),e.lineTo(Math.floor(t.wobbleX),Math.floor(i)),e.lineTo(Math.floor(a),Math.floor(s)),e.lineTo(Math.floor(r),Math.floor(t.wobbleY));return e.closePath(),e.fill(),t.tick<t.totalTicks}function re(e,t,n,a,o){var s=t.slice(),c=e.getContext(`2d`),f,p,m=l(function(t){function l(){f=p=null,c.clearRect(0,0,a.width,a.height),u.clear(),o(),t()}function m(){r&&(a.width!==i.width||a.height!==i.height)&&(a.width=e.width=i.width,a.height=e.height=i.height),!a.width&&!a.height&&(n(e),a.width=e.width,a.height=e.height),c.clearRect(0,0,a.width,a.height),s=s.filter(function(e){return T(c,e)}),s.length?f=d.frame(m):l()}f=d.frame(m),p=l});return{addFettis:function(e){return s=s.concat(e),m},canvas:e,promise:m,reset:function(){f&&d.cancel(f),p&&p()}}}function ie(e,n){var r=!e,i=!!g(n||{},`resize`),o=!1,s=g(n,`disableForReducedMotion`,Boolean),c=a&&g(n||{},`useWorker`)?f():null,u=r?S:C,d=e&&c?!!e.__confetti_initialized:!1,p=typeof matchMedia==`function`&&matchMedia(`(prefers-reduced-motion)`).matches,m;function h(t,n,r){for(var i=g(t,`particleCount`,_),a=g(t,`angle`,Number),o=g(t,`spread`,Number),s=g(t,`startVelocity`,Number),c=g(t,`decay`,Number),l=g(t,`gravity`,Number),d=g(t,`drift`,Number),f=g(t,`colors`,b),p=g(t,`ticks`,Number),h=g(t,`shapes`),y=g(t,`scalar`),x=!!g(t,`flat`),S=ee(t),C=i,te=[],w=e.width*S.x,T=e.height*S.y;C--;)te.push(ne({x:w,y:T,angle:a,spread:o,startVelocity:s,color:f[C%f.length],shape:h[v(0,h.length)],ticks:p,decay:c,gravity:l,drift:d,scalar:y,flat:x}));return m?m.addFettis(te):(m=re(e,te,u,n,r),m.promise)}function y(n){var a=s||g(n,`disableForReducedMotion`,Boolean),f=g(n,`zIndex`,Number);if(a&&p)return l(function(e){e()});r&&m?e=m.canvas:r&&!e&&(e=te(f),document.body.appendChild(e)),i&&!d&&u(e);var _={width:e.width,height:e.height};c&&!d&&c.init(e),d=!0,c&&(e.__confetti_initialized=!0);function v(){if(c){var t={getBoundingClientRect:function(){if(!r)return e.getBoundingClientRect()}};u(t),c.postMessage({resize:{width:t.width,height:t.height}});return}_.width=_.height=null}function y(){m=null,i&&(o=!1,t.removeEventListener(`resize`,v)),r&&e&&(document.body.contains(e)&&document.body.removeChild(e),e=null,d=!1)}return i&&!o&&(o=!0,t.addEventListener(`resize`,v,!1)),c?c.fire(n,_,y):h(n,_,y)}return y.reset=function(){c&&c.reset(),m&&m.reset()},y}var ae;function oe(){return ae||=ie(null,{useWorker:!0,resize:!0}),ae}function se(e,t,n,r,i,a,o){var s=new Path2D(e),c=new Path2D;c.addPath(s,new DOMMatrix(t));var l=new Path2D;return l.addPath(c,new DOMMatrix([Math.cos(o)*i,Math.sin(o)*i,-Math.sin(o)*a,Math.cos(o)*a,n,r])),l}function E(e){if(!o)throw Error(`path confetti are not supported in this browser`);var t,n;typeof e==`string`?t=e:(t=e.path,n=e.matrix);var r=new Path2D(t),i=document.createElement(`canvas`).getContext(`2d`);if(!n){for(var a=1e3,s=a,c=a,l=0,u=0,d,f,p=0;p<a;p+=2)for(var m=0;m<a;m+=2)i.isPointInPath(r,p,m,`nonzero`)&&(s=Math.min(s,p),c=Math.min(c,m),l=Math.max(l,p),u=Math.max(u,m));d=l-s,f=u-c;var h=10,g=Math.min(h/d,h/f);n=[g,0,0,g,-Math.round(d/2+s)*g,-Math.round(f/2+c)*g]}return{type:`path`,path:t,matrix:n}}function ce(e){var t,n=1,r=`#000000`,i=`"Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji", "EmojiOne Color", "Android Emoji", "Twemoji Mozilla", "system emoji", sans-serif`;typeof e==`string`?t=e:(t=e.text,n=`scalar`in e?e.scalar:n,i=`fontFamily`in e?e.fontFamily:i,r=`color`in e?e.color:r);var a=10*n,o=``+a+`px `+i,s=new OffscreenCanvas(a,a),c=s.getContext(`2d`);c.font=o;var l=c.measureText(t),u=Math.ceil(l.actualBoundingBoxRight+l.actualBoundingBoxLeft),d=Math.ceil(l.actualBoundingBoxAscent+l.actualBoundingBoxDescent),f=2,p=l.actualBoundingBoxLeft+f,m=l.actualBoundingBoxAscent+f;u+=f+f,d+=f+f,s=new OffscreenCanvas(u,d),c=s.getContext(`2d`),c.font=o,c.fillStyle=r,c.fillText(t,p,m);var h=1/n;return{type:`bitmap`,bitmap:s.transferToImageBitmap(),matrix:[h,0,0,h,-u*h/2,-d*h/2]}}n.exports=function(){return oe().apply(this,arguments)},n.exports.reset=function(){oe().reset()},n.exports.create=ie,n.exports.shapeFromPath=E,n.exports.shapeFromText=ce})((function(){return typeof window<`u`?window:typeof self<`u`?self:this||{}})(),st,!1);var ct=st.exports;st.exports.create;function lt({onOpenOrderTag:e}){let[t,n]=(0,_.useState)(!1),[r,i]=(0,_.useState)(``);return(0,j.jsxs)(`section`,{id:`live-services`,className:`section-padding live-services-section`,children:[(0,j.jsxs)(`div`,{className:`container`,children:[(0,j.jsxs)(`div`,{className:`section-header text-center`,children:[(0,j.jsxs)(`div`,{className:`glass-pill`,children:[(0,j.jsx)(`span`,{className:`badge-pulsing-dot`}),(0,j.jsx)(`span`,{children:`COMING SOON`})]}),(0,j.jsxs)(`h2`,{className:`section-title`,children:[`CarFrnd `,(0,j.jsx)(`span`,{className:`magenta-gradient-text`,children:`Auto Services`})]}),(0,j.jsx)(`p`,{className:`section-subtitle`,children:`More ways to care for your car are coming soon.`}),(0,j.jsxs)(`div`,{className:`services-summary-pill`,children:[(0,j.jsx)(`span`,{className:`s-name`,children:`Doorstep Car Wash`}),(0,j.jsx)(`span`,{className:`dot-sep`,children:`•`}),(0,j.jsx)(`span`,{className:`s-name`,children:`Car Detailing`}),(0,j.jsx)(`span`,{className:`dot-sep`,children:`•`}),(0,j.jsx)(`span`,{className:`s-name`,children:`Tyre & Wheel Services`})]})]}),(0,j.jsx)(`div`,{className:`clean-services-grid`,children:[{title:`Doorstep Car Wash`,desc:`Eco-friendly high-pressure foam wash, wheel rim scrubbing, tire dressing, and interior floor vacuuming delivered at your home or office.`,icon:O,image:`/images/service_car_wash.jpg`},{title:`Car Detailing`,desc:`Showroom finish packages combining deep interior steam sanitization, leather conditioning, and 3-step exterior machine polish.`,icon:we,image:`/images/service_car_detailing.jpg`},{title:`Tyre & Wheel Services`,desc:`Genuine branded tyre fitment from top brands, precision computerized 3D wheel alignment, dynamic balancing, and nitrogen inflation.`,icon:D,image:`/images/service_tyres_wheels.jpg`}].map((e,t)=>{let n=e.icon;return(0,j.jsxs)(`div`,{className:`clean-service-card glass-card`,children:[(0,j.jsxs)(`div`,{className:`service-card-media`,children:[(0,j.jsx)(`img`,{src:e.image,alt:e.title,className:`service-card-photo`,loading:`lazy`}),(0,j.jsx)(`div`,{className:`service-media-overlay`}),(0,j.jsx)(`span`,{className:`coming-soon-badge-floating`,children:`Coming Soon`}),(0,j.jsx)(`div`,{className:`service-icon-floating`,children:(0,j.jsx)(n,{size:18,color:`#FF2B85`})})]}),(0,j.jsxs)(`div`,{className:`service-card-body`,children:[(0,j.jsx)(`h3`,{className:`clean-service-title`,children:e.title}),(0,j.jsx)(`p`,{className:`clean-service-desc`,children:e.desc}),(0,j.jsx)(`div`,{className:`service-card-footer`,children:(0,j.jsxs)(`span`,{className:`service-launch-note`,children:[(0,j.jsx)(`span`,{className:`dot-ping`}),` Launching Next`]})})]})]},t)})}),(0,j.jsxs)(`div`,{className:`services-notify-box glass-card`,children:[(0,j.jsxs)(`div`,{className:`notify-content-left`,children:[(0,j.jsx)(`h4`,{children:`Be the First to Know When We Launch in Your City`}),(0,j.jsx)(`p`,{children:`Get early priority booking access and exclusive launch discounts across all CarFrnd Auto Services.`})]}),t?(0,j.jsxs)(`div`,{className:`notify-success-badge`,children:[(0,j.jsx)(E,{size:18,color:`#059669`}),(0,j.jsxs)(`span`,{children:[`You're on the priority launch list (`,r,`)!`]})]}):(0,j.jsxs)(`form`,{onSubmit:e=>{e.preventDefault(),r.trim()&&(n(!0),ct({particleCount:75,spread:65,origin:{y:.6}}))},className:`notify-form-inline`,children:[(0,j.jsx)(`input`,{type:`text`,placeholder:`Enter email or mobile number`,value:r,onChange:e=>i(e.target.value),required:!0,className:`notify-input`}),(0,j.jsxs)(`button`,{type:`submit`,className:`btn-primary notify-submit-btn`,children:[(0,j.jsx)(ae,{size:15}),(0,j.jsx)(`span`,{children:`Notify Me on Launch`})]})]})]})]}),(0,j.jsx)(`style`,{children:`
        .live-services-section {
          background: #FFFFFF;
          padding: 44px 0 28px 0;
          border-top: 1px solid #E2E8F0;
        }

        .badge-pulsing-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: var(--magenta);
        }

        .services-summary-pill {
          display: inline-flex;
          align-items: center;
          gap: 12px;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          padding: 8px 20px;
          border-radius: 30px;
          font-family: var(--font-heading);
          font-size: 0.9rem;
          font-weight: 700;
          color: #334155;
          margin-top: 14px;
          box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04);
        }

        .dot-sep {
          color: var(--magenta);
          font-size: 1.1rem;
        }

        .s-name {
          color: #0F172A;
        }

        .clean-services-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 24px;
          margin: 32px 0 32px 0;
        }

        .clean-service-card {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 20px;
          overflow: hidden;
          padding: 0;
          display: flex;
          flex-direction: column;
          box-shadow: 0 4px 20px rgba(15, 23, 42, 0.05);
          transition: all 0.35s ease;
        }

        .clean-service-card:hover {
          border-color: rgba(255, 43, 133, 0.35);
          transform: translateY(-5px);
          box-shadow: 0 16px 36px rgba(15, 23, 42, 0.09), 0 0 20px rgba(255, 43, 133, 0.08);
        }

        .service-card-media {
          position: relative;
          width: 100%;
          height: 195px;
          overflow: hidden;
          background: #0F172A;
        }

        .service-card-photo {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
          transition: transform 0.5s ease;
        }

        .clean-service-card:hover .service-card-photo {
          transform: scale(1.06);
        }

        .service-media-overlay {
          position: absolute;
          inset: 0;
          background: linear-gradient(180deg, rgba(15, 23, 42, 0.1) 0%, rgba(15, 23, 42, 0.45) 100%);
        }

        .coming-soon-badge-floating {
          position: absolute;
          top: 14px;
          right: 14px;
          font-size: 0.7rem;
          font-weight: 800;
          color: var(--magenta);
          background: rgba(255, 255, 255, 0.95);
          backdrop-filter: blur(8px);
          padding: 4px 10px;
          border-radius: 20px;
          border: 1px solid rgba(255, 43, 133, 0.2);
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.12);
        }

        .service-icon-floating {
          position: absolute;
          bottom: 12px;
          left: 14px;
          width: 38px;
          height: 38px;
          border-radius: 10px;
          background: rgba(255, 255, 255, 0.95);
          backdrop-filter: blur(8px);
          border: 1px solid rgba(255, 43, 133, 0.25);
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .service-card-body {
          padding: 22px 24px;
          display: flex;
          flex-direction: column;
          flex: 1;
        }

        .clean-service-title {
          font-size: 1.25rem;
          font-weight: 800;
          color: #0F172A;
          margin-bottom: 8px;
        }

        .clean-service-desc {
          font-size: 0.88rem;
          color: #64748B;
          line-height: 1.6;
          margin-bottom: 18px;
          flex: 1;
        }

        .service-card-footer {
          padding-top: 14px;
          border-top: 1px solid #F1F5F9;
          margin-top: auto;
        }

        .service-launch-note {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 0.78rem;
          font-weight: 700;
          color: #059669;
        }

        .dot-ping {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: #10B981;
        }

        /* Priority Notification Banner */
        .services-notify-box {
          background: linear-gradient(135deg, #F8FAFC 0%, #FFF5F9 100%);
          border: 1.5px solid var(--magenta-border);
          border-radius: 20px;
          padding: 32px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 28px;
          box-shadow: 0 10px 30px rgba(255, 43, 133, 0.05);
        }

        .notify-content-left h4 {
          font-size: 1.25rem;
          font-weight: 800;
          color: #0F172A;
          margin-bottom: 4px;
        }

        .notify-content-left p {
          font-size: 0.9rem;
          color: #64748B;
          margin: 0;
        }

        .notify-form-inline {
          display: flex;
          align-items: center;
          gap: 10px;
          min-width: 380px;
        }

        .notify-input {
          flex: 1;
          padding: 12px 16px;
          border-radius: 10px;
          border: 1px solid #CBD5E1;
          background: #FFFFFF;
          font-size: 0.9rem;
          outline: none;
          color: #0F172A;
        }

        .notify-input:focus {
          border-color: var(--magenta);
        }

        .notify-submit-btn {
          padding: 12px 20px;
          font-size: 0.88rem;
          white-space: nowrap;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .notify-success-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: #ECFDF5;
          color: #059669;
          border: 1px solid #A7F3D0;
          padding: 10px 18px;
          border-radius: 12px;
          font-size: 0.88rem;
          font-weight: 700;
        }

        @media (max-width: 992px) {
          .clean-services-grid {
            grid-template-columns: 1fr;
            gap: 18px;
          }

          .services-summary-pill {
            flex-wrap: wrap;
            justify-content: center;
            gap: 6px 10px;
            font-size: 0.82rem;
            padding: 10px 16px;
          }

          .services-notify-box {
            flex-direction: column;
            text-align: center;
            padding: 24px;
            gap: 18px;
          }

          .notify-form-inline {
            width: 100%;
            min-width: unset;
            flex-direction: column;
          }

          .notify-input, .notify-submit-btn {
            width: 100%;
          }
        }
      `})]})}function ut({onOpenBill:e,onOpenTrackOrder:t}){let[n,r]=(0,_.useState)(1),[i,a]=(0,_.useState)(``),[o,s]=(0,_.useState)(``),[c,l]=(0,_.useState)(``),[u,d]=(0,_.useState)(``),[f,p]=(0,_.useState)(!1),[m,h]=(0,_.useState)(null),g=450*n;return(0,j.jsxs)(`section`,{id:`order-tag`,className:`section-padding order-section`,children:[(0,j.jsx)(`div`,{className:`container`,children:(0,j.jsx)(`div`,{className:`order-box glass-card`,children:(0,j.jsxs)(`div`,{className:`order-grid`,children:[(0,j.jsxs)(`div`,{className:`order-preview-col`,children:[(0,j.jsxs)(`div`,{className:`glass-pill`,children:[(0,j.jsx)(we,{size:13}),(0,j.jsx)(`span`,{children:`SPECIAL LAUNCH OFFER — ₹450 (INCL. GST)`})]}),(0,j.jsxs)(`h2`,{className:`order-title`,children:[`Get Your Weatherproof `,(0,j.jsx)(`br`,{}),(0,j.jsx)(`span`,{className:`magenta-gradient-text`,children:`CarFrnd Tag`})]}),(0,j.jsxs)(`p`,{className:`order-subtitle`,children:[(0,j.jsx)(`strong`,{children:`Your car's smart contact tag.`}),` Protect your personal phone number and receive alerts about your car. Delivered to your doorstep in 3–5 business days.`]}),(0,j.jsxs)(`div`,{className:`order-features-list`,children:[(0,j.jsxs)(`div`,{className:`order-feature-item`,children:[(0,j.jsx)(`div`,{className:`feat-icon-box`,children:(0,j.jsx)(be,{size:20,color:`#FF2B85`})}),(0,j.jsxs)(`div`,{className:`feat-content`,children:[(0,j.jsx)(`h4`,{children:`Your Phone Number Stays Private`}),(0,j.jsx)(`p`,{children:`Callers reach you via masked phone forwarding. Your personal mobile number is never exposed.`})]})]}),(0,j.jsxs)(`div`,{className:`order-feature-item`,children:[(0,j.jsx)(`div`,{className:`feat-icon-box`,children:(0,j.jsx)(we,{size:20,color:`#FF2B85`})}),(0,j.jsxs)(`div`,{className:`feat-content`,children:[(0,j.jsx)(`h4`,{children:`Weatherproof Automotive Decal`}),(0,j.jsx)(`p`,{children:`Durable Automotive Decal. Premium vinyl designed for use on automotive windshield.`})]})]}),(0,j.jsxs)(`div`,{className:`order-feature-item`,children:[(0,j.jsx)(`div`,{className:`feat-icon-box`,children:(0,j.jsx)(Ee,{size:20,color:`#FF2B85`})}),(0,j.jsxs)(`div`,{className:`feat-content`,children:[(0,j.jsx)(`h4`,{children:`Doorstep Delivery`}),(0,j.jsx)(`p`,{children:`Delivered to your doorstep within 3–5 business days.`})]})]})]})]}),(0,j.jsx)(`div`,{className:`order-form-col`,children:f?(0,j.jsxs)(`div`,{className:`order-success-card`,children:[(0,j.jsx)(`div`,{className:`success-icon`,children:(0,j.jsx)(be,{size:48,color:`#FF2B85`})}),(0,j.jsx)(`h3`,{children:`Order Confirmed! 🎉`}),(0,j.jsxs)(`p`,{className:`success-txt`,children:[`Thank you `,(0,j.jsx)(`strong`,{children:m?.name||o}),`! Your order for `,(0,j.jsxs)(`strong`,{children:[m?.quantity||n,`x CarFrnd Tag`]}),` for vehicle `,(0,j.jsx)(`strong`,{children:(m?.vehicleNo||i).toUpperCase()}),` has been placed successfully.`]}),(0,j.jsxs)(`div`,{className:`tracking-box`,children:[(0,j.jsxs)(`span`,{children:[`Order ID: `,(0,j.jsx)(`code`,{children:m?.orderId||`CF-842918`})]}),(0,j.jsxs)(`span`,{children:[`Estimated Delivery: `,(0,j.jsx)(`strong`,{children:`3–5 Business Days`})]})]}),(0,j.jsxs)(`div`,{style:{display:`flex`,gap:`10px`,width:`100%`,marginTop:`6px`},children:[(0,j.jsxs)(`button`,{className:`btn-primary`,style:{flex:1,padding:`10px`,fontSize:`0.85rem`,display:`flex`,alignItems:`center`,justifyContent:`center`,gap:`6px`},onClick:()=>e&&e(m),children:[(0,j.jsx)(ve,{size:15}),` View Bill / Invoice`]}),(0,j.jsxs)(`button`,{className:`btn-secondary`,style:{flex:1,padding:`10px`,fontSize:`0.85rem`,display:`flex`,alignItems:`center`,justifyContent:`center`,gap:`6px`},onClick:()=>t&&t(m?.orderId),children:[(0,j.jsx)(Ee,{size:15}),` Track Order`]})]}),(0,j.jsx)(`button`,{className:`btn-secondary`,style:{width:`100%`,marginTop:`4px`,fontSize:`0.82rem`},onClick:()=>p(!1),children:`Place Another Order`})]}):(0,j.jsxs)(`form`,{onSubmit:e=>{if(e.preventDefault(),!o.trim()||!c.trim()||!i.trim()||!u.trim()){alert(`Please fill out all mandatory details including Vehicle Number!`);return}let t={orderId:`CF-${Math.floor(1e5+Math.random()*9e5)}`,name:o,phone:c,vehicleNo:i.toUpperCase(),address:u,quantity:n,totalPrice:g,date:new Date().toLocaleDateString(`en-IN`,{day:`numeric`,month:`short`,year:`numeric`})};h(t),p(!0),ct({particleCount:120,spread:80,origin:{y:.5}})},className:`order-checkout-form`,children:[(0,j.jsx)(`h3`,{className:`form-head-title`,children:`Shipping & Contact Details`}),(0,j.jsxs)(`div`,{className:`form-group`,children:[(0,j.jsx)(`label`,{children:`Full Name`}),(0,j.jsx)(`input`,{type:`text`,placeholder:`e.g. Rahul Sharma`,value:o,onChange:e=>s(e.target.value),required:!0})]}),(0,j.jsxs)(`div`,{className:`form-group`,children:[(0,j.jsx)(`label`,{children:`Mobile Number (For Delivery Updates)`}),(0,j.jsx)(`input`,{type:`tel`,placeholder:`10-digit mobile number`,value:c,onChange:e=>l(e.target.value),required:!0})]}),(0,j.jsxs)(`div`,{className:`form-group`,children:[(0,j.jsxs)(`label`,{children:[`Vehicle Number `,(0,j.jsx)(`span`,{className:`req-star`,children:`*`})]}),(0,j.jsx)(`input`,{type:`text`,placeholder:`e.g. MH 01 AB 1234`,value:i,onChange:e=>a(e.target.value.toUpperCase()),required:!0})]}),(0,j.jsxs)(`div`,{className:`form-group`,children:[(0,j.jsx)(`label`,{children:`Shipping Address`}),(0,j.jsx)(`textarea`,{rows:2,placeholder:`Flat/House No., Street, City, State, Pincode`,value:u,onChange:e=>d(e.target.value),required:!0})]}),(0,j.jsxs)(`div`,{className:`checkout-pricing-card`,children:[(0,j.jsxs)(`div`,{className:`pricing-main-row`,children:[(0,j.jsxs)(`div`,{className:`qty-control-wrapper`,children:[(0,j.jsx)(`span`,{className:`qty-label`,children:`Qty:`}),(0,j.jsxs)(`div`,{className:`qty-picker`,children:[(0,j.jsx)(`button`,{type:`button`,onClick:()=>r(Math.max(1,n-1)),"aria-label":`Decrease quantity`,children:`−`}),(0,j.jsx)(`span`,{className:`qty-val`,children:n}),(0,j.jsx)(`button`,{type:`button`,onClick:()=>r(n+1),"aria-label":`Increase quantity`,children:`+`})]})]}),(0,j.jsxs)(`div`,{className:`price-stack`,children:[(0,j.jsxs)(`span`,{className:`strike-price`,children:[`₹`,799*n]}),(0,j.jsxs)(`span`,{className:`total-price`,children:[`₹`,g]})]})]}),(0,j.jsxs)(`div`,{className:`shipping-benefit-tag`,children:[(0,j.jsx)(`span`,{className:`green-dot`}),(0,j.jsx)(`span`,{children:`INCL. GST`})]})]}),(0,j.jsxs)(`button`,{type:`submit`,className:`btn-primary full-w order-submit-btn`,children:[(0,j.jsx)(ue,{size:16}),` Pay ₹`,g,` & Place Order`]}),(0,j.jsxs)(`div`,{className:`trust-footer-row`,children:[(0,j.jsxs)(`div`,{className:`t-item`,children:[(0,j.jsx)(Ee,{size:14,color:`#FF2B85`}),(0,j.jsx)(`span`,{children:`3–5 Business Days Delivery`})]}),(0,j.jsx)(`span`,{className:`t-sep`,children:`•`}),(0,j.jsxs)(`div`,{className:`t-item`,children:[(0,j.jsx)(be,{size:14,color:`#FF2B85`}),(0,j.jsx)(`span`,{children:`Your Phone Number Stays Private`})]})]})]})})]})})}),(0,j.jsx)(`style`,{children:`
        section.order-section {
          background: #F8FAFC;
          padding-top: 14px;
          padding-bottom: 24px;
        }

        .order-box {
          padding: 38px;
          border-radius: var(--radius-xl);
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          box-shadow: 0 8px 25px rgba(15, 23, 42, 0.04);
        }

        .order-grid {
          display: grid;
          grid-template-columns: 1.1fr 0.9fr;
          gap: 40px;
          align-items: center;
        }

        .order-title {
          font-size: 2.3rem;
          font-weight: 900;
          margin: 14px 0 14px 0;
          line-height: 1.2;
          color: #0F172A;
        }

        .order-subtitle {
          font-size: 0.98rem;
          color: #64748B;
          margin-bottom: 20px;
          line-height: 1.55;
        }

        .order-features-list {
          display: flex;
          flex-direction: column;
          gap: 14px;
          margin-top: 24px;
        }

        .order-feature-item {
          display: flex;
          align-items: flex-start;
          gap: 14px;
          padding: 14px 16px;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 12px;
          transition: all 0.2s ease;
        }

        .order-feature-item:hover {
          background: #FFF1F7;
          border-color: rgba(255, 43, 133, 0.3);
        }

        .feat-icon-box {
          width: 40px;
          height: 40px;
          border-radius: 10px;
          background: #FFFFFF;
          border: 1px solid #FBCFE8;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          box-shadow: 0 2px 6px rgba(255, 43, 133, 0.08);
        }

        .feat-content h4 {
          font-size: 0.94rem;
          font-weight: 800;
          color: #0F172A;
          margin: 0 0 3px 0;
        }

        .feat-content p {
          font-size: 0.82rem;
          color: #64748B;
          margin: 0;
          line-height: 1.45;
        }

        .req-star {
          color: var(--magenta);
          font-weight: 800;
        }

        /* Order Form */
        .order-checkout-form {
          display: flex;
          flex-direction: column;
          gap: 12px;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: var(--radius-lg);
          padding: 22px;
        }

        .form-head-title {
          font-size: 1.15rem;
          font-weight: 800;
          color: #0F172A;
          margin-bottom: 2px;
        }

        .order-checkout-form label {
          font-size: 0.78rem;
          font-weight: 700;
          color: #334155;
          margin-bottom: 3px;
          display: block;
        }

        .order-checkout-form input, .order-checkout-form textarea {
          background: #FFFFFF;
          border: 1px solid #CBD5E1;
          border-radius: 8px;
          padding: 9px 12px;
          color: #0F172A;
          font-size: 0.88rem;
          outline: none;
          width: 100%;
        }

        .order-checkout-form input:focus, .order-checkout-form textarea:focus {
          border-color: var(--magenta);
        }

        .checkout-pricing-card {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 12px;
          padding: 12px 14px;
          margin: 6px 0;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .pricing-main-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
        }

        .qty-control-wrapper {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .qty-label {
          font-size: 0.8rem;
          font-weight: 700;
          color: #64748B;
        }

        .qty-picker {
          display: flex;
          align-items: center;
          gap: 8px;
          background: #F8FAFC;
          border: 1px solid #CBD5E1;
          border-radius: 8px;
          padding: 3px 8px;
        }

        .qty-picker button {
          background: none;
          border: none;
          color: var(--magenta);
          font-size: 1.15rem;
          font-weight: 800;
          cursor: pointer;
          width: 24px;
          height: 24px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 4px;
          transition: background 0.15s;
        }

        .qty-picker button:hover {
          background: #FCE7F3;
        }

        .qty-val {
          font-weight: 800;
          color: #0F172A;
          font-size: 0.95rem;
          min-width: 16px;
          text-align: center;
        }

        .price-stack {
          display: flex;
          align-items: baseline;
          gap: 8px;
        }

        .strike-price {
          font-size: 0.86rem;
          color: #94A3B8;
          text-decoration: line-through;
        }

        .total-price {
          font-family: var(--font-heading);
          font-size: 1.4rem;
          font-weight: 900;
          color: #0F172A;
        }

        .shipping-benefit-tag {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          background: #ECFDF5;
          border: 1px solid #D1FAE5;
          color: #059669;
          font-size: 0.7rem;
          font-weight: 800;
          letter-spacing: 0.03em;
          padding: 5px 10px;
          border-radius: 6px;
          text-align: center;
        }

        .green-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          flex-shrink: 0;
        }

        .order-submit-btn {
          margin-top: 4px;
          font-size: 1rem;
          padding: 14px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          font-weight: 800;
          box-shadow: 0 4px 16px rgba(255, 43, 133, 0.35);
        }

        .trust-footer-row {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          font-size: 0.76rem;
          color: #64748B;
          margin-top: 8px;
          flex-wrap: wrap;
          text-align: center;
        }

        .t-item {
          display: flex;
          align-items: center;
          gap: 5px;
          white-space: nowrap;
          font-weight: 600;
        }

        .t-sep {
          color: #CBD5E1;
        }

        .order-success-card {
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          gap: 12px;
          padding: 20px 14px;
        }

        .tracking-box {
          background: var(--magenta-light);
          border: 1px solid var(--magenta-border);
          border-radius: 10px;
          padding: 12px;
          width: 100%;
          display: flex;
          flex-direction: column;
          gap: 4px;
          font-size: 0.84rem;
          color: #0F172A;
        }

        @media (max-width: 900px) {
          section.order-section {
            background: #FFFFFF;
            padding-top: 24px;
            padding-bottom: 48px;
          }
          .order-box {
            background: transparent !important;
            border: none !important;
            box-shadow: none !important;
            padding: 0 !important;
            border-radius: 0 !important;
          }
          .order-box:hover {
            transform: none !important;
            box-shadow: none !important;
            border-color: transparent !important;
          }
          .order-grid {
            grid-template-columns: 1fr;
            gap: 28px;
          }
          .order-title {
            font-size: 1.85rem;
            margin-top: 10px;
          }
          .order-checkout-form {
            background: transparent !important;
            border: none !important;
            padding: 0 !important;
            border-radius: 0 !important;
            box-shadow: none !important;
            gap: 16px;
          }
          .order-checkout-form input,
          .order-checkout-form textarea {
            background: #F8FAFC;
            border: 1px solid #CBD5E1;
            border-radius: 10px;
            padding: 11px 14px;
            font-size: 0.92rem;
          }
          .order-checkout-form input:focus,
          .order-checkout-form textarea:focus {
            background: #FFFFFF;
            border-color: var(--magenta);
            box-shadow: 0 0 0 3px rgba(255, 43, 133, 0.12);
          }
          .checkout-pricing-card {
            background: #F8FAFC;
            border: 1px solid #E2E8F0;
            border-radius: 14px;
            padding: 14px;
            margin: 6px 0;
          }
          .qty-picker {
            background: #FFFFFF;
          }
          .trust-footer-row {
            gap: 8px;
            font-size: 0.74rem;
            margin-top: 10px;
          }
        }

        @media (max-width: 420px) {
          .trust-footer-row {
            flex-direction: column;
            gap: 4px;
          }
          .t-sep {
            display: none;
          }
        }
      `})]})}function dt(){let[e,t]=(0,_.useState)(0);return(0,j.jsxs)(`section`,{className:`section-padding faq-section`,children:[(0,j.jsxs)(`div`,{className:`container`,children:[(0,j.jsxs)(`div`,{className:`section-header text-center`,children:[(0,j.jsxs)(`div`,{className:`glass-pill`,children:[(0,j.jsx)(ce,{size:14}),(0,j.jsx)(`span`,{children:`FREQUENTLY ASKED QUESTIONS`})]}),(0,j.jsxs)(`h2`,{className:`section-title`,children:[`Everything You Need To `,(0,j.jsx)(`br`,{}),(0,j.jsx)(`span`,{className:`magenta-gradient-text`,children:`Know About CarFrnd`})]})]}),(0,j.jsx)(`div`,{className:`faq-accordion`,children:[{q:`How does the CarFrnd Tag protect my personal mobile number?`,a:`When someone scans your CarFrnd Tag, they can notify you about your car without seeing your personal phone number. Supported contact is handled through secure masked communication, keeping your phone number private.`},{q:`Does a person scanning my CarFrnd Tag need to download the CarFrnd app?`,a:`No. Anyone with a smartphone camera can scan your CarFrnd Tag. It opens a secure web-based contact page in their browser without requiring an app download or sign-up.`},{q:`Are there any monthly subscription fees for CarFrnd Tag?`,a:`No. CarFrnd Tag is a one-time purchase of ₹450 including GST. There are no recurring monthly or annual subscription fees.`}].map((n,r)=>{let i=e===r;return(0,j.jsxs)(`div`,{className:`faq-item glass-card ${i?`open`:``}`,onClick:()=>t(i?-1:r),children:[(0,j.jsxs)(`div`,{className:`faq-question-row`,children:[(0,j.jsx)(`h3`,{className:`faq-question-title`,children:n.q}),(0,j.jsx)(`div`,{className:`faq-arrow`,children:(0,j.jsx)(se,{size:20,className:i?`rotate-180`:``})})]}),i&&(0,j.jsx)(`div`,{className:`faq-answer-content`,children:(0,j.jsx)(`p`,{children:n.a})})]},r)})}),(0,j.jsxs)(`div`,{className:`faq-support-box glass-card`,children:[(0,j.jsx)(`div`,{className:`support-icon-wrap`,children:(0,j.jsx)(fe,{size:24,color:`#FF2B85`})}),(0,j.jsxs)(`div`,{className:`support-text-wrap`,children:[(0,j.jsx)(`h4`,{children:`Need help with your CarFrnd Tag?`}),(0,j.jsx)(`p`,{children:`Our support team can assist you with your CarFrnd Tag.`})]}),(0,j.jsx)(`a`,{href:`mailto:support@carfrnd.com`,className:`btn-primary`,children:`Email support@carfrnd.com`})]})]}),(0,j.jsx)(`style`,{children:`
        section.faq-section {
          background: #FFFFFF;
          padding-top: 28px;
        }

        .faq-accordion {
          max-width: 860px;
          margin: 0 auto;
          display: flex;
          flex-direction: column;
          gap: 14px;
        }

        .faq-item {
          padding: 22px 26px;
          cursor: pointer;
          transition: all 0.25s ease;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 16px;
        }

        .faq-item.open {
          border-color: var(--magenta);
          box-shadow: 0 8px 25px rgba(255, 43, 133, 0.1);
        }

        .faq-question-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
        }

        .faq-question-title {
          font-size: 1.1rem;
          font-weight: 800;
          color: #0F172A;
        }

        .faq-arrow {
          color: var(--magenta);
          transition: transform 0.3s ease;
          flex-shrink: 0;
        }

        .rotate-180 {
          transform: rotate(180deg);
        }

        .faq-answer-content {
          margin-top: 14px;
          padding-top: 14px;
          border-top: 1px solid #F1F5F9;
          font-size: 0.95rem;
          color: #475569;
          line-height: 1.6;
        }

        .faq-support-box {
          max-width: 860px;
          margin: 28px auto 0 auto;
          padding: 24px 28px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 20px;
          background: var(--magenta-light);
          border: 1px solid var(--magenta-border);
          border-radius: 20px;
        }

        .support-icon-wrap {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          background: #FFFFFF;
          border: 1px solid var(--magenta-border);
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }

        .support-text-wrap {
          flex: 1;
        }

        .support-text-wrap h4 {
          font-size: 1.1rem;
          font-weight: 800;
          color: #0F172A;
          margin-bottom: 4px;
        }

        .support-text-wrap p {
          font-size: 0.88rem;
          color: #64748B;
          line-height: 1.4;
        }

        @media (max-width: 768px) {
          section.faq-section {
            padding-top: 16px;
          }
          .faq-support-box {
            flex-direction: column;
            text-align: center;
            padding: 24px 18px;
          }
          .faq-support-box .btn-primary {
            width: 100%;
          }
        }
      `})]})}function ft({onOpenOrderTag:e,onNavigate:t}){return(0,j.jsxs)(`footer`,{className:`footer-section`,children:[(0,j.jsxs)(`div`,{className:`container`,children:[(0,j.jsxs)(`div`,{className:`footer-top-grid`,children:[(0,j.jsxs)(`div`,{className:`footer-brand-col`,children:[(0,j.jsx)(`a`,{href:`/`,className:`footer-logo`,onClick:e=>{e.preventDefault(),t?t(`home`):window.scrollTo({top:0,behavior:`smooth`})},children:(0,j.jsx)(`img`,{src:`/carfrndlogo.png`,alt:`CarFrnd Logo`,className:`footer-logo-img`})}),(0,j.jsx)(`p`,{className:`footer-brand-desc`,children:`Your car's smart contact tag. Helping car owners stay connected while keeping their personal phone number private.`}),(0,j.jsx)(`div`,{className:`footer-contact-info`,children:(0,j.jsxs)(`div`,{className:`c-item`,children:[(0,j.jsx)(fe,{size:15,color:`#FF2B85`}),(0,j.jsx)(`span`,{className:`c-label`,children:`Support: `}),(0,j.jsx)(`a`,{href:`mailto:support@carfrnd.com`,className:`email-link`,children:`support@carfrnd.com`})]})})]}),(0,j.jsxs)(`div`,{className:`footer-col`,children:[(0,j.jsx)(`h4`,{className:`footer-heading`,children:`CarFrnd Tag`}),(0,j.jsxs)(`ul`,{className:`footer-links`,children:[(0,j.jsx)(`li`,{children:(0,j.jsx)(`a`,{href:`#app-showcase`,onClick:()=>{t&&t(`home`)},children:`How CarFrnd Tag Works`})}),(0,j.jsx)(`li`,{children:(0,j.jsx)(`a`,{href:`#`,onClick:t=>{t.preventDefault(),e()},children:`Order CarFrnd Tag (₹450)`})}),(0,j.jsx)(`li`,{children:(0,j.jsx)(`a`,{href:`/activate-tag`,onClick:e=>{e.preventDefault(),t&&t(`activate-tag`)},children:`Activate CarFrnd Tag`})}),(0,j.jsx)(`li`,{children:(0,j.jsx)(`a`,{href:`/track-order`,onClick:e=>{e.preventDefault(),t&&t(`track-order`)},children:`Track Your Order`})}),(0,j.jsx)(`li`,{children:(0,j.jsx)(`a`,{href:`/bill`,onClick:e=>{e.preventDefault(),t&&t(`bill`)},children:`Download Bill / Invoice`})}),(0,j.jsx)(`li`,{children:(0,j.jsx)(`a`,{href:`#app-showcase`,onClick:()=>{t&&t(`home`)},children:`Privacy & Phone Protection`})})]})]})]}),(0,j.jsxs)(`div`,{className:`footer-bottom-bar`,children:[(0,j.jsx)(`p`,{children:`© 2026 Aramel Tech Private Limited. All rights reserved.`}),(0,j.jsxs)(`div`,{className:`footer-legal-links`,children:[(0,j.jsx)(`a`,{href:`#`,children:`Privacy Policy`}),(0,j.jsx)(`a`,{href:`#`,children:`Terms of Service`})]})]})]}),(0,j.jsx)(`style`,{children:`
        .footer-section {
          background: #F1F5F9;
          border-top: 1px solid #E2E8F0;
          padding: 44px 0 36px 0;
          color: #475569;
        }

        .footer-top-grid {
          display: grid;
          grid-template-columns: 1.8fr 1fr;
          gap: 48px;
          margin-bottom: 32px;
        }

        .footer-logo {
          display: flex;
          align-items: center;
          text-decoration: none;
          margin-bottom: 22px;
          height: 56px;
          min-width: 180px;
          overflow: visible;
        }

        .footer-logo-img {
          height: 60px;
          width: auto;
          object-fit: contain;
          transform: scale(2.2);
          transform-origin: left center;
          transition: transform 0.2s ease;
        }

        .footer-logo-img:hover {
          transform: scale(2.28);
        }

        .footer-brand-desc {
          font-size: 0.88rem;
          line-height: 1.55;
          margin-bottom: 16px;
          max-width: 360px;
          color: #64748B;
        }

        .footer-contact-info {
          display: flex;
          flex-direction: column;
          gap: 8px;
          font-size: 0.86rem;
        }

        .c-item {
          display: flex;
          align-items: center;
          gap: 8px;
          color: #334155;
        }

        .c-label {
          font-weight: 500;
        }

        .email-link {
          color: #0F172A;
          text-decoration: none;
          font-weight: 700;
          transition: color 0.2s ease;
        }

        .email-link:hover {
          color: var(--magenta);
          text-decoration: underline;
        }

        .footer-heading {
          font-family: var(--font-heading);
          font-size: 0.98rem;
          font-weight: 800;
          color: #0F172A;
          margin-bottom: 14px;
        }

        .footer-links {
          list-style: none;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .footer-links a {
          color: #64748B;
          text-decoration: none;
          font-size: 0.86rem;
          font-weight: 500;
          transition: color 0.2s ease;
        }

        .footer-links a:hover {
          color: var(--magenta);
        }

        .footer-bottom-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-top: 24px;
          border-top: 1px solid #CBD5E1;
          font-size: 0.82rem;
          color: #64748B;
        }

        .footer-legal-links {
          display: flex;
          gap: 16px;
        }

        .footer-legal-links a {
          color: #64748B;
          text-decoration: none;
          font-weight: 500;
        }

        .footer-legal-links a:hover {
          color: var(--magenta);
        }

        @media (max-width: 900px) {
          .footer-section {
            padding-bottom: 110px !important;
          }
          .footer-top-grid {
            grid-template-columns: 1fr;
            gap: 28px;
          }
          .footer-logo {
            margin-bottom: 20px;
            height: 52px;
            margin-left: -12px;
          }
          .footer-logo-img {
            height: 56px;
            transform: scale(2.2);
            transform-origin: left center;
          }
          .footer-bottom-bar {
            flex-direction: column;
            gap: 12px;
            text-align: center;
          }
        }
      `})]})}function pt({onOpenOrderTag:e,onOpenAccount:t,onNavigate:n,currentView:r}){let[i,a]=(0,_.useState)(`home`);(0,_.useEffect)(()=>{if(r&&r!==`home`)return;let e=()=>{let e=window.scrollY+250,t=document.getElementById(`order-tag`);t&&e>=t.offsetTop?a(`order`):a(`home`)};return window.addEventListener(`scroll`,e,{passive:!0}),()=>window.removeEventListener(`scroll`,e)},[r]);let o=r&&r!==`home`?r:i,s=(e,t)=>{if(a(t),r&&r!==`home`&&n){n(`home`),setTimeout(()=>{let t=document.getElementById(e);t?t.scrollIntoView({behavior:`smooth`}):e===`home`&&window.scrollTo({top:0,behavior:`smooth`})},50);return}let i=document.getElementById(e);i?i.scrollIntoView({behavior:`smooth`}):e===`home`&&window.scrollTo({top:0,behavior:`smooth`})};return(0,j.jsxs)(`nav`,{className:`mobile-bottom-nav`,children:[(0,j.jsxs)(`div`,{className:`bottom-nav-inner`,children:[(0,j.jsxs)(`button`,{className:`nav-tab-item ${o===`home`?`active`:``}`,onClick:()=>s(`home`,`home`),children:[(0,j.jsx)(le,{size:20}),(0,j.jsx)(`span`,{children:`Home`})]}),(0,j.jsxs)(`button`,{className:`nav-tab-item ${r===`track-order`?`active`:``}`,onClick:()=>{n&&n(`track-order`)},children:[(0,j.jsx)(Ee,{size:20}),(0,j.jsx)(`span`,{children:`Track Order`})]}),(0,j.jsxs)(`div`,{className:`center-fab-wrapper`,children:[(0,j.jsxs)(`button`,{className:`center-fab-btn`,onClick:()=>{s(`order-tag`,`order`),e&&e()},"aria-label":`Get CarFrnd Tag`,children:[(0,j.jsx)(Se,{size:22,color:`#FFFFFF`}),(0,j.jsx)(`span`,{className:`fab-pulse-ring`})]}),(0,j.jsx)(`span`,{className:`center-fab-label`,children:`₹450`}),(0,j.jsx)(`span`,{className:`fab-badge`,children:`BUY`})]}),(0,j.jsxs)(`button`,{className:`nav-tab-item`,onClick:()=>{t&&t()},children:[(0,j.jsx)(De,{size:20}),(0,j.jsx)(`span`,{children:`Account`})]})]}),(0,j.jsx)(`style`,{children:`
        .mobile-bottom-nav {
          display: none;
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          z-index: 150;
          background: rgba(255, 255, 255, 0.96);
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
          border-top: 1px solid #E2E8F0;
          box-shadow: 0 -8px 25px rgba(15, 23, 42, 0.08);
          padding-bottom: env(safe-area-inset-bottom, 6px);
        }

        .bottom-nav-inner {
          display: flex;
          align-items: center;
          justify-content: space-around;
          height: 62px;
          padding: 0 6px;
          position: relative;
        }

        .nav-tab-item {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          background: none;
          border: none;
          color: #64748B;
          font-size: 0.68rem;
          font-weight: 700;
          gap: 3px;
          cursor: pointer;
          transition: all 0.2s ease;
          padding: 4px 0;
        }

        .nav-tab-item.active {
          color: var(--magenta);
        }

        .nav-tab-item.active svg {
          transform: scale(1.1);
          color: var(--magenta);
        }

        /* Center Floating Button */
        .center-fab-wrapper {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          position: relative;
          margin-top: -22px;
        }

        .center-fab-btn {
          width: 52px;
          height: 52px;
          border-radius: 50%;
          background: linear-gradient(135deg, #FF2B85 0%, #E91E63 100%);
          border: 3px solid #FFFFFF;
          box-shadow: 0 4px 18px rgba(255, 43, 133, 0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          position: relative;
          transition: transform 0.2s ease;
        }

        .center-fab-btn:active {
          transform: scale(0.92);
        }

        .center-fab-label {
          font-size: 0.65rem;
          font-weight: 800;
          color: var(--magenta);
          margin-top: 3px;
        }

        .fab-badge {
          position: absolute;
          top: -4px;
          right: 6px;
          background: #10B981;
          color: #FFFFFF;
          font-size: 0.55rem;
          font-weight: 900;
          padding: 1px 4px;
          border-radius: 4px;
          border: 1px solid #FFFFFF;
        }

        .fab-pulse-ring {
          position: absolute;
          inset: -4px;
          border-radius: 50%;
          border: 2px solid rgba(255, 43, 133, 0.5);
          animation: fabPulse 2s infinite ease-out;
        }

        @keyframes fabPulse {
          0% {
            transform: scale(0.95);
            opacity: 0.8;
          }
          100% {
            transform: scale(1.35);
            opacity: 0;
          }
        }

        @media (max-width: 900px) {
          .mobile-bottom-nav {
            display: block;
          }
        }
      `})]})}function mt({isOpen:e,onClose:t}){let[n,r]=(0,_.useState)(``),[i,a]=(0,_.useState)(!1);return e?(0,j.jsxs)(`div`,{className:`doorstep-modal-backdrop`,onClick:t,children:[(0,j.jsxs)(`div`,{className:`doorstep-modal-box glass-card`,onClick:e=>e.stopPropagation(),children:[(0,j.jsx)(`button`,{className:`doorstep-close-btn`,onClick:t,"aria-label":`Close modal`,children:`×`}),i?(0,j.jsxs)(`div`,{className:`doorstep-success-view`,children:[(0,j.jsx)(`div`,{className:`success-icon-wrap`,children:(0,j.jsx)(E,{size:36,color:`#059669`})}),(0,j.jsx)(`h3`,{children:`You're on the Priority List! 🎉`}),(0,j.jsxs)(`p`,{children:[`We'll notify `,(0,j.jsx)(`strong`,{children:n}),` the moment Doorstep Car Wash launches in your city.`]}),(0,j.jsxs)(`span`,{className:`early-perk-badge`,children:[(0,j.jsx)(we,{size:13}),` Includes 20% First Wash Launch Discount`]}),(0,j.jsx)(`button`,{className:`btn-primary full-w mt-16`,onClick:()=>{a(!1),r(``),t()},children:`Got It`})]}):(0,j.jsxs)(`div`,{className:`doorstep-content-view`,children:[(0,j.jsxs)(`div`,{className:`doorstep-top-badge`,children:[(0,j.jsx)(`span`,{className:`badge-pulsing-dot`}),(0,j.jsx)(`span`,{children:`COMING SOON`})]}),(0,j.jsx)(`div`,{className:`doorstep-icon-circle`,children:(0,j.jsx)(O,{size:32,color:`#FF2B85`})}),(0,j.jsx)(`h3`,{className:`doorstep-title`,children:`Doorstep Car Wash Coming Soon`}),(0,j.jsx)(`p`,{className:`doorstep-sub`,children:`We're getting this service ready for you.`}),(0,j.jsx)(`p`,{className:`doorstep-detail`,children:`Eco-friendly high pressure foam wash, interior deep vacuuming, and tire shine delivered directly at your apartment parking or office bay.`}),(0,j.jsxs)(`form`,{onSubmit:e=>{e.preventDefault(),n.trim()&&(a(!0),ct({particleCount:80,spread:70,origin:{y:.6}}))},className:`doorstep-form`,children:[(0,j.jsx)(`div`,{className:`form-group`,style:{width:`100%`},children:(0,j.jsx)(`input`,{type:`text`,placeholder:`Enter email or mobile number`,value:n,onChange:e=>r(e.target.value),className:`doorstep-input`,required:!0})}),(0,j.jsxs)(`button`,{type:`submit`,className:`btn-primary full-w notify-btn`,children:[(0,j.jsx)(ae,{size:16}),(0,j.jsx)(`span`,{children:`Notify Me on Launch`})]})]})]})]}),(0,j.jsx)(`style`,{children:`
        .doorstep-modal-backdrop {
          position: fixed;
          inset: 0;
          background: rgba(15, 23, 42, 0.7);
          backdrop-filter: blur(8px);
          -webkit-backdrop-filter: blur(8px);
          z-index: 250;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 16px;
        }

        .doorstep-modal-box {
          width: 100%;
          max-width: 480px;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: var(--radius-xl);
          padding: 32px 28px;
          position: relative;
          box-shadow: 0 25px 60px rgba(15, 23, 42, 0.25);
          animation: modalAppear 0.25s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes modalAppear {
          from {
            opacity: 0;
            transform: scale(0.94) translateY(10px);
          }
          to {
            opacity: 1;
            transform: scale(1) translateY(0);
          }
        }

        .doorstep-close-btn {
          position: absolute;
          top: 16px;
          right: 20px;
          background: none;
          border: none;
          color: #64748B;
          font-size: 1.8rem;
          line-height: 1;
          cursor: pointer;
          transition: color 0.2s;
        }

        .doorstep-close-btn:hover {
          color: var(--magenta);
        }

        .doorstep-content-view,
        .doorstep-success-view {
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
        }

        .doorstep-top-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          background: var(--magenta-light);
          border: 1px solid var(--magenta-border);
          color: var(--magenta);
          font-size: 0.72rem;
          font-weight: 800;
          padding: 3px 10px;
          border-radius: 20px;
          margin-bottom: 16px;
          letter-spacing: 0.05em;
        }

        .badge-pulsing-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: var(--magenta);
        }

        .doorstep-icon-circle {
          width: 64px;
          height: 64px;
          border-radius: 50%;
          background: var(--magenta-light);
          border: 1.5px solid var(--magenta-border);
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 16px;
        }

        .doorstep-title {
          font-size: 1.45rem;
          font-weight: 900;
          color: #0F172A;
          margin-bottom: 6px;
        }

        .doorstep-sub {
          font-size: 1rem;
          font-weight: 700;
          color: var(--magenta);
          margin-bottom: 12px;
        }

        .doorstep-detail {
          font-size: 0.88rem;
          color: #64748B;
          line-height: 1.55;
          margin-bottom: 22px;
          max-width: 400px;
        }

        .doorstep-form {
          width: 100%;
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .doorstep-input {
          width: 100%;
          padding: 12px 16px;
          border-radius: 10px;
          border: 1px solid #CBD5E1;
          background: #F8FAFC;
          color: #0F172A;
          font-size: 0.92rem;
          outline: none;
          transition: border-color 0.2s;
        }

        .doorstep-input:focus {
          border-color: var(--magenta);
          background: #FFFFFF;
        }

        .notify-btn {
          padding: 13px;
          font-size: 0.95rem;
          font-weight: 800;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
        }

        .success-icon-wrap {
          width: 68px;
          height: 68px;
          border-radius: 50%;
          background: #ECFDF5;
          border: 2px solid #10B981;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 16px;
        }

        .doorstep-success-view h3 {
          font-size: 1.35rem;
          font-weight: 900;
          color: #0F172A;
          margin-bottom: 8px;
        }

        .doorstep-success-view p {
          font-size: 0.9rem;
          color: #64748B;
          line-height: 1.5;
          margin-bottom: 16px;
        }

        .early-perk-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          background: #FFF0F6;
          color: var(--magenta);
          border: 1px solid var(--magenta-border);
          padding: 6px 14px;
          border-radius: 20px;
          font-size: 0.78rem;
          font-weight: 700;
          margin-bottom: 14px;
        }

        .full-w {
          width: 100%;
        }

        .mt-16 {
          margin-top: 16px;
        }
      `})]}):null}function ht({isOpen:e,onClose:t,onOpenOrderTag:n,onNavigate:r}){let[i,a]=(0,_.useState)(!0),[o,s]=(0,_.useState)(``),[c,l]=(0,_.useState)(!1),[u,d]=(0,_.useState)(``),[f,p]=(0,_.useState)(!0),[m,h]=(0,_.useState)(!0);return e?(0,j.jsxs)(`div`,{className:`account-modal-backdrop`,onClick:t,children:[(0,j.jsxs)(`div`,{className:`account-modal-box glass-card`,onClick:e=>e.stopPropagation(),children:[(0,j.jsx)(`button`,{className:`account-close-btn`,onClick:t,"aria-label":`Close modal`,children:`×`}),i?(0,j.jsxs)(`div`,{className:`account-dashboard-view`,children:[(0,j.jsxs)(`div`,{className:`account-profile-header`,children:[(0,j.jsx)(`div`,{className:`profile-avatar`,children:(0,j.jsx)(De,{size:28,color:`#FF2B85`})}),(0,j.jsxs)(`div`,{className:`profile-info`,children:[(0,j.jsxs)(`div`,{className:`profile-name-row`,children:[(0,j.jsx)(`h4`,{children:`Rahul Badugu`}),(0,j.jsxs)(`span`,{className:`account-verified-badge`,children:[(0,j.jsx)(be,{size:12}),` Verified Owner`]})]}),(0,j.jsx)(`span`,{className:`profile-phone`,children:`+91 98765 43210 • Primary Member`})]})]}),(0,j.jsxs)(`div`,{className:`account-section`,children:[(0,j.jsxs)(`div`,{className:`section-title-row`,children:[(0,j.jsx)(`span`,{className:`section-label`,children:`ACTIVE CARFRND TAGS`}),(0,j.jsx)(`span`,{className:`badge-active`,children:`1 Tag Active`})]}),(0,j.jsxs)(`div`,{className:`vehicle-tag-card`,children:[(0,j.jsxs)(`div`,{className:`v-card-top`,children:[(0,j.jsxs)(`div`,{className:`v-plate-wrap`,children:[(0,j.jsx)(oe,{size:16,color:`#FF2B85`}),(0,j.jsx)(`span`,{className:`v-number`,children:`MH 01 AB 1234`})]}),(0,j.jsxs)(`span`,{className:`v-status-pill`,children:[(0,j.jsx)(`span`,{className:`dot-green`}),` ACTIVE`]})]}),(0,j.jsxs)(`div`,{className:`v-details-grid`,children:[(0,j.jsxs)(`div`,{className:`detail-item`,children:[(0,j.jsx)(`span`,{className:`detail-lbl`,children:`Tag ID`}),(0,j.jsx)(`span`,{className:`detail-val`,children:`KA560100MM1234`})]}),(0,j.jsxs)(`div`,{className:`detail-item`,children:[(0,j.jsx)(`span`,{className:`detail-lbl`,children:`Privacy Mode`}),(0,j.jsx)(`span`,{className:`detail-val highlight`,children:`Masked Voice Calls`})]})]}),(0,j.jsxs)(`div`,{className:`tag-controls-list`,children:[(0,j.jsxs)(`div`,{className:`control-row`,children:[(0,j.jsxs)(`div`,{className:`control-meta`,children:[(0,j.jsx)(me,{size:14,color:`#059669`}),(0,j.jsx)(`span`,{children:`Anonymous Masked Call Forwarding`})]}),(0,j.jsxs)(`label`,{className:`toggle-switch`,children:[(0,j.jsx)(`input`,{type:`checkbox`,checked:f,onChange:e=>p(e.target.checked)}),(0,j.jsx)(`span`,{className:`slider`})]})]}),(0,j.jsxs)(`div`,{className:`control-row`,children:[(0,j.jsxs)(`div`,{className:`control-meta`,children:[(0,j.jsx)(Te,{size:14,color:`#D97706`}),(0,j.jsx)(`span`,{children:`Emergency Parking & Towing Alerts`})]}),(0,j.jsxs)(`label`,{className:`toggle-switch`,children:[(0,j.jsx)(`input`,{type:`checkbox`,checked:m,onChange:e=>h(e.target.checked)}),(0,j.jsx)(`span`,{className:`slider`})]})]})]})]})]}),(0,j.jsxs)(`div`,{className:`account-section`,children:[(0,j.jsx)(`div`,{className:`section-title-row`,children:(0,j.jsx)(`span`,{className:`section-label`,children:`ORDERS & BOOKINGS`})}),(0,j.jsxs)(`div`,{className:`order-summary-card`,style:{flexDirection:`column`,alignItems:`stretch`,gap:`10px`},children:[(0,j.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`12px`},children:[(0,j.jsx)(`div`,{className:`order-s-icon`,children:(0,j.jsx)(we,{size:18,color:`#FF2B85`})}),(0,j.jsxs)(`div`,{className:`order-s-info`,children:[(0,j.jsx)(`span`,{className:`order-s-title`,children:`CarFrnd Tag (Weatherproof Decal)`}),(0,j.jsx)(`span`,{className:`order-s-sub`,children:`Order #CF-842918 • Dispatched (3–5 days)`})]}),(0,j.jsx)(`span`,{className:`order-status-chip`,children:`In Transit`})]}),(0,j.jsxs)(`div`,{style:{display:`flex`,gap:`8px`,borderTop:`1px solid #E2E8F0`,paddingTop:`8px`},children:[(0,j.jsx)(`button`,{className:`btn-secondary`,style:{flex:1,padding:`6px`,fontSize:`0.75rem`},onClick:()=>{t(),r&&r(`track-order`,`CF-842918`)},children:`Track Order`}),(0,j.jsx)(`button`,{className:`btn-secondary`,style:{flex:1,padding:`6px`,fontSize:`0.75rem`},onClick:()=>{t(),r&&r(`bill`,`CF-842918`)},children:`View Bill`})]})]})]}),(0,j.jsxs)(`div`,{className:`account-modal-footer`,children:[(0,j.jsx)(`button`,{className:`btn-secondary btn-order-more`,onClick:()=>{t(),r&&r(`activate-tag`)},children:`+ Activate Tag`}),(0,j.jsx)(`button`,{className:`btn-secondary btn-order-more`,onClick:()=>{t(),n&&n()},children:`+ Order Tag (₹450)`}),(0,j.jsxs)(`button`,{className:`btn-logout`,onClick:()=>a(!1),title:`Sign Out`,children:[(0,j.jsx)(de,{size:15}),` Sign Out`]})]})]}):(0,j.jsxs)(`div`,{className:`account-login-view`,children:[(0,j.jsx)(`div`,{className:`login-avatar-circle`,children:(0,j.jsx)(De,{size:32,color:`#FF2B85`})}),(0,j.jsx)(`h3`,{className:`login-title`,children:`CarFrnd Owner Login`}),(0,j.jsx)(`p`,{className:`login-desc`,children:`Manage your registered CarFrnd Tags, emergency contact alerts, and doorstep auto services.`}),(0,j.jsxs)(`form`,{onSubmit:e=>{e.preventDefault(),c?(a(!0),ct({particleCount:60,spread:60,origin:{y:.6}})):o.length>=10&&l(!0)},className:`login-form`,children:[(0,j.jsxs)(`div`,{className:`form-group`,style:{width:`100%`},children:[(0,j.jsx)(`label`,{className:`input-label`,children:`Mobile Number`}),(0,j.jsxs)(`div`,{className:`phone-input-wrap`,children:[(0,j.jsx)(`span`,{className:`phone-prefix`,children:`+91`}),(0,j.jsx)(`input`,{type:`tel`,placeholder:`Enter 10-digit number`,value:o,onChange:e=>s(e.target.value),required:!0,className:`account-input`})]})]}),c&&(0,j.jsxs)(`div`,{className:`form-group`,style:{width:`100%`},children:[(0,j.jsx)(`label`,{className:`input-label`,children:`Enter 4-Digit OTP (Code: 1234)`}),(0,j.jsx)(`input`,{type:`text`,placeholder:`e.g. 1234`,value:u,onChange:e=>d(e.target.value),required:!0,className:`account-input text-center`,maxLength:4})]}),(0,j.jsx)(`button`,{type:`submit`,className:`btn-primary full-w`,children:c?`Verify OTP & Enter`:`Get Verification OTP`})]}),(0,j.jsx)(`div`,{className:`demo-shortcut-divider`,children:(0,j.jsx)(`span`,{children:`OR`})}),(0,j.jsxs)(`button`,{type:`button`,className:`btn-secondary full-w demo-access-btn`,onClick:()=>{a(!0),l(!1)},children:[(0,j.jsx)(E,{size:16,color:`#059669`}),(0,j.jsx)(`span`,{children:`Instant Account Access`})]})]})]}),(0,j.jsx)(`style`,{children:`
        .account-modal-backdrop {
          position: fixed;
          inset: 0;
          background: rgba(15, 23, 42, 0.7);
          backdrop-filter: blur(8px);
          -webkit-backdrop-filter: blur(8px);
          z-index: 250;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 16px;
        }

        .account-modal-box {
          width: 100%;
          max-width: 520px;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: var(--radius-xl);
          padding: 30px 26px;
          position: relative;
          box-shadow: 0 25px 60px rgba(15, 23, 42, 0.25);
          animation: modalAppear 0.25s cubic-bezier(0.16, 1, 0.3, 1);
          max-height: 90vh;
          overflow-y: auto;
        }

        .account-close-btn {
          position: absolute;
          top: 16px;
          right: 20px;
          background: none;
          border: none;
          color: #64748B;
          font-size: 1.8rem;
          line-height: 1;
          cursor: pointer;
          transition: color 0.2s;
        }

        .account-close-btn:hover {
          color: var(--magenta);
        }

        /* Profile Header */
        .account-profile-header {
          display: flex;
          align-items: center;
          gap: 14px;
          padding-bottom: 18px;
          border-bottom: 1px solid #F1F5F9;
          margin-bottom: 20px;
        }

        .profile-avatar {
          width: 54px;
          height: 54px;
          border-radius: 50%;
          background: var(--magenta-light);
          border: 1.5px solid var(--magenta-border);
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }

        .profile-info {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }

        .profile-name-row {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .profile-name-row h4 {
          font-size: 1.25rem;
          font-weight: 800;
          color: #0F172A;
          margin: 0;
        }

        .account-verified-badge {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          background: #ECFDF5;
          color: #059669;
          font-size: 0.7rem;
          font-weight: 700;
          padding: 2px 8px;
          border-radius: 12px;
          border: 1px solid #A7F3D0;
        }

        .profile-phone {
          font-size: 0.82rem;
          color: #64748B;
        }

        .account-section {
          margin-bottom: 22px;
        }

        .section-title-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 10px;
        }

        .section-label {
          font-size: 0.72rem;
          font-weight: 800;
          color: var(--magenta);
          letter-spacing: 0.05em;
        }

        .badge-active {
          font-size: 0.7rem;
          font-weight: 700;
          color: #059669;
          background: #ECFDF5;
          padding: 2px 7px;
          border-radius: 4px;
        }

        .vehicle-tag-card {
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 14px;
          padding: 16px;
        }

        .v-card-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 12px;
        }

        .v-plate-wrap {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .v-number {
          font-family: var(--font-heading);
          font-size: 1.1rem;
          font-weight: 900;
          color: #0F172A;
          letter-spacing: 0.05em;
        }

        .v-status-pill {
          display: flex;
          align-items: center;
          gap: 5px;
          font-size: 0.72rem;
          font-weight: 800;
          color: #059669;
        }

        .dot-green {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: #10B981;
        }

        .v-details-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 10px;
          padding: 10px 12px;
          margin-bottom: 12px;
        }

        .detail-item {
          display: flex;
          flex-direction: column;
        }

        .detail-lbl {
          font-size: 0.68rem;
          color: #64748B;
          font-weight: 600;
        }

        .detail-val {
          font-size: 0.82rem;
          font-weight: 700;
          color: #0F172A;
          font-family: monospace;
        }

        .detail-val.highlight {
          font-family: inherit;
          color: var(--magenta);
        }

        .tag-controls-list {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .control-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          font-size: 0.8rem;
          color: #334155;
          font-weight: 600;
        }

        .control-meta {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        /* Toggle switch */
        .toggle-switch {
          position: relative;
          display: inline-block;
          width: 36px;
          height: 20px;
        }

        .toggle-switch input {
          opacity: 0;
          width: 0;
          height: 0;
        }

        .slider {
          position: absolute;
          cursor: pointer;
          inset: 0;
          background-color: #CBD5E1;
          transition: 0.3s;
          border-radius: 20px;
        }

        .slider:before {
          position: absolute;
          content: "";
          height: 14px;
          width: 14px;
          left: 3px;
          bottom: 3px;
          background-color: white;
          transition: 0.3s;
          border-radius: 50%;
        }

        input:checked + .slider {
          background-color: #10B981;
        }

        input:checked + .slider:before {
          transform: translateX(16px);
        }

        /* Order card */
        .order-summary-card {
          display: flex;
          align-items: center;
          gap: 12px;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 12px;
          padding: 12px 14px;
        }

        .order-s-icon {
          width: 38px;
          height: 38px;
          border-radius: 8px;
          background: var(--magenta-light);
          border: 1px solid var(--magenta-border);
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }

        .order-s-info {
          display: flex;
          flex-direction: column;
          flex: 1;
        }

        .order-s-title {
          font-size: 0.85rem;
          font-weight: 800;
          color: #0F172A;
        }

        .order-s-sub {
          font-size: 0.74rem;
          color: #64748B;
        }

        .order-status-chip {
          font-size: 0.72rem;
          font-weight: 800;
          color: #2563EB;
          background: #EFF6FF;
          border: 1px solid #BFDBFE;
          padding: 3px 8px;
          border-radius: 6px;
        }

        /* Footer */
        .account-modal-footer {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-top: 16px;
          border-top: 1px solid #F1F5F9;
          gap: 10px;
        }

        .btn-order-more {
          font-size: 0.84rem;
          padding: 8px 14px;
          border-radius: 8px;
          flex: 1;
        }

        .btn-logout {
          background: none;
          border: 1px solid #E2E8F0;
          color: #64748B;
          font-size: 0.8rem;
          font-weight: 700;
          padding: 8px 12px;
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 5px;
          transition: all 0.2s;
        }

        .btn-logout:hover {
          color: #EF4444;
          border-color: #FCA5A5;
          background: #FEF2F2;
        }

        /* Login view */
        .account-login-view {
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
        }

        .login-avatar-circle {
          width: 64px;
          height: 64px;
          border-radius: 50%;
          background: var(--magenta-light);
          border: 2px solid var(--magenta);
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 16px;
        }

        .login-title {
          font-size: 1.45rem;
          font-weight: 900;
          color: #0F172A;
          margin-bottom: 6px;
        }

        .login-desc {
          font-size: 0.88rem;
          color: #64748B;
          line-height: 1.5;
          margin-bottom: 20px;
          max-width: 380px;
        }

        .login-form {
          width: 100%;
          display: flex;
          flex-direction: column;
          gap: 14px;
        }

        .input-label {
          font-size: 0.78rem;
          font-weight: 700;
          color: #334155;
          display: block;
          text-align: left;
          margin-bottom: 4px;
        }

        .phone-input-wrap {
          display: flex;
          align-items: center;
          border: 1px solid #CBD5E1;
          border-radius: 10px;
          background: #F8FAFC;
          overflow: hidden;
        }

        .phone-prefix {
          padding: 0 12px;
          font-size: 0.9rem;
          font-weight: 700;
          color: #64748B;
          border-right: 1px solid #CBD5E1;
          background: #F1F5F9;
        }

        .account-input {
          width: 100%;
          padding: 11px 14px;
          border: none;
          background: transparent;
          color: #0F172A;
          font-size: 0.92rem;
          outline: none;
        }

        .phone-input-wrap:focus-within {
          border-color: var(--magenta);
          background: #FFFFFF;
        }

        .demo-shortcut-divider {
          display: flex;
          align-items: center;
          width: 100%;
          margin: 16px 0;
          color: #94A3B8;
          font-size: 0.75rem;
          font-weight: 700;
        }

        .demo-shortcut-divider:before, .demo-shortcut-divider:after {
          content: "";
          flex: 1;
          height: 1px;
          background: #E2E8F0;
        }

        .demo-shortcut-divider span {
          padding: 0 10px;
        }

        .demo-access-btn {
          padding: 10px;
          font-size: 0.88rem;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
        }

        .full-w {
          width: 100%;
        }

        .text-center {
          text-align: center;
        }
      `})]}):null}function gt({activeOrder:e,onNavigate:t}){let n={orderId:`CF-842918`,name:`Rahul Sharma`,phone:`+91 98765 43210`,vehicleNo:`MH 01 AB 1234`,address:`Flat 402, Lotus Heights, Indiranagar, Bengaluru, Karnataka - 560038`,quantity:1,totalPrice:450,date:`08 Sep 2026`,paymentId:`pay_Pz92841920`,hsn:`49119900`},[r,i]=(0,_.useState)(``),[a,o]=(0,_.useState)(e||n),[s,c]=(0,_.useState)(!1),l=e=>{if(e.preventDefault(),!r.trim())return;let t=r.trim().toUpperCase();o(e=>({...e,orderId:t.startsWith(`CF-`)?t:`CF-${t}`,name:e.name||`Verified Customer`}))},u=()=>{window.print()},d=()=>{navigator.clipboard.writeText(window.location.href),c(!0),setTimeout(()=>c(!1),2500)},f=a.quantity||1,p=(381.36*f).toFixed(2),m=(34.32*f).toFixed(2),h=(34.32*f).toFixed(2),g=450*f;return(0,j.jsxs)(`div`,{className:`bill-page-container`,children:[(0,j.jsx)(`div`,{className:`bill-nav-bar no-print`,children:(0,j.jsxs)(`div`,{className:`container bill-nav-inner`,children:[(0,j.jsxs)(`button`,{className:`btn-back`,onClick:()=>t(`home`),children:[(0,j.jsx)(re,{size:18}),(0,j.jsx)(`span`,{children:`Back to Home`})]}),(0,j.jsx)(`div`,{className:`bill-search-box`,children:(0,j.jsxs)(`form`,{onSubmit:l,className:`bill-search-form`,children:[(0,j.jsx)(ye,{size:15,color:`#94A3B8`}),(0,j.jsx)(`input`,{type:`text`,placeholder:`Find invoice by Order ID (e.g. CF-842918)`,value:r,onChange:e=>i(e.target.value)}),(0,j.jsx)(`button`,{type:`submit`,className:`btn-lookup`,children:`Find`})]})}),(0,j.jsxs)(`div`,{className:`bill-actions-group`,children:[(0,j.jsx)(`button`,{className:`btn-secondary btn-action-sm`,onClick:d,children:s?`Link Copied!`:`Share`}),(0,j.jsxs)(`button`,{className:`btn-primary btn-action-sm`,onClick:u,children:[(0,j.jsx)(ge,{size:16}),(0,j.jsx)(`span`,{children:`Print / Download PDF`})]})]})]})}),(0,j.jsxs)(`div`,{className:`container invoice-sheet-wrapper`,children:[(0,j.jsxs)(`div`,{className:`invoice-paper glass-card`,children:[(0,j.jsxs)(`div`,{className:`invoice-top-header`,children:[(0,j.jsxs)(`div`,{className:`invoice-seller-info`,children:[(0,j.jsx)(`div`,{className:`invoice-brand-row`,children:(0,j.jsx)(`img`,{src:`/carfrndlogo.png`,alt:`CarFrnd Logo`,className:`invoice-logo`})}),(0,j.jsx)(`h3`,{className:`seller-name`,children:`Aramel Tech Private Limited`}),(0,j.jsxs)(`p`,{className:`seller-meta`,children:[`CIN: U72900KA2026PTC184201`,(0,j.jsx)(`br`,{}),`GSTIN: `,(0,j.jsx)(`strong`,{children:`29AABCA1234F1Z5`}),` (Karnataka - 29)`,(0,j.jsx)(`br`,{}),`Registered Office: Sector 4, HSR Layout, Bengaluru, Karnataka - 560102`,(0,j.jsx)(`br`,{}),`Email: support@carfrnd.com • Web: www.carfrnd.com`]})]}),(0,j.jsxs)(`div`,{className:`invoice-meta-badge`,children:[(0,j.jsx)(`div`,{className:`invoice-title-pill`,children:`TAX INVOICE`}),(0,j.jsxs)(`div`,{className:`inv-meta-grid`,children:[(0,j.jsxs)(`div`,{className:`inv-meta-row`,children:[(0,j.jsx)(`span`,{className:`lbl`,children:`Invoice No:`}),(0,j.jsxs)(`span`,{className:`val`,children:[`INV-2026-`,(a.orderId||`CF-842918`).replace(`CF-`,``)]})]}),(0,j.jsxs)(`div`,{className:`inv-meta-row`,children:[(0,j.jsx)(`span`,{className:`lbl`,children:`Invoice Date:`}),(0,j.jsx)(`span`,{className:`val`,children:a.date||`08 Sep 2026`})]}),(0,j.jsxs)(`div`,{className:`inv-meta-row`,children:[(0,j.jsx)(`span`,{className:`lbl`,children:`Order ID:`}),(0,j.jsx)(`span`,{className:`val highlight`,children:a.orderId||`CF-842918`})]}),(0,j.jsxs)(`div`,{className:`inv-meta-row`,children:[(0,j.jsx)(`span`,{className:`lbl`,children:`Payment Status:`}),(0,j.jsx)(`span`,{className:`val status-paid`,children:`PAID (UPI Online)`})]})]})]})]}),(0,j.jsx)(`div`,{className:`invoice-divider`}),(0,j.jsxs)(`div`,{className:`bill-to-section`,children:[(0,j.jsxs)(`div`,{className:`bill-col`,children:[(0,j.jsx)(`span`,{className:`sec-label`,children:`BILLED & SHIPPED TO:`}),(0,j.jsx)(`h4`,{className:`customer-name`,children:a.name||`Rahul Sharma`}),(0,j.jsxs)(`p`,{className:`customer-details`,children:[a.address||`Indiranagar, Bengaluru, Karnataka - 560038`,(0,j.jsx)(`br`,{}),`Mobile: `,(0,j.jsx)(`strong`,{children:a.phone||`+91 98765 43210`}),(0,j.jsx)(`br`,{}),`Place of Supply: Karnataka (29)`]})]}),(0,j.jsxs)(`div`,{className:`bill-col vehicle-col`,children:[(0,j.jsx)(`span`,{className:`sec-label`,children:`REGISTERED VEHICLE DETAILS:`}),(0,j.jsxs)(`div`,{className:`vehicle-badge-large`,children:[(0,j.jsx)(`span`,{className:`v-lbl`,children:`VEHICLE NO:`}),(0,j.jsx)(`span`,{className:`v-val`,children:(a.vehicleNo||`MH 01 AB 1234`).toUpperCase()})]}),(0,j.jsx)(`p`,{className:`vehicle-note`,children:`Encrypted NFC & Weatherproof QR Decal programmed for this vehicle number.`})]})]}),(0,j.jsx)(`div`,{className:`invoice-table-wrapper`,children:(0,j.jsxs)(`table`,{className:`invoice-table`,children:[(0,j.jsx)(`thead`,{children:(0,j.jsxs)(`tr`,{children:[(0,j.jsx)(`th`,{children:`#`}),(0,j.jsx)(`th`,{children:`Description of Goods / Services`}),(0,j.jsx)(`th`,{className:`text-center`,children:`HSN/SAC`}),(0,j.jsx)(`th`,{className:`text-center`,children:`Qty`}),(0,j.jsx)(`th`,{className:`text-right`,children:`Unit Rate (Excl. GST)`}),(0,j.jsx)(`th`,{className:`text-right`,children:`CGST (9%)`}),(0,j.jsx)(`th`,{className:`text-right`,children:`SGST (9%)`}),(0,j.jsx)(`th`,{className:`text-right`,children:`Total Amount`})]})}),(0,j.jsxs)(`tbody`,{children:[(0,j.jsxs)(`tr`,{children:[(0,j.jsx)(`td`,{children:`1`}),(0,j.jsxs)(`td`,{children:[(0,j.jsx)(`strong`,{children:`CarFrnd Smart Contact Tag`}),(0,j.jsx)(`div`,{className:`item-sub`,children:`Weatherproof Automotive Decal • Sun & Wash Resistant • Masked Call Protection`})]}),(0,j.jsx)(`td`,{className:`text-center`,children:`49119900`}),(0,j.jsx)(`td`,{className:`text-center`,children:f}),(0,j.jsx)(`td`,{className:`text-right`,children:`₹381.36`}),(0,j.jsxs)(`td`,{className:`text-right`,children:[`₹`,m]}),(0,j.jsxs)(`td`,{className:`text-right`,children:[`₹`,h]}),(0,j.jsxs)(`td`,{className:`text-right font-bold`,children:[`₹`,g,`.00`]})]}),(0,j.jsxs)(`tr`,{className:`shipping-row`,children:[(0,j.jsx)(`td`,{children:`2`}),(0,j.jsxs)(`td`,{children:[(0,j.jsx)(`strong`,{children:`Doorstep Delivery & Insured Courier`}),(0,j.jsx)(`div`,{className:`item-sub`,children:`Doorstep Delivery within 3–5 business days`})]}),(0,j.jsx)(`td`,{className:`text-center`,children:`996812`}),(0,j.jsx)(`td`,{className:`text-center`,children:`1`}),(0,j.jsx)(`td`,{className:`text-right`,children:`₹0.00`}),(0,j.jsx)(`td`,{className:`text-right`,children:`₹0.00`}),(0,j.jsx)(`td`,{className:`text-right`,children:`₹0.00`}),(0,j.jsx)(`td`,{className:`text-right font-bold text-green`,children:`FREE`})]})]})]})}),(0,j.jsxs)(`div`,{className:`invoice-totals-grid`,children:[(0,j.jsxs)(`div`,{className:`totals-left-col`,children:[(0,j.jsxs)(`div`,{className:`amount-in-words`,children:[(0,j.jsx)(`span`,{className:`words-lbl`,children:`Amount in Words:`}),(0,j.jsx)(`span`,{className:`words-val`,children:f===1?`Indian Rupees Four Hundred Fifty Only`:`Indian Rupees ${g} Only`})]}),(0,j.jsxs)(`div`,{className:`invoice-tax-summary-card`,children:[(0,j.jsx)(`span`,{className:`tax-head`,children:`GST Tax Summary`}),(0,j.jsxs)(`div`,{className:`tax-row`,children:[(0,j.jsx)(`span`,{children:`Taxable Base Value:`}),(0,j.jsxs)(`span`,{children:[`₹`,p]})]}),(0,j.jsxs)(`div`,{className:`tax-row`,children:[(0,j.jsx)(`span`,{children:`Central GST (CGST @ 9%):`}),(0,j.jsxs)(`span`,{children:[`₹`,m]})]}),(0,j.jsxs)(`div`,{className:`tax-row`,children:[(0,j.jsx)(`span`,{children:`State GST (SGST @ 9%):`}),(0,j.jsxs)(`span`,{children:[`₹`,h]})]}),(0,j.jsxs)(`div`,{className:`tax-row total-tax-row`,children:[(0,j.jsx)(`span`,{children:`Total Tax Included:`}),(0,j.jsxs)(`span`,{children:[`₹`,(parseFloat(m)+parseFloat(h)).toFixed(2)]})]})]})]}),(0,j.jsxs)(`div`,{className:`totals-right-col`,children:[(0,j.jsxs)(`div`,{className:`calc-row`,children:[(0,j.jsx)(`span`,{children:`Subtotal (Net):`}),(0,j.jsxs)(`span`,{children:[`₹`,p]})]}),(0,j.jsxs)(`div`,{className:`calc-row`,children:[(0,j.jsx)(`span`,{children:`Total Tax (18% GST):`}),(0,j.jsxs)(`span`,{children:[`₹`,(parseFloat(m)+parseFloat(h)).toFixed(2)]})]}),(0,j.jsxs)(`div`,{className:`calc-row`,children:[(0,j.jsx)(`span`,{children:`Shipping & Doorstep Delivery:`}),(0,j.jsx)(`span`,{className:`text-green`,children:`₹0.00 (FREE)`})]}),(0,j.jsxs)(`div`,{className:`calc-row grand-total-row`,children:[(0,j.jsx)(`span`,{children:`Grand Total (Incl. GST):`}),(0,j.jsxs)(`span`,{className:`grand-val`,children:[`₹`,g,`.00`]})]}),(0,j.jsxs)(`div`,{className:`payment-stamp-box`,children:[(0,j.jsx)(E,{size:24,color:`#059669`}),(0,j.jsxs)(`div`,{className:`stamp-details`,children:[(0,j.jsx)(`span`,{className:`stamp-title`,children:`Payment Confirmed`}),(0,j.jsxs)(`span`,{className:`stamp-sub`,children:[`Trans ID: `,a.paymentId||`pay_Pz92841920`]})]})]})]})]}),(0,j.jsxs)(`div`,{className:`invoice-footer-grid`,children:[(0,j.jsxs)(`div`,{className:`terms-col`,children:[(0,j.jsx)(`span`,{className:`terms-title`,children:`Terms & Conditions:`}),(0,j.jsxs)(`ol`,{className:`terms-list`,children:[(0,j.jsx)(`li`,{children:`This is a computer-generated tax invoice issued by Aramel Tech Private Limited.`}),(0,j.jsx)(`li`,{children:`Your CarFrnd Tag includes lifetime QR scanning and masked voice forwarding without monthly subscriptions.`}),(0,j.jsx)(`li`,{children:`Delivery is scheduled within 3–5 business days via tracked express courier.`}),(0,j.jsx)(`li`,{children:`For support or queries, reach us at support@carfrnd.com.`})]})]}),(0,j.jsxs)(`div`,{className:`signature-col`,children:[(0,j.jsxs)(`div`,{className:`qr-verification-block`,children:[(0,j.jsx)(it,{value:`https://carfrnd.com/bill?order=${a.orderId||`CF-842918`}`,size:64,level:`M`}),(0,j.jsx)(`span`,{className:`qr-caption`,children:`Verify Invoice`})]}),(0,j.jsxs)(`div`,{className:`signature-box`,children:[(0,j.jsx)(`div`,{className:`signature-img-placeholder`,children:`Aramel Tech Pvt Ltd`}),(0,j.jsx)(`span`,{className:`signatory-label`,children:`Authorised Signatory`})]})]})]})]}),(0,j.jsxs)(`div`,{className:`invoice-quick-cta-row no-print`,children:[(0,j.jsxs)(`button`,{className:`btn-secondary`,onClick:()=>t(`track-order`,a.orderId),children:[(0,j.jsx)(Ee,{size:16}),` Track This Order`]}),(0,j.jsxs)(`button`,{className:`btn-primary`,onClick:()=>t(`activate-tag`),children:[(0,j.jsx)(we,{size:16}),` Activate CarFrnd Tag`]})]})]}),(0,j.jsx)(`style`,{children:`
        .bill-page-container {
          min-height: 100vh;
          background: #F8FAFC;
          padding-top: 86px;
          padding-bottom: 60px;
        }

        .bill-nav-bar {
          position: sticky;
          top: 68px;
          z-index: 40;
          background: rgba(255, 255, 255, 0.96);
          backdrop-filter: blur(12px);
          border-bottom: 1px solid #E2E8F0;
          padding: 12px 0;
          margin-bottom: 24px;
        }

        .bill-nav-inner {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          flex-wrap: wrap;
        }

        .btn-back {
          background: none;
          border: 1px solid #CBD5E1;
          padding: 8px 14px;
          border-radius: 10px;
          font-weight: 700;
          font-size: 0.88rem;
          color: #334155;
          display: flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          transition: all 0.2s;
        }

        .btn-back:hover {
          background: #F1F5F9;
          color: #0F172A;
        }

        .bill-search-form {
          display: flex;
          align-items: center;
          gap: 8px;
          background: #F1F5F9;
          border: 1px solid #CBD5E1;
          border-radius: 10px;
          padding: 6px 12px;
          width: 320px;
        }

        .bill-search-form input {
          border: none;
          background: transparent;
          font-size: 0.84rem;
          width: 100%;
          outline: none;
          color: #0F172A;
        }

        .btn-lookup {
          background: var(--magenta);
          color: #FFFFFF;
          border: none;
          padding: 4px 10px;
          border-radius: 6px;
          font-size: 0.76rem;
          font-weight: 700;
          cursor: pointer;
        }

        .bill-actions-group {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .btn-action-sm {
          padding: 8px 16px;
          font-size: 0.85rem;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        /* Printable Invoice Paper */
        .invoice-sheet-wrapper {
          max-width: 900px;
          margin: 0 auto;
        }

        .invoice-paper {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 18px;
          padding: 44px;
          box-shadow: 0 10px 30px rgba(15, 23, 42, 0.05);
        }

        .invoice-top-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 30px;
        }

        .invoice-logo {
          height: 48px;
          width: auto;
          object-fit: contain;
          margin-bottom: 12px;
          transform: scale(1.6);
          transform-origin: left center;
        }

        .seller-name {
          font-size: 1.15rem;
          font-weight: 900;
          color: #0F172A;
          margin-bottom: 4px;
        }

        .seller-meta {
          font-size: 0.78rem;
          color: #64748B;
          line-height: 1.5;
        }

        .invoice-meta-badge {
          text-align: right;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 12px;
          padding: 16px 20px;
          min-width: 260px;
        }

        .invoice-title-pill {
          display: inline-block;
          background: var(--magenta);
          color: #FFFFFF;
          font-size: 0.75rem;
          font-weight: 900;
          letter-spacing: 0.06em;
          padding: 4px 12px;
          border-radius: 6px;
          margin-bottom: 10px;
        }

        .inv-meta-grid {
          display: flex;
          flex-direction: column;
          gap: 5px;
        }

        .inv-meta-row {
          display: flex;
          justify-content: space-between;
          font-size: 0.8rem;
          gap: 12px;
        }

        .inv-meta-row .lbl {
          color: #64748B;
          font-weight: 600;
        }

        .inv-meta-row .val {
          font-weight: 700;
          color: #0F172A;
        }

        .inv-meta-row .val.highlight {
          color: var(--magenta);
          font-family: monospace;
          font-size: 0.85rem;
        }

        .inv-meta-row .val.status-paid {
          color: #059669;
          background: #ECFDF5;
          padding: 1px 6px;
          border-radius: 4px;
          font-size: 0.74rem;
        }

        .invoice-divider {
          height: 1px;
          background: #E2E8F0;
          margin: 24px 0;
        }

        .bill-to-section {
          display: grid;
          grid-template-columns: 1.2fr 1fr;
          gap: 30px;
          margin-bottom: 24px;
        }

        .sec-label {
          font-size: 0.72rem;
          font-weight: 800;
          color: var(--magenta);
          letter-spacing: 0.05em;
          display: block;
          margin-bottom: 6px;
        }

        .customer-name {
          font-size: 1.1rem;
          font-weight: 800;
          color: #0F172A;
          margin-bottom: 4px;
        }

        .customer-details {
          font-size: 0.82rem;
          color: #475569;
          line-height: 1.5;
        }

        .vehicle-badge-large {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: #0F172A;
          color: #FFFFFF;
          padding: 8px 14px;
          border-radius: 8px;
          border-left: 4px solid var(--magenta);
          margin-bottom: 6px;
        }

        .v-lbl {
          font-size: 0.68rem;
          color: #94A3B8;
          font-weight: 700;
        }

        .v-val {
          font-family: var(--font-heading);
          font-size: 1.05rem;
          font-weight: 900;
          letter-spacing: 0.06em;
        }

        .vehicle-note {
          font-size: 0.76rem;
          color: #64748B;
          line-height: 1.4;
        }

        /* Invoice Table */
        .invoice-table-wrapper {
          overflow-x: auto;
          margin-bottom: 24px;
          border: 1px solid #E2E8F0;
          border-radius: 12px;
        }

        .invoice-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 0.84rem;
        }

        .invoice-table th {
          background: #F8FAFC;
          color: #334155;
          font-weight: 800;
          padding: 12px 14px;
          border-bottom: 1px solid #E2E8F0;
          text-align: left;
        }

        .invoice-table td {
          padding: 14px;
          border-bottom: 1px solid #F1F5F9;
          color: #1E293B;
        }

        .item-sub {
          font-size: 0.74rem;
          color: #64748B;
          margin-top: 3px;
        }

        .text-center {
          text-align: center;
        }

        .text-right {
          text-align: right;
        }

        .font-bold {
          font-weight: 800;
        }

        .text-green {
          color: #059669;
        }

        /* Totals Grid */
        .invoice-totals-grid {
          display: grid;
          grid-template-columns: 1.2fr 1fr;
          gap: 30px;
          padding-bottom: 24px;
          border-bottom: 1px solid #E2E8F0;
        }

        .amount-in-words {
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 10px;
          padding: 12px 16px;
          margin-bottom: 16px;
        }

        .words-lbl {
          font-size: 0.7rem;
          font-weight: 700;
          color: #64748B;
          display: block;
        }

        .words-val {
          font-size: 0.84rem;
          font-weight: 800;
          color: #0F172A;
        }

        .invoice-tax-summary-card {
          background: #FFF0F6;
          border: 1px solid var(--magenta-border);
          border-radius: 10px;
          padding: 12px 16px;
        }

        .tax-head {
          font-size: 0.74rem;
          font-weight: 800;
          color: var(--magenta);
          display: block;
          margin-bottom: 6px;
        }

        .tax-row {
          display: flex;
          justify-content: space-between;
          font-size: 0.78rem;
          color: #475569;
          padding: 3px 0;
        }

        .total-tax-row {
          border-top: 1px dashed var(--magenta-border);
          margin-top: 4px;
          padding-top: 4px;
          font-weight: 800;
          color: #0F172A;
        }

        .totals-right-col {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .calc-row {
          display: flex;
          justify-content: space-between;
          font-size: 0.84rem;
          color: #475569;
        }

        .grand-total-row {
          border-top: 2px solid #0F172A;
          margin-top: 6px;
          padding-top: 8px;
          font-size: 1.05rem;
          font-weight: 900;
          color: #0F172A;
        }

        .grand-val {
          color: var(--magenta);
          font-family: var(--font-heading);
          font-size: 1.3rem;
        }

        .payment-stamp-box {
          display: flex;
          align-items: center;
          gap: 10px;
          background: #ECFDF5;
          border: 1px solid #A7F3D0;
          border-radius: 10px;
          padding: 10px 14px;
          margin-top: 12px;
        }

        .stamp-title {
          font-size: 0.8rem;
          font-weight: 800;
          color: #065F46;
          display: block;
        }

        .stamp-sub {
          font-size: 0.7rem;
          color: #047857;
          font-family: monospace;
        }

        /* Footer Grid */
        .invoice-footer-grid {
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
          gap: 30px;
          margin-top: 24px;
        }

        .terms-title {
          font-size: 0.72rem;
          font-weight: 800;
          color: #64748B;
          display: block;
          margin-bottom: 4px;
        }

        .terms-list {
          font-size: 0.7rem;
          color: #64748B;
          padding-left: 14px;
          line-height: 1.5;
          max-width: 480px;
        }

        .signature-col {
          display: flex;
          align-items: center;
          gap: 20px;
          text-align: center;
        }

        .qr-verification-block {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
        }

        .qr-caption {
          font-size: 0.62rem;
          color: #64748B;
          font-weight: 700;
        }

        .signature-box {
          display: flex;
          flex-direction: column;
          align-items: center;
        }

        .signature-img-placeholder {
          font-family: 'Brush Script MT', cursive, sans-serif;
          font-size: 1.4rem;
          color: #0F172A;
          border-bottom: 1px solid #0F172A;
          padding: 0 16px 4px 16px;
          margin-bottom: 4px;
        }

        .signatory-label {
          font-size: 0.68rem;
          font-weight: 800;
          color: #64748B;
        }

        .invoice-quick-cta-row {
          display: flex;
          justify-content: center;
          gap: 14px;
          margin-top: 24px;
        }

        /* Print Media Styles */
        @media print {
          .no-print, .navbar-header, .footer-section, .mobile-bottom-nav {
            display: none !important;
          }
          .bill-page-container {
            padding: 0 !important;
            background: #FFFFFF !important;
          }
          .invoice-paper {
            border: none !important;
            box-shadow: none !important;
            padding: 0 !important;
          }
          body {
            background: #FFFFFF !important;
          }
        }

        @media (max-width: 768px) {
          .invoice-paper {
            padding: 24px 18px;
          }
          .invoice-top-header {
            flex-direction: column;
          }
          .invoice-meta-badge {
            width: 100%;
            text-align: left;
          }
          .bill-to-section {
            grid-template-columns: 1fr;
            gap: 18px;
          }
          .invoice-totals-grid {
            grid-template-columns: 1fr;
          }
          .invoice-footer-grid {
            flex-direction: column;
            align-items: flex-start;
          }
          .bill-search-form {
            width: 100%;
          }
          .bill-actions-group {
            width: 100%;
            justify-content: space-between;
          }
        }
      `})]})}function _t({initialOrderId:e,onNavigate:t}){let[n,r]=(0,_.useState)(e||`CF-842918`),[i,a]=(0,_.useState)(e||`CF-842918`),o=e=>{if(e.preventDefault(),!n.trim())return;let t=n.trim().toUpperCase();a(t.startsWith(`CF-`)?t:`CF-${t}`)},s=[{id:1,title:`Order Confirmed`,desc:`Payment of ₹450 received. Order registered in the Aramel CarFrnd network.`,timestamp:`08 Sep 2026, 09:15 AM`,completed:!0,current:!1},{id:2,title:`Decal Printed & Encoded`,desc:`Weatherproof automotive decal manufactured with encrypted QR & NFC for vehicle MH 01 AB 1234.`,timestamp:`08 Sep 2026, 02:40 PM`,completed:!0,current:!1},{id:3,title:`Dispatched via Express Courier`,desc:`Handed over to BlueDart Air Logistics Hub, Bengaluru. In transit to destination city.`,timestamp:`08 Sep 2026, 06:10 PM`,completed:!0,current:!0},{id:4,title:`Out for Delivery`,desc:`Courier executive will contact you for doorstep delivery.`,timestamp:`Expected in 2 business days`,completed:!1,current:!1},{id:5,title:`Delivered to Doorstep`,desc:`Package handed over. Follow quick instructions to stick decal on windshield.`,timestamp:`Within 3–5 Business Days`,completed:!1,current:!1}];return(0,j.jsxs)(`div`,{className:`track-page-container`,children:[(0,j.jsx)(`div`,{className:`track-nav-bar`,children:(0,j.jsxs)(`div`,{className:`container track-nav-inner`,children:[(0,j.jsxs)(`button`,{className:`btn-back`,onClick:()=>t(`home`),children:[(0,j.jsx)(re,{size:18}),(0,j.jsx)(`span`,{children:`Back to Home`})]}),(0,j.jsxs)(`div`,{className:`track-title-badge`,children:[(0,j.jsx)(Ee,{size:16,color:`#FF2B85`}),(0,j.jsx)(`span`,{children:`Live Order Tracking`})]})]})}),(0,j.jsxs)(`div`,{className:`container track-main-content`,children:[(0,j.jsxs)(`div`,{className:`track-search-card glass-card`,children:[(0,j.jsxs)(`div`,{className:`search-copy`,children:[(0,j.jsx)(`h2`,{children:`Track Your CarFrnd Tag Order`}),(0,j.jsxs)(`p`,{children:[`Enter your 6-digit Order ID (e.g. `,(0,j.jsx)(`code`,{children:`CF-842918`}),`) or 10-digit registered mobile number.`]})]}),(0,j.jsxs)(`form`,{onSubmit:o,className:`track-input-form`,children:[(0,j.jsxs)(`div`,{className:`input-group-track`,children:[(0,j.jsx)(ye,{size:18,color:`#94A3B8`}),(0,j.jsx)(`input`,{type:`text`,placeholder:`Enter Order ID (e.g. CF-842918)`,value:n,onChange:e=>r(e.target.value)})]}),(0,j.jsx)(`button`,{type:`submit`,className:`btn-primary btn-track-submit`,children:`Track Status`})]})]}),(0,j.jsxs)(`div`,{className:`status-hero-card glass-card`,children:[(0,j.jsxs)(`div`,{className:`status-hero-left`,children:[(0,j.jsxs)(`div`,{className:`status-badge-live`,children:[(0,j.jsx)(`span`,{className:`live-dot`}),(0,j.jsx)(`span`,{children:`IN TRANSIT — DISPATCHED`})]}),(0,j.jsxs)(`h3`,{className:`status-heading`,children:[`Order #`,i]}),(0,j.jsxs)(`p`,{className:`status-sub`,children:[`Your CarFrnd Tag is on the way! Doorstep delivery is guaranteed within `,(0,j.jsx)(`strong`,{children:`3–5 business days`}),`.`]})]}),(0,j.jsx)(`div`,{className:`status-hero-right`,children:(0,j.jsxs)(`div`,{className:`delivery-est-box`,children:[(0,j.jsx)(`span`,{className:`est-label`,children:`Estimated Delivery`}),(0,j.jsx)(`span`,{className:`est-date`,children:`Within 3–5 Business Days`}),(0,j.jsxs)(`span`,{className:`est-courier`,children:[`Carrier: `,(0,j.jsx)(`strong`,{children:`BlueDart Express Air`}),` (AWB: BD`,i.replace(`CF-`,``),`IN)`]})]})})]}),(0,j.jsxs)(`div`,{className:`track-details-grid`,children:[(0,j.jsxs)(`div`,{className:`stepper-col glass-card`,children:[(0,j.jsx)(`h4`,{className:`col-heading`,children:`Shipment Timeline`}),(0,j.jsx)(`div`,{className:`vertical-timeline`,children:s.map((e,t)=>(0,j.jsxs)(`div`,{className:`timeline-step ${e.completed?`completed`:``} ${e.current?`current`:``}`,children:[(0,j.jsxs)(`div`,{className:`step-marker-col`,children:[(0,j.jsx)(`div`,{className:`step-circle`,children:e.completed?(0,j.jsx)(E,{size:18}):(0,j.jsx)(`span`,{children:t+1})}),t<s.length-1&&(0,j.jsx)(`div`,{className:`step-line`})]}),(0,j.jsxs)(`div`,{className:`step-content-col`,children:[(0,j.jsxs)(`div`,{className:`step-title-row`,children:[(0,j.jsx)(`span`,{className:`step-title`,children:e.title}),e.current&&(0,j.jsx)(`span`,{className:`current-badge`,children:`Active`})]}),(0,j.jsx)(`p`,{className:`step-desc`,children:e.desc}),(0,j.jsx)(`span`,{className:`step-time`,children:e.timestamp})]})]},e.id))})]}),(0,j.jsxs)(`div`,{className:`info-sidebar-col`,children:[(0,j.jsxs)(`div`,{className:`sidebar-card glass-card`,children:[(0,j.jsxs)(`div`,{className:`card-sec-head`,children:[(0,j.jsx)(pe,{size:18,color:`#FF2B85`}),(0,j.jsx)(`span`,{children:`Package Contents`})]}),(0,j.jsxs)(`div`,{className:`package-item-row`,children:[(0,j.jsx)(`div`,{className:`package-icon`,children:(0,j.jsx)(be,{size:24,color:`#FF2B85`})}),(0,j.jsxs)(`div`,{className:`package-meta`,children:[(0,j.jsx)(`h5`,{children:`CarFrnd Smart Contact Tag`}),(0,j.jsx)(`p`,{children:`Weatherproof Automotive Decal`}),(0,j.jsx)(`span`,{className:`vehicle-pill`,children:`Vehicle: MH 01 AB 1234`})]}),(0,j.jsx)(`span`,{className:`pkg-qty`,children:`Qty: 1`})]}),(0,j.jsxs)(`div`,{className:`feature-tags-wrap`,children:[(0,j.jsx)(`span`,{className:`feat-chip`,children:`Sun & Scratch Proof`}),(0,j.jsx)(`span`,{className:`feat-chip`,children:`Masked Calls`}),(0,j.jsx)(`span`,{className:`feat-chip`,children:`Windshield Safe`})]})]}),(0,j.jsxs)(`div`,{className:`sidebar-card glass-card`,children:[(0,j.jsxs)(`div`,{className:`card-sec-head`,children:[(0,j.jsx)(k,{size:18,color:`#FF2B85`}),(0,j.jsx)(`span`,{children:`Delivery Address`})]}),(0,j.jsxs)(`div`,{className:`address-content`,children:[(0,j.jsx)(`strong`,{children:`Rahul Sharma`}),(0,j.jsxs)(`p`,{children:[`Flat 402, Lotus Heights, Indiranagar`,(0,j.jsx)(`br`,{}),`Bengaluru, Karnataka - 560038`]}),(0,j.jsx)(`span`,{className:`phone-num`,children:`Mobile: +91 98765 43210`})]})]}),(0,j.jsxs)(`div`,{className:`sidebar-actions-card glass-card`,children:[(0,j.jsxs)(`button`,{className:`btn-secondary full-w action-btn`,onClick:()=>t(`bill`,i),children:[(0,j.jsx)(ve,{size:16}),(0,j.jsx)(`span`,{children:`Download Bill / Tax Invoice`})]}),(0,j.jsxs)(`button`,{className:`btn-primary full-w action-btn`,onClick:()=>t(`activate-tag`),children:[(0,j.jsx)(we,{size:16}),(0,j.jsx)(`span`,{children:`Activate Tag Once Delivered`})]})]}),(0,j.jsxs)(`div`,{className:`support-help-mini glass-card`,children:[(0,j.jsx)(ce,{size:18,color:`#FF2B85`}),(0,j.jsxs)(`div`,{children:[(0,j.jsx)(`h6`,{children:`Need tracking assistance?`}),(0,j.jsx)(`p`,{children:`Our support team can assist you with your CarFrnd Tag.`}),(0,j.jsx)(`a`,{href:`mailto:support@carfrnd.com`,children:`Email support@carfrnd.com`})]})]})]})]})]}),(0,j.jsx)(`style`,{children:`
        .track-page-container {
          min-height: 100vh;
          background: #F8FAFC;
          padding-top: 86px;
          padding-bottom: 60px;
        }

        .track-nav-bar {
          background: rgba(255, 255, 255, 0.96);
          backdrop-filter: blur(12px);
          border-bottom: 1px solid #E2E8F0;
          padding: 12px 0;
          margin-bottom: 24px;
        }

        .track-nav-inner {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .btn-back {
          background: none;
          border: 1px solid #CBD5E1;
          padding: 8px 14px;
          border-radius: 10px;
          font-weight: 700;
          font-size: 0.88rem;
          color: #334155;
          display: flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          transition: all 0.2s;
        }

        .btn-back:hover {
          background: #F1F5F9;
          color: #0F172A;
        }

        .track-title-badge {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 0.88rem;
          font-weight: 800;
          color: #0F172A;
          background: var(--magenta-light);
          border: 1px solid var(--magenta-border);
          padding: 6px 14px;
          border-radius: 20px;
        }

        .track-main-content {
          max-width: 1020px;
          margin: 0 auto;
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        /* Search Card */
        .track-search-card {
          padding: 24px 28px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 24px;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: var(--radius-xl);
        }

        .search-copy h2 {
          font-size: 1.3rem;
          font-weight: 900;
          color: #0F172A;
          margin-bottom: 4px;
        }

        .search-copy p {
          font-size: 0.84rem;
          color: #64748B;
        }

        .search-copy code {
          background: #F1F5F9;
          padding: 2px 6px;
          border-radius: 4px;
          color: var(--magenta);
          font-weight: 800;
        }

        .track-input-form {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .input-group-track {
          display: flex;
          align-items: center;
          gap: 10px;
          background: #F8FAFC;
          border: 1px solid #CBD5E1;
          border-radius: 10px;
          padding: 8px 14px;
          width: 260px;
        }

        .input-group-track input {
          border: none;
          background: transparent;
          font-size: 0.88rem;
          outline: none;
          width: 100%;
          color: #0F172A;
          font-weight: 600;
        }

        .btn-track-submit {
          padding: 10px 18px;
          font-size: 0.88rem;
          white-space: nowrap;
        }

        /* Hero Status Card */
        .status-hero-card {
          background: linear-gradient(135deg, #0F172A 0%, #1E293B 100%);
          color: #FFFFFF;
          border-radius: var(--radius-xl);
          padding: 28px 32px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 28px;
          border: 1px solid #334155;
          box-shadow: 0 10px 30px rgba(15, 23, 42, 0.15);
        }

        .status-badge-live {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: rgba(16, 185, 129, 0.2);
          border: 1px solid rgba(16, 185, 129, 0.4);
          color: #34D399;
          font-size: 0.72rem;
          font-weight: 900;
          padding: 4px 12px;
          border-radius: 20px;
          margin-bottom: 10px;
        }

        .live-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #10B981;
          box-shadow: 0 0 10px #10B981;
        }

        .status-heading {
          font-size: 1.6rem;
          font-weight: 900;
          color: #FFFFFF;
          margin-bottom: 6px;
        }

        .status-sub {
          font-size: 0.88rem;
          color: #94A3B8;
          max-width: 480px;
          line-height: 1.5;
        }

        .status-sub strong {
          color: #FFFFFF;
        }

        .delivery-est-box {
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(8px);
          padding: 16px 20px;
          border-radius: 14px;
          text-align: right;
          min-width: 260px;
        }

        .est-label {
          font-size: 0.72rem;
          color: #94A3B8;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          display: block;
          margin-bottom: 4px;
        }

        .est-date {
          font-family: var(--font-heading);
          font-size: 1.25rem;
          font-weight: 900;
          color: #FF2B85;
          display: block;
          margin-bottom: 4px;
        }

        .est-courier {
          font-size: 0.75rem;
          color: #CBD5E1;
          display: block;
        }

        /* Timeline Grid */
        .track-details-grid {
          display: grid;
          grid-template-columns: 1.3fr 0.8fr;
          gap: 20px;
        }

        .stepper-col {
          padding: 28px;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: var(--radius-xl);
        }

        .col-heading {
          font-size: 1.15rem;
          font-weight: 900;
          color: #0F172A;
          margin-bottom: 24px;
        }

        /* Vertical Stepper */
        .vertical-timeline {
          display: flex;
          flex-direction: column;
        }

        .timeline-step {
          display: flex;
          gap: 18px;
          position: relative;
        }

        .step-marker-col {
          display: flex;
          flex-direction: column;
          align-items: center;
        }

        .step-circle {
          width: 34px;
          height: 34px;
          border-radius: 50%;
          background: #F1F5F9;
          border: 2px solid #CBD5E1;
          color: #64748B;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 800;
          font-size: 0.85rem;
          flex-shrink: 0;
          z-index: 2;
          transition: all 0.2s;
        }

        .timeline-step.completed .step-circle {
          background: #ECFDF5;
          border-color: #10B981;
          color: #059669;
        }

        .timeline-step.current .step-circle {
          background: #FFF0F6;
          border-color: var(--magenta);
          color: var(--magenta);
          box-shadow: 0 0 12px rgba(255, 43, 133, 0.4);
        }

        .step-line {
          width: 2px;
          flex-grow: 1;
          background: #E2E8F0;
          min-height: 44px;
          margin: 4px 0;
        }

        .timeline-step.completed .step-line {
          background: #A7F3D0;
        }

        .step-content-col {
          padding-bottom: 28px;
          flex: 1;
        }

        .step-title-row {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 4px;
        }

        .step-title {
          font-size: 0.98rem;
          font-weight: 800;
          color: #0F172A;
        }

        .timeline-step.current .step-title {
          color: var(--magenta);
        }

        .current-badge {
          font-size: 0.65rem;
          font-weight: 900;
          background: var(--magenta);
          color: #FFFFFF;
          padding: 1px 7px;
          border-radius: 4px;
        }

        .step-desc {
          font-size: 0.82rem;
          color: #64748B;
          line-height: 1.45;
          margin-bottom: 4px;
        }

        .step-time {
          font-size: 0.74rem;
          color: #94A3B8;
          font-weight: 600;
        }

        /* Info Sidebar */
        .info-sidebar-col {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .sidebar-card {
          padding: 20px 22px;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: var(--radius-lg);
        }

        .card-sec-head {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 0.88rem;
          font-weight: 800;
          color: #0F172A;
          margin-bottom: 14px;
          padding-bottom: 10px;
          border-bottom: 1px solid #F1F5F9;
        }

        .package-item-row {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-bottom: 12px;
        }

        .package-icon {
          width: 44px;
          height: 44px;
          border-radius: 10px;
          background: var(--magenta-light);
          border: 1px solid var(--magenta-border);
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }

        .package-meta h5 {
          font-size: 0.92rem;
          font-weight: 800;
          color: #0F172A;
          margin: 0 0 2px 0;
        }

        .package-meta p {
          font-size: 0.76rem;
          color: #64748B;
          margin: 0 0 4px 0;
        }

        .vehicle-pill {
          display: inline-block;
          font-size: 0.7rem;
          font-weight: 800;
          color: #0F172A;
          background: #F1F5F9;
          padding: 2px 6px;
          border-radius: 4px;
          font-family: monospace;
        }

        .pkg-qty {
          font-size: 0.8rem;
          font-weight: 800;
          color: #64748B;
        }

        .feature-tags-wrap {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
        }

        .feat-chip {
          font-size: 0.68rem;
          font-weight: 700;
          color: #475569;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          padding: 3px 8px;
          border-radius: 6px;
        }

        .address-content strong {
          font-size: 0.9rem;
          color: #0F172A;
          display: block;
          margin-bottom: 4px;
        }

        .address-content p {
          font-size: 0.82rem;
          color: #64748B;
          line-height: 1.45;
          margin-bottom: 6px;
        }

        .phone-num {
          font-size: 0.78rem;
          color: #334155;
          font-weight: 700;
        }

        .sidebar-actions-card {
          padding: 16px;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .action-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 11px;
          font-size: 0.86rem;
        }

        .support-help-mini {
          padding: 16px 18px;
          background: var(--magenta-light);
          border: 1px solid var(--magenta-border);
          border-radius: var(--radius-lg);
          display: flex;
          align-items: flex-start;
          gap: 12px;
        }

        .support-help-mini h6 {
          font-size: 0.85rem;
          font-weight: 800;
          color: #0F172A;
          margin-bottom: 2px;
        }

        .support-help-mini p {
          font-size: 0.78rem;
          color: #64748B;
          margin-bottom: 4px;
        }

        .support-help-mini a {
          font-size: 0.78rem;
          color: var(--magenta);
          font-weight: 800;
          text-decoration: underline;
        }

        @media (max-width: 860px) {
          .track-details-grid {
            grid-template-columns: 1fr;
          }
          .status-hero-card {
            flex-direction: column;
            align-items: flex-start;
          }
          .delivery-est-box {
            width: 100%;
            text-align: left;
          }
          .track-search-card {
            flex-direction: column;
            align-items: flex-start;
          }
          .track-input-form {
            width: 100%;
          }
          .input-group-track {
            flex: 1;
            width: auto;
          }
        }
      `})]})}function vt({onNavigate:e}){let[t,n]=(0,_.useState)(1),[r,i]=(0,_.useState)(`KA560100MM1234`),[a,o]=(0,_.useState)(`MH 01 AB 1234`),[s,c]=(0,_.useState)(`SUV`),[l,u]=(0,_.useState)(`Tata Nexon`),[d,f]=(0,_.useState)(`9876543210`),[p,m]=(0,_.useState)(!1),[h,g]=(0,_.useState)(``),[v,y]=(0,_.useState)(``),[b,x]=(0,_.useState)(!0),[ee,S]=(0,_.useState)(!0),C=e=>{e.preventDefault(),r.trim()&&n(2)},te=e=>{e.preventDefault(),a.trim()&&n(3)},w=()=>{d.length>=10&&(m(!0),g(`1234`))};return(0,j.jsxs)(`div`,{className:`activate-page-container`,children:[(0,j.jsx)(`div`,{className:`activate-nav-bar`,children:(0,j.jsxs)(`div`,{className:`container activate-nav-inner`,children:[(0,j.jsxs)(`button`,{className:`btn-back`,onClick:()=>e(`home`),children:[(0,j.jsx)(re,{size:18}),(0,j.jsx)(`span`,{children:`Back to Home`})]}),(0,j.jsxs)(`div`,{className:`activate-pill`,children:[(0,j.jsx)(we,{size:15,color:`#FF2B85`}),(0,j.jsx)(`span`,{children:`Tag Self-Activation`})]})]})}),(0,j.jsxs)(`div`,{className:`container activate-main-wrapper`,children:[(0,j.jsxs)(`div`,{className:`step-indicator-bar`,children:[(0,j.jsxs)(`div`,{className:`step-node ${t>=1?`active`:``} ${t>1?`done`:``}`,children:[(0,j.jsx)(`span`,{className:`step-num`,children:`1`}),(0,j.jsx)(`span`,{className:`step-name`,children:`Scan / Tag ID`})]}),(0,j.jsx)(`div`,{className:`step-connector`}),(0,j.jsxs)(`div`,{className:`step-node ${t>=2?`active`:``} ${t>2?`done`:``}`,children:[(0,j.jsx)(`span`,{className:`step-num`,children:`2`}),(0,j.jsx)(`span`,{className:`step-name`,children:`Vehicle Info`})]}),(0,j.jsx)(`div`,{className:`step-connector`}),(0,j.jsxs)(`div`,{className:`step-node ${t>=3?`active`:``} ${t>3?`done`:``}`,children:[(0,j.jsx)(`span`,{className:`step-num`,children:`3`}),(0,j.jsx)(`span`,{className:`step-name`,children:`Owner & Privacy`})]}),(0,j.jsx)(`div`,{className:`step-connector`}),(0,j.jsxs)(`div`,{className:`step-node ${t>=4?`active`:``}`,children:[(0,j.jsx)(`span`,{className:`step-num`,children:`4`}),(0,j.jsx)(`span`,{className:`step-name`,children:`Live Active`})]})]}),(0,j.jsxs)(`div`,{className:`activate-card glass-card`,children:[t===1&&(0,j.jsxs)(`div`,{className:`step-view`,children:[(0,j.jsxs)(`div`,{className:`step-header`,children:[(0,j.jsx)(`div`,{className:`step-icon-wrap`,children:(0,j.jsx)(_e,{size:28,color:`#FF2B85`})}),(0,j.jsx)(`h2`,{children:`Enter Your CarFrnd Tag ID`}),(0,j.jsxs)(`p`,{children:[`Find the 14-character alphanumeric Tag ID printed on your physical decal (e.g. `,(0,j.jsx)(`code`,{children:`KA560100MM1234`}),`) or scan the QR code.`]})]}),(0,j.jsxs)(`form`,{onSubmit:C,className:`activate-form`,children:[(0,j.jsxs)(`div`,{className:`form-group`,children:[(0,j.jsx)(`label`,{className:`activate-label`,children:`Tag ID (Printed on Decal)`}),(0,j.jsx)(`input`,{type:`text`,className:`activate-input font-mono`,placeholder:`e.g. KA560100MM1234`,value:r,onChange:e=>i(e.target.value.toUpperCase()),required:!0}),(0,j.jsx)(`span`,{className:`input-hint`,children:`Default demo code entered. You can customize or leave as is.`})]}),(0,j.jsxs)(`button`,{type:`submit`,className:`btn-primary full-w next-btn`,children:[`Continue to Vehicle Details `,(0,j.jsx)(ie,{size:16})]})]})]}),t===2&&(0,j.jsxs)(`div`,{className:`step-view`,children:[(0,j.jsxs)(`div`,{className:`step-header`,children:[(0,j.jsx)(`div`,{className:`step-icon-wrap`,children:(0,j.jsx)(oe,{size:28,color:`#FF2B85`})}),(0,j.jsx)(`h2`,{children:`Link Your Vehicle Details`}),(0,j.jsx)(`p`,{children:`Connect your CarFrnd Tag with your vehicle. Callers will see your vehicle number when scanning to ensure they notify the right car.`})]}),(0,j.jsxs)(`form`,{onSubmit:te,className:`activate-form`,children:[(0,j.jsxs)(`div`,{className:`form-group`,children:[(0,j.jsx)(`label`,{className:`activate-label`,children:`Vehicle Registration Number`}),(0,j.jsx)(`input`,{type:`text`,className:`activate-input font-mono uppercase`,placeholder:`e.g. MH 01 AB 1234`,value:a,onChange:e=>o(e.target.value.toUpperCase()),required:!0})]}),(0,j.jsxs)(`div`,{className:`form-row-2`,children:[(0,j.jsxs)(`div`,{className:`form-group`,children:[(0,j.jsx)(`label`,{className:`activate-label`,children:`Vehicle Type`}),(0,j.jsxs)(`select`,{className:`activate-select`,value:s,onChange:e=>c(e.target.value),children:[(0,j.jsx)(`option`,{value:`Sedan`,children:`Sedan`}),(0,j.jsx)(`option`,{value:`SUV`,children:`SUV / Compact SUV`}),(0,j.jsx)(`option`,{value:`Hatchback`,children:`Hatchback`}),(0,j.jsx)(`option`,{value:`EV`,children:`Electric Vehicle (EV)`}),(0,j.jsx)(`option`,{value:`Commercial`,children:`Commercial / Taxi`})]})]}),(0,j.jsxs)(`div`,{className:`form-group`,children:[(0,j.jsx)(`label`,{className:`activate-label`,children:`Vehicle Model (Optional)`}),(0,j.jsx)(`input`,{type:`text`,className:`activate-input`,placeholder:`e.g. Tata Nexon / Creta`,value:l,onChange:e=>u(e.target.value)})]})]}),(0,j.jsxs)(`div`,{className:`btn-group-dual`,children:[(0,j.jsx)(`button`,{type:`button`,className:`btn-secondary`,onClick:()=>n(1),children:`Back`}),(0,j.jsxs)(`button`,{type:`submit`,className:`btn-primary flex-1 next-btn`,children:[`Continue to Owner & Privacy `,(0,j.jsx)(ie,{size:16})]})]})]})]}),t===3&&(0,j.jsxs)(`div`,{className:`step-view`,children:[(0,j.jsxs)(`div`,{className:`step-header`,children:[(0,j.jsx)(`div`,{className:`step-icon-wrap`,children:(0,j.jsx)(be,{size:28,color:`#FF2B85`})}),(0,j.jsx)(`h2`,{children:`Owner Phone & Masked Privacy`}),(0,j.jsx)(`p`,{children:`Your Phone Number Stays Private. We route calls through anonymous masked forwarding so callers never see your actual mobile number.`})]}),(0,j.jsxs)(`form`,{onSubmit:e=>{e.preventDefault(),p&&h.length===4?(setActivatedSuccess(!0),n(4),ct({particleCount:150,spread:90,origin:{y:.5}})):w()},className:`activate-form`,children:[(0,j.jsxs)(`div`,{className:`form-group`,children:[(0,j.jsx)(`label`,{className:`activate-label`,children:`Owner Mobile Number (For Forwarded Calls)`}),(0,j.jsxs)(`div`,{className:`phone-input-field`,children:[(0,j.jsx)(`span`,{className:`p-prefix`,children:`+91`}),(0,j.jsx)(`input`,{type:`tel`,placeholder:`10-digit mobile number`,value:d,onChange:e=>f(e.target.value),required:!0}),p?(0,j.jsx)(`span`,{className:`otp-sent-pill`,children:`OTP Sent (1234)`}):(0,j.jsx)(`button`,{type:`button`,className:`btn-otp-trigger`,onClick:w,children:`Verify OTP`})]})]}),p&&(0,j.jsxs)(`div`,{className:`form-group`,children:[(0,j.jsx)(`label`,{className:`activate-label`,children:`Enter 4-Digit OTP (Use: 1234)`}),(0,j.jsx)(`input`,{type:`text`,className:`activate-input text-center font-mono`,placeholder:`1234`,value:h,onChange:e=>g(e.target.value),maxLength:4,required:!0})]}),(0,j.jsxs)(`div`,{className:`form-group`,children:[(0,j.jsx)(`label`,{className:`activate-label`,children:`Secondary Emergency Contact (Optional)`}),(0,j.jsx)(`input`,{type:`tel`,className:`activate-input`,placeholder:`Family member or backup contact`,value:v,onChange:e=>y(e.target.value)}),(0,j.jsx)(`span`,{className:`input-hint`,children:`Will be rung if you are unreachable during towing/emergency.`})]}),(0,j.jsxs)(`div`,{className:`privacy-toggles-card`,children:[(0,j.jsxs)(`div`,{className:`toggle-item-row`,children:[(0,j.jsxs)(`div`,{className:`t-meta`,children:[(0,j.jsx)(me,{size:16,color:`#059669`}),(0,j.jsxs)(`div`,{children:[(0,j.jsx)(`strong`,{children:`Masked Voice Call Forwarding`}),(0,j.jsx)(`p`,{children:`Callers speak with you anonymously without seeing your phone number.`})]})]}),(0,j.jsxs)(`label`,{className:`toggle-switch`,children:[(0,j.jsx)(`input`,{type:`checkbox`,checked:b,onChange:e=>x(e.target.checked)}),(0,j.jsx)(`span`,{className:`slider`})]})]}),(0,j.jsxs)(`div`,{className:`toggle-item-row`,children:[(0,j.jsxs)(`div`,{className:`t-meta`,children:[(0,j.jsx)(Te,{size:16,color:`#D97706`}),(0,j.jsxs)(`div`,{children:[(0,j.jsx)(`strong`,{children:`Instant Towing & Parking Alerts`}),(0,j.jsx)(`p`,{children:`Receive immediate SMS alerts if your vehicle is blocking or facing towing.`})]})]}),(0,j.jsxs)(`label`,{className:`toggle-switch`,children:[(0,j.jsx)(`input`,{type:`checkbox`,checked:ee,onChange:e=>S(e.target.checked)}),(0,j.jsx)(`span`,{className:`slider`})]})]})]}),(0,j.jsxs)(`div`,{className:`btn-group-dual`,children:[(0,j.jsx)(`button`,{type:`button`,className:`btn-secondary`,onClick:()=>n(2),children:`Back`}),(0,j.jsxs)(`button`,{type:`submit`,className:`btn-primary flex-1 next-btn`,children:[(0,j.jsx)(ue,{size:16}),` Complete Activation`]})]})]})]}),t===4&&(0,j.jsxs)(`div`,{className:`step-view success-view`,children:[(0,j.jsx)(`div`,{className:`success-badge-circle`,children:(0,j.jsx)(E,{size:44,color:`#059669`})}),(0,j.jsx)(`h2`,{className:`success-headline`,children:`CarFrnd Tag Is Live & Protected! 🎉`}),(0,j.jsxs)(`p`,{className:`success-subtext`,children:[`Your Tag `,(0,j.jsx)(`strong`,{children:r}),` is successfully paired with vehicle `,(0,j.jsx)(`strong`,{children:a}),`. Your phone number is 100% shielded via anonymous masked communication.`]}),(0,j.jsxs)(`div`,{className:`active-tag-preview glass-card`,children:[(0,j.jsxs)(`div`,{className:`tag-preview-header`,children:[(0,j.jsxs)(`span`,{className:`live-status-pill`,children:[(0,j.jsx)(`span`,{className:`pulse-dot`}),` LIVE & ACTIVE`]}),(0,j.jsx)(`span`,{className:`tag-code`,children:r})]}),(0,j.jsxs)(`div`,{className:`tag-preview-body`,children:[(0,j.jsx)(`div`,{className:`tag-qr-wrap`,children:(0,j.jsx)(it,{value:`https://carfrnd.com/scan?tag=${r}&v=${a.replace(/\s+/g,``)}`,size:90,level:`H`})}),(0,j.jsxs)(`div`,{className:`tag-meta-details`,children:[(0,j.jsx)(`span`,{className:`vehicle-big`,children:a}),(0,j.jsxs)(`span`,{className:`vehicle-sub`,children:[l,` • `,s]}),(0,j.jsxs)(`div`,{className:`protected-row`,children:[(0,j.jsx)(be,{size:14,color:`#FF2B85`}),(0,j.jsxs)(`span`,{children:[`Phone Masking Enabled (+91 `,d.slice(0,2),`******`,d.slice(-2),`)`]})]})]})]})]}),(0,j.jsxs)(`div`,{className:`application-guide-card`,children:[(0,j.jsx)(`h5`,{children:`How to Affix Your Decal:`}),(0,j.jsxs)(`div`,{className:`guide-steps-row`,children:[(0,j.jsxs)(`div`,{className:`g-step`,children:[(0,j.jsx)(`span`,{className:`g-num`,children:`1`}),(0,j.jsx)(`span`,{children:`Clean interior windshield glass thoroughly`})]}),(0,j.jsxs)(`div`,{className:`g-step`,children:[(0,j.jsx)(`span`,{className:`g-num`,children:`2`}),(0,j.jsx)(`span`,{children:`Peel protective backing layer`})]}),(0,j.jsxs)(`div`,{className:`g-step`,children:[(0,j.jsx)(`span`,{className:`g-num`,children:`3`}),(0,j.jsx)(`span`,{children:`Press decal firmly to bottom-left corner`})]})]})]}),(0,j.jsx)(`div`,{className:`success-actions-row`,children:(0,j.jsx)(`button`,{className:`btn-primary full-w`,onClick:()=>e(`home`),children:`Return to Home`})})]})]})]}),(0,j.jsx)(`style`,{children:`
        .activate-page-container {
          min-height: 100vh;
          background: #F8FAFC;
          padding-top: 86px;
          padding-bottom: 60px;
        }

        .activate-nav-bar {
          background: rgba(255, 255, 255, 0.96);
          backdrop-filter: blur(12px);
          border-bottom: 1px solid #E2E8F0;
          padding: 12px 0;
          margin-bottom: 24px;
        }

        .activate-nav-inner {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .btn-back {
          background: none;
          border: 1px solid #CBD5E1;
          padding: 8px 14px;
          border-radius: 10px;
          font-weight: 700;
          font-size: 0.88rem;
          color: #334155;
          display: flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          transition: all 0.2s;
        }

        .btn-back:hover {
          background: #F1F5F9;
          color: #0F172A;
        }

        .activate-pill {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 0.86rem;
          font-weight: 800;
          color: var(--magenta);
          background: var(--magenta-light);
          border: 1px solid var(--magenta-border);
          padding: 6px 14px;
          border-radius: 20px;
        }

        .activate-main-wrapper {
          max-width: 680px;
          margin: 0 auto;
        }

        /* Stepper Bar */
        .step-indicator-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 24px;
          padding: 0 10px;
        }

        .step-node {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 6px;
        }

        .step-num {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: #F1F5F9;
          border: 2px solid #CBD5E1;
          color: #64748B;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 800;
          font-size: 0.85rem;
          transition: all 0.25s;
        }

        .step-name {
          font-size: 0.72rem;
          font-weight: 700;
          color: #64748B;
          white-space: nowrap;
        }

        .step-node.active .step-num {
          background: var(--magenta-light);
          border-color: var(--magenta);
          color: var(--magenta);
          box-shadow: 0 0 10px rgba(255, 43, 133, 0.3);
        }

        .step-node.active .step-name {
          color: var(--magenta);
        }

        .step-node.done .step-num {
          background: #ECFDF5;
          border-color: #10B981;
          color: #059669;
        }

        .step-connector {
          flex: 1;
          height: 2px;
          background: #E2E8F0;
          margin: 0 8px 20px 8px;
        }

        /* Form Card */
        .activate-card {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: var(--radius-xl);
          padding: 36px 32px;
          box-shadow: 0 10px 30px rgba(15, 23, 42, 0.05);
        }

        .step-header {
          text-align: center;
          margin-bottom: 24px;
        }

        .step-icon-wrap {
          width: 58px;
          height: 58px;
          border-radius: 50%;
          background: var(--magenta-light);
          border: 1px solid var(--magenta-border);
          display: flex;
          align-items: center;
          justify-content: center;
          margin: 0 auto 14px auto;
        }

        .step-header h2 {
          font-size: 1.45rem;
          font-weight: 900;
          color: #0F172A;
          margin-bottom: 6px;
        }

        .step-header p {
          font-size: 0.88rem;
          color: #64748B;
          max-width: 480px;
          margin: 0 auto;
          line-height: 1.5;
        }

        .step-header code {
          background: #F1F5F9;
          color: var(--magenta);
          padding: 2px 6px;
          border-radius: 4px;
          font-weight: 800;
        }

        .activate-form {
          display: flex;
          flex-direction: column;
          gap: 18px;
        }

        .activate-label {
          font-size: 0.8rem;
          font-weight: 700;
          color: #334155;
          display: block;
          margin-bottom: 6px;
        }

        .activate-input, .activate-select {
          width: 100%;
          padding: 11px 14px;
          border: 1px solid #CBD5E1;
          border-radius: 10px;
          background: #F8FAFC;
          font-size: 0.92rem;
          color: #0F172A;
          outline: none;
          transition: all 0.2s;
        }

        .activate-input:focus, .activate-select:focus {
          border-color: var(--magenta);
          background: #FFFFFF;
          box-shadow: 0 0 0 3px rgba(255, 43, 133, 0.12);
        }

        .font-mono {
          font-family: monospace;
          letter-spacing: 0.05em;
        }

        .uppercase {
          text-transform: uppercase;
        }

        .input-hint {
          font-size: 0.72rem;
          color: #94A3B8;
          margin-top: 4px;
          display: block;
        }

        .scan-shortcut-box {
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: #F8FAFC;
          border: 1px dashed #CBD5E1;
          padding: 10px 14px;
          border-radius: 10px;
          font-size: 0.82rem;
          color: #64748B;
        }

        .scan-btn-mini {
          padding: 6px 12px;
          font-size: 0.78rem;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .form-row-2 {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 14px;
        }

        .phone-input-field {
          display: flex;
          align-items: center;
          border: 1px solid #CBD5E1;
          border-radius: 10px;
          background: #F8FAFC;
          overflow: hidden;
        }

        .phone-input-field:focus-within {
          border-color: var(--magenta);
          background: #FFFFFF;
        }

        .p-prefix {
          padding: 0 12px;
          font-size: 0.9rem;
          font-weight: 700;
          color: #64748B;
          border-right: 1px solid #CBD5E1;
          background: #F1F5F9;
        }

        .phone-input-field input {
          border: none;
          background: transparent;
          padding: 11px 14px;
          font-size: 0.92rem;
          width: 100%;
          outline: none;
        }

        .btn-otp-trigger {
          background: var(--magenta);
          color: #FFFFFF;
          border: none;
          padding: 7px 12px;
          margin-right: 6px;
          border-radius: 6px;
          font-size: 0.78rem;
          font-weight: 700;
          cursor: pointer;
          white-space: nowrap;
        }

        .otp-sent-pill {
          font-size: 0.72rem;
          font-weight: 800;
          color: #059669;
          background: #ECFDF5;
          border: 1px solid #A7F3D0;
          padding: 4px 8px;
          margin-right: 6px;
          border-radius: 6px;
          white-space: nowrap;
        }

        .text-center {
          text-align: center;
        }

        /* Privacy toggles */
        .privacy-toggles-card {
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 12px;
          padding: 14px 16px;
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .toggle-item-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
        }

        .t-meta {
          display: flex;
          align-items: flex-start;
          gap: 10px;
        }

        .t-meta strong {
          font-size: 0.85rem;
          color: #0F172A;
          display: block;
        }

        .t-meta p {
          font-size: 0.76rem;
          color: #64748B;
          margin: 0;
          line-height: 1.35;
        }

        /* Toggle switch */
        .toggle-switch {
          position: relative;
          display: inline-block;
          width: 36px;
          height: 20px;
          flex-shrink: 0;
        }

        .toggle-switch input {
          opacity: 0;
          width: 0;
          height: 0;
        }

        .slider {
          position: absolute;
          cursor: pointer;
          inset: 0;
          background-color: #CBD5E1;
          transition: 0.3s;
          border-radius: 20px;
        }

        .slider:before {
          position: absolute;
          content: "";
          height: 14px;
          width: 14px;
          left: 3px;
          bottom: 3px;
          background-color: white;
          transition: 0.3s;
          border-radius: 50%;
        }

        input:checked + .slider {
          background-color: #10B981;
        }

        input:checked + .slider:before {
          transform: translateX(16px);
        }

        .btn-group-dual {
          display: flex;
          gap: 12px;
          margin-top: 8px;
        }

        .flex-1 {
          flex: 1;
        }

        .next-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 13px;
          font-size: 0.94rem;
        }

        /* Success View */
        .success-view {
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
        }

        .success-badge-circle {
          width: 72px;
          height: 72px;
          border-radius: 50%;
          background: #ECFDF5;
          border: 2px solid #A7F3D0;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 16px;
        }

        .success-headline {
          font-size: 1.6rem;
          font-weight: 900;
          color: #0F172A;
          margin-bottom: 8px;
        }

        .success-subtext {
          font-size: 0.9rem;
          color: #64748B;
          max-width: 480px;
          line-height: 1.5;
          margin-bottom: 24px;
        }

        .active-tag-preview {
          width: 100%;
          background: #FFFFFF;
          border: 1.5px solid var(--magenta-border);
          border-radius: 16px;
          padding: 20px;
          margin-bottom: 20px;
          box-shadow: 0 8px 24px rgba(255, 43, 133, 0.08);
        }

        .tag-preview-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding-bottom: 12px;
          border-bottom: 1px solid #F1F5F9;
          margin-bottom: 16px;
        }

        .live-status-pill {
          display: flex;
          align-items: center;
          gap: 6px;
          background: #ECFDF5;
          color: #059669;
          font-size: 0.72rem;
          font-weight: 800;
          padding: 3px 8px;
          border-radius: 12px;
        }

        .pulse-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
        }

        .tag-code {
          font-family: monospace;
          font-size: 0.85rem;
          font-weight: 700;
          color: #64748B;
        }

        .tag-preview-body {
          display: flex;
          align-items: center;
          gap: 20px;
          text-align: left;
        }

        .tag-qr-wrap {
          background: #FFFFFF;
          padding: 6px;
          border: 1px solid #E2E8F0;
          border-radius: 10px;
          flex-shrink: 0;
        }

        .vehicle-big {
          font-family: var(--font-heading);
          font-size: 1.4rem;
          font-weight: 900;
          color: #0F172A;
          letter-spacing: 0.04em;
          display: block;
        }

        .vehicle-sub {
          font-size: 0.8rem;
          color: #64748B;
          display: block;
          margin-bottom: 6px;
        }

        .protected-row {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 0.76rem;
          color: #059669;
          font-weight: 700;
        }

        /* Application Guide */
        .application-guide-card {
          width: 100%;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 14px;
          padding: 16px;
          margin-bottom: 24px;
          text-align: left;
        }

        .application-guide-card h5 {
          font-size: 0.85rem;
          font-weight: 800;
          color: #0F172A;
          margin-bottom: 10px;
        }

        .guide-steps-row {
          display: grid;
          grid-template-columns: 1fr 1fr 1fr;
          gap: 10px;
        }

        .g-step {
          display: flex;
          align-items: flex-start;
          gap: 8px;
          font-size: 0.75rem;
          color: #475569;
          line-height: 1.35;
        }

        .g-num {
          width: 18px;
          height: 18px;
          border-radius: 50%;
          background: var(--magenta);
          color: #FFFFFF;
          font-size: 0.68rem;
          font-weight: 800;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }

        .success-actions-row {
          display: flex;
          gap: 12px;
          width: 100%;
        }

        .success-actions-row button {
          flex: 1;
          padding: 12px;
          font-size: 0.9rem;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
        }

        @media (max-width: 600px) {
          .activate-card {
            padding: 24px 18px;
          }
          .form-row-2 {
            grid-template-columns: 1fr;
          }
          .guide-steps-row {
            grid-template-columns: 1fr;
            gap: 8px;
          }
          .tag-preview-body {
            flex-direction: column;
            text-align: center;
          }
          .success-actions-row {
            flex-direction: column;
          }
        }
      `})]})}function yt(){let[e,t]=(0,_.useState)(!1),[n,r]=(0,_.useState)(!1),i=()=>{let e=window.location.pathname.toLowerCase(),t=window.location.hash.toLowerCase(),n=e+` `+t;return n.includes(`bill`)||n.includes(`invoice`)?`bill`:n.includes(`track`)?`track-order`:n.includes(`activate`)?`activate-tag`:`home`},[a,o]=(0,_.useState)(i()),[s,c]=(0,_.useState)(null),[l,u]=(0,_.useState)(`CF-842918`);(0,_.useEffect)(()=>{(window.location.hash===`#/`||window.location.hash===`#`)&&window.history.replaceState(null,``,window.location.pathname);let e=()=>{o(i())};return window.addEventListener(`popstate`,e),window.addEventListener(`hashchange`,e),()=>{window.removeEventListener(`popstate`,e),window.removeEventListener(`hashchange`,e)}},[]);let d=(e,t)=>{o(e);let n=`/`;if(e===`bill`)n=`/bill`,t&&(typeof t==`object`?c(t):typeof t==`string`&&(u(t),c(e=>({...e||{},orderId:t}))));else if(e===`track-order`){if(n=`/track-order`,t){let e=typeof t==`string`?t:t.orderId;u(e)}}else n=e===`activate-tag`?`/activate-tag`:`/`;(window.location.pathname!==n||window.location.hash)&&window.history.pushState(null,``,n),window.scrollTo({top:0,behavior:`smooth`})},f=()=>{if(a!==`home`){d(`home`),setTimeout(()=>{let e=document.getElementById(`order-tag`);e&&e.scrollIntoView({behavior:`smooth`})},50);return}let e=document.getElementById(`order-tag`);e&&e.scrollIntoView({behavior:`smooth`})};return(0,j.jsxs)(`div`,{className:`carfrnd-app-root`,children:[(0,j.jsx)(je,{onOpenOrderTag:f,onOpenAccount:()=>r(!0),onNavigate:d,currentView:a}),(0,j.jsx)(`main`,{className:`main-content-wrapper`,children:a===`bill`?(0,j.jsx)(gt,{activeOrder:s,onNavigate:d}):a===`track-order`?(0,j.jsx)(_t,{initialOrderId:l,onNavigate:d}):a===`activate-tag`?(0,j.jsx)(vt,{onNavigate:d}):(0,j.jsxs)(j.Fragment,{children:[(0,j.jsx)(at,{onOpenOrderTag:f,onOpenDoorstepWash:()=>t(!0)}),(0,j.jsx)(ot,{onOpenOrderTag:f}),(0,j.jsx)(lt,{onOpenOrderTag:f}),(0,j.jsx)(ut,{onOpenBill:e=>d(`bill`,e),onOpenTrackOrder:e=>d(`track-order`,e)}),(0,j.jsx)(dt,{})]})}),(0,j.jsx)(ft,{onOpenOrderTag:f,onNavigate:d}),(0,j.jsx)(pt,{onOpenOrderTag:f,onOpenAccount:()=>r(!0),onNavigate:d,currentView:a}),(0,j.jsx)(mt,{isOpen:e,onClose:()=>t(!1)}),(0,j.jsx)(ht,{isOpen:n,onClose:()=>r(!1),onOpenOrderTag:f,onNavigate:d})]})}(0,v.createRoot)(document.getElementById(`root`)).render((0,j.jsx)(_.StrictMode,{children:(0,j.jsx)(yt,{})}));